package cn.blockforge.generated.allreturn.combat;

import cn.blockforge.generated.allreturn.AllReturnMod;
import java.util.List;
import net.minecraft.network.protocol.game.ClientboundRemoveEntitiesPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

public final class HardPurge {

    public static final float OVERKILL = Float.MAX_VALUE;

    private HardPurge() {
    }

    public static boolean erase(Entity target, Player attacker) {
        if (target == null || target.isRemoved()) {
            return false;
        }
        boolean isPlayer = target instanceof Player;
        boolean purged = false;

        step(() -> target.setInvulnerable(false));
        step(() -> target.setSilent(true));
        if (target instanceof LivingEntity living) {
            step(() -> living.setAbsorptionAmount(0.0F));
            step(() -> living.removeAllEffects());
            step(() -> living.invulnerableTime = 0);
            step(() -> living.setDeltaMovement(Vec3.ZERO));
            step(living::clearFire);
            if (living instanceof Mob mob) {

                step(() -> mob.setNoAi(true));
            }

            if (!isPlayer) {
                step(() -> {
                    AttributeInstance maxHealth = living.getAttribute(Attributes.MAX_HEALTH);
                    if (maxHealth != null) {
                        maxHealth.setBaseValue(0.0D);
                    }
                });
            }

            DamageSource playerHit = attacker == null
                    ? living.damageSources().genericKill()
                    : attacker.damageSources().playerAttack(attacker);
            step(() -> living.hurt(playerHit, OVERKILL));

            if (living.isAlive()) {
                step(() -> living.hurt(living.damageSources().genericKill(), OVERKILL));
            }

            if (living.isAlive() && !isPlayer) {
                step(() -> living.hurt(living.damageSources().fellOutOfWorld(), OVERKILL));
            }

            if (living.isAlive()) {
                step(() -> living.setHealth(0.0F));
                step(() -> living.die(living.damageSources().genericKill()));
            }
        }

        if (!isPlayer) {
            step(target::ejectPassengers);
            step(target::stopRiding);
            step(() -> target.remove(Entity.RemovalReason.KILLED));
            if (!target.isRemoved()) {
                step(target::discard);
            }
            if (!target.isRemoved()) {
                step(() -> target.setRemoved(Entity.RemovalReason.DISCARDED));
            }

            step(() -> sendRemovalPacket(target));
            InterceptStats.purged();
            purged = target.isRemoved();
        }
        return purged;
    }

    public static boolean reseal(Entity target) {
        return erase(target, null);
    }

    private static void sendRemovalPacket(Entity target) {
        if (!(target.level() instanceof ServerLevel level)) {
            return;
        }
        ClientboundRemoveEntitiesPacket packet = new ClientboundRemoveEntitiesPacket(target.getId());
        List<ServerPlayer> players = level.players();
        for (ServerPlayer player : players) {
            if (player != null && player.connection != null) {
                player.connection.send(packet);
            }
        }
    }

    private static void step(Runnable action) {
        try {
            action.run();
        } catch (RuntimeException exception) {
            InterceptStats.blocked();
            AllReturnMod.LOGGER.debug("强力清除的某一步被目标自己的逻辑挡住了", exception);
        }
    }
}
