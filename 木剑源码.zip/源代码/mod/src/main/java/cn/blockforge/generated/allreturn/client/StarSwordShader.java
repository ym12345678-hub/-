package cn.blockforge.generated.allreturn.client;

import cn.blockforge.generated.allreturn.AllReturnMod;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.logging.LogUtils;
import java.io.IOException;
import java.util.Map;
import net.minecraft.client.renderer.RenderStateShard;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.ShaderInstance;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.inventory.InventoryMenu;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.ModelEvent;
import net.minecraftforge.client.event.RegisterShadersEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import org.slf4j.Logger;

@OnlyIn(Dist.CLIENT)
public final class StarSwordShader {
    private static final Logger LOGGER = LogUtils.getLogger();

    private static final String SHADER_NAME = "star_sword";

    private static final String ITEM_PATH = "wooden_sword";
    private static final String RENDER_TYPE_NAME = "all_return_star_sword";

    private static volatile ShaderInstance shader;
    private static RenderType starRenderType;

    private StarSwordShader() {
    }

    public static void register(IEventBus modBus) {
        modBus.addListener(StarSwordShader::onRegisterShaders);
        modBus.addListener(StarSwordShader::onModifyBakingResult);
    }

    public static RenderType renderType() {
        if (shader == null) {
            return null;
        }
        RenderType type = starRenderType;
        if (type == null) {
            type = States.createStarRenderType();
            starRenderType = type;
        }
        return type;
    }

    private static void onRegisterShaders(RegisterShadersEvent event) {
        shader = null;
        try {
            ShaderInstance instance = new ShaderInstance(
                    event.getResourceProvider(),
                    new ResourceLocation(AllReturnMod.MOD_ID, SHADER_NAME),
                    DefaultVertexFormat.NEW_ENTITY);
            event.registerShader(instance, loaded -> shader = loaded);
        } catch (IOException | RuntimeException exception) {
            LOGGER.error("星空着色器 star_sword 没能编译，湮灭之刃会退回普通贴图渲染", exception);
        }
    }

    private static void onModifyBakingResult(ModelEvent.ModifyBakingResult event) {
        for (Map.Entry<ResourceLocation, BakedModel> entry : event.getModels().entrySet()) {
            ResourceLocation key = entry.getKey();
            if (!AllReturnMod.MOD_ID.equals(key.getNamespace()) || !ITEM_PATH.equals(key.getPath())) {
                continue;
            }
            BakedModel original = entry.getValue();
            if (original == null || original instanceof StarSwordModel) {
                continue;
            }
            entry.setValue(new StarSwordModel(original));
        }
    }

    private static final class States extends RenderStateShard {
        private States() {
            super(RENDER_TYPE_NAME, () -> {
            }, () -> {
            });
        }

        private static RenderType createStarRenderType() {
            return RenderType.create(
                    RENDER_TYPE_NAME,
                    DefaultVertexFormat.NEW_ENTITY,
                    VertexFormat.Mode.QUADS,
                    256,
                    false,
                    false,
                    RenderType.CompositeState.builder()

                            .setShaderState(new ShaderStateShard(() -> shader))

                            .setTextureState(new TextureStateShard(InventoryMenu.BLOCK_ATLAS, false, false))

                            .setTransparencyState(NO_TRANSPARENCY)
                            .setDepthTestState(LEQUAL_DEPTH_TEST)
                            .setCullState(NO_CULL)
                            .setLightmapState(NO_LIGHTMAP)
                            .setOverlayState(NO_OVERLAY)
                            .setWriteMaskState(COLOR_DEPTH_WRITE)
                            .setOutputState(MAIN_TARGET)
                            .createCompositeState(true));
        }
    }
}
