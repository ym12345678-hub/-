package cn.blockforge.generated.allreturn.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@OnlyIn(Dist.CLIENT)
public final class ClientFreeze {
    private static final Logger LOGGER = LoggerFactory.getLogger("all_return/client");

    private static boolean frozen;

    private static long setAt;

    private static long dayTime;
    private static float rainLevel;
    private static float thunderLevel;

    private static final long TIMEOUT_MILLIS = 90_000L;

    private ClientFreeze() {
    }

    public static void set(boolean value) {
        if (value && !frozen) {
            ClientLevel level = Minecraft.getInstance().level;
            if (level != null) {
                dayTime = level.getDayTime();
                rainLevel = level.getRainLevel(1.0F);
                thunderLevel = level.getThunderLevel(1.0F);
            }
            setAt = System.currentTimeMillis();
        }
        frozen = value;
    }

    public static boolean isFrozen() {
        return frozen;
    }

    public static boolean expired() {
        return frozen && System.currentTimeMillis() - setAt > TIMEOUT_MILLIS;
    }

    public static void holdWeather() {
        if (!frozen) {
            return;
        }
        ClientLevel level = Minecraft.getInstance().level;
        if (level == null) {
            return;
        }
        try {
            level.setDayTime(dayTime);
            level.setRainLevel(rainLevel);
            level.setThunderLevel(thunderLevel);
        } catch (RuntimeException exception) {
            LOGGER.debug("暂停期间固定天空失败，跳过这一帧", exception);
        }
    }
}
