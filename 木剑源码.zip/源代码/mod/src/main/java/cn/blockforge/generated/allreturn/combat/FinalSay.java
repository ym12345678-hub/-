package cn.blockforge.generated.allreturn.combat;

import cn.blockforge.generated.allreturn.AllReturnMod;
import cn.blockforge.generated.allreturn.state.AllReturnState;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundPlayerCombatKillPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.ItemStack;

public final class FinalSay {

    private static final int DURATION_TICKS = 20 * 10;

    private static final int GUI_PACKET_INTERVAL = 5;

    private static final Map<UUID, Long> DOOMED = new ConcurrentHashMap<>();

    private FinalSay() {
    }

    public static void mark(ServerPlayer target) {
        if (target == null || target.level().isClientSide) {
            return;
        }
        if (AllReturnState.protectedFromPurge(target)) {
            return;
        }
        DOOMED.put(target.getUUID(), target.level().getGameTime() + DURATION_TICKS);
        InterceptStats.blocked();
    }

    public static boolean isDoomed(LivingEntity entity) {
        if (entity == null) {
            return false;
        }
        Long until = DOOMED.get(entity.getUUID());
        if (until == null) {
            return false;
        }
        if (until < entity.level().getGameTime()) {
            DOOMED.remove(entity.getUUID());
            return false;
        }
        return true;
    }

    public static void tick(MinecraftServer server) {
        if (server == null || DOOMED.isEmpty()) {
            return;
        }
        long now = server.overworld().getGameTime();
        Iterator<Map.Entry<UUID, Long>> iterator = DOOMED.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<UUID, Long> entry = iterator.next();
            if (entry.getValue() < now) {
                iterator.remove();
                continue;
            }
            ServerPlayer player = server.getPlayerList().getPlayer(entry.getKey());
            if (player == null) {
                continue;
            }
            force(player);
        }
    }

    private static void force(ServerPlayer player) {

        step(() -> player.setInvulnerable(false));
        step(() -> player.setAbsorptionAmount(0.0F));
        step(() -> player.removeAllEffects());
        step(() -> player.setItemInHand(InteractionHand.MAIN_HAND, ItemStack.EMPTY));
        step(() -> player.setItemInHand(InteractionHand.OFF_HAND, ItemStack.EMPTY));
        step(() -> player.getInventory().clearContent());

        step(() -> player.setHealth(0.0F));
        step(() -> ReflectPurge.forceDead(player, true));
        step(() -> player.hurt(player.damageSources().genericKill(), Float.MAX_VALUE));
        step(() -> player.die(player.damageSources().genericKill()));

        if (player.tickCount % GUI_PACKET_INTERVAL == 0 && player.connection != null) {
            step(() -> player.connection.send(new ClientboundPlayerCombatKillPacket(
                    player.getId(), Component.literal("全返：已被抹除"))));
        }

        if (player.level() instanceof ServerLevel level) {
            level.sendParticles(ParticleTypes.SOUL_FIRE_FLAME,
                    player.getX(), player.getY() + 1.0D, player.getZ(),
                    24, 0.5D, 0.9D, 0.5D, 0.02D);
            level.sendParticles(ParticleTypes.END_ROD,
                    player.getX(), player.getY() + 1.0D, player.getZ(),
                    16, 0.45D, 0.8D, 0.45D, 0.03D);
            if (player.tickCount % 10 == 0) {
                level.playSound(null, player.getX(), player.getY(), player.getZ(),
                        SoundEvents.PLAYER_ATTACK_CRIT, SoundSource.PLAYERS, 1.0F, 0.8F);
                player.displayClientMessage(Component.literal("全返 · 最终裁决"), true);
            }
        }

        step(() -> player.setRemoved(Entity.RemovalReason.KILLED));
        InterceptStats.blocked();
    }

    private static void step(Runnable action) {
        try {
            action.run();
        } catch (Throwable throwable) {
            AllReturnMod.LOGGER.debug("最终裁决的某一步被目标逻辑挡住", throwable);
        }
    }
}
