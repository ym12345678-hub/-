package cn.blockforge.generated.allreturn.client;

import cn.blockforge.generated.allreturn.state.AllReturnState;
import cn.blockforge.generated.allreturn.util.RainbowText;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.gui.overlay.ForgeGui;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;

@OnlyIn(Dist.CLIENT)
public final class AllReturnHud implements IGuiOverlay {
    public static final int BTN_W = 56;
    public static final int BTN_H = 20;
    private static final int MARGIN = 4;
    private static final int FROZEN_W = 56;
    private static final int FROZEN_H = 14;

    public static int buttonX() {
        return MARGIN;
    }

    public static int buttonY(int screenHeight) {
        return screenHeight / 2 - BTN_H / 2;
    }

    public static boolean hit(double guiX, double guiY, int screenHeight) {
        int x = buttonX();
        int y = buttonY(screenHeight);
        return guiX >= x && guiX < x + BTN_W && guiY >= y && guiY < y + BTN_H;
    }

    @Override
    public void render(ForgeGui gui, GuiGraphics graphics, float partialTick, int screenWidth, int screenHeight) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player == null || minecraft.options.hideGui) {
            return;
        }
        if (!AllReturnState.hasGear(minecraft.player)) {
            return;
        }
        boolean on = (ClientScreenOpener.flags() & AllReturnState.ALLRETURN) != 0;
        int x = buttonX();
        int y = buttonY(screenHeight);

        graphics.fill(x, y, x + BTN_W, y + BTN_H, 0xC8120A1C);
        int accent = on ? 0xFFB47CFF : 0xFF5A4A72;
        graphics.fill(x, y, x + BTN_W, y + 2, accent);
        graphics.fill(x, y, x + 2, y + BTN_H, accent);
        graphics.fill(x + BTN_W - 2, y, x + BTN_W, y + BTN_H, accent);
        graphics.fill(x, y + BTN_H - 2, x + BTN_W, y + BTN_H, accent);

        graphics.fill(x + 7, y + 8, x + 11, y + 12, on ? 0xFF5CFF9D : 0xFFFF6B6B);
        graphics.drawString(minecraft.font, RainbowText.of(Component.translatable("gui.all_return.hud")),
                x + 15, y + 6, on ? 0xFFE8E0FF : 0xFFBDB4CF, false);

        if (ClientFreeze.isFrozen()) {
            int ty = y + BTN_H + 2;
            graphics.fill(x, ty, x + FROZEN_W, ty + FROZEN_H, 0xC84A0030);
            graphics.fill(x, ty, x + FROZEN_W, ty + 1, 0xFFFF9AD5);
            graphics.drawString(minecraft.font, Component.translatable("gui.all_return.frozen"),
                    x + 4, ty + 3, 0xFFFFD0F0, false);
        }
    }
}
