package cn.blockforge.generated.allreturn.win;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

/**
 * 扫描 {@code mods/*.jar}，算出「别的模组」的包名和类名。
 *
 * <p>全返不点名任何具体模组：谁进了 mods 目录、又不是自己，就都算目标。
 * 只有 SoV 这种明显不该动的包会被排除（JDK、Minecraft、Forge、ASM 等）。
 */
final class WinTargets {

    /** 明显不该动的包前缀：和原生层的粗筛保持一致。 */
    private static final String[] SKIP_PREFIXES = {
            "java.", "javax.", "jdk.", "sun.", "com.sun.",
            "com.mojang.", "cpw.", "net.minecraft.", "net.minecraftforge.", "net.neoforged.",
            "org.objectweb.", "org.slf4j.", "org.apache.", "org.spongepowered.",
            "org.lwjgl.", "org.joml.", "org.jetbrains.", "org.antlr.", "org.mixin.",
            "io.netty.", "it.unimi.", "com.google.",
            "cn.blockforge."
    };

    private static volatile Set<String> packages = Collections.emptySet();

    private static volatile Set<String> classes = Collections.emptySet();

    private static volatile Map<String, String> owner = Collections.emptyMap();

    private WinTargets() {
    }

    static synchronized void refresh() {
        Set<String> pkgAcc = new HashSet<>();
        Set<String> clsAcc = new HashSet<>();
        Map<String, String> ownerAcc = new HashMap<>();

        Path mods = modsDirectory();
        if (mods == null) {
            packages = Collections.emptySet();
            classes = Collections.emptySet();
            owner = Collections.emptyMap();
            return;
        }

        Path self = ownJar();
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(mods, "*.jar")) {
            for (Path jarPath : stream) {
                String fileName = jarPath.getFileName().toString();
                if (fileName.startsWith("all_return") || fileName.startsWith("allreturn")) {
                    continue;
                }
                if (self != null && same(self, jarPath)) {
                    continue;
                }
                scanJar(jarPath, pkgAcc, clsAcc, ownerAcc);
            }
        } catch (IOException ignored) {
        }

        packages = Collections.unmodifiableSet(pkgAcc);
        classes = Collections.unmodifiableSet(clsAcc);
        owner = Collections.unmodifiableMap(ownerAcc);
    }

    private static void scanJar(Path jarPath, Set<String> pkgAcc, Set<String> clsAcc,
                                Map<String, String> ownerAcc) {
        try (JarFile jar = new JarFile(jarPath.toFile())) {
            var entries = jar.entries();
            while (entries.hasMoreElements()) {
                JarEntry entry = entries.nextElement();
                String name = entry.getName();
                if (!name.endsWith(".class") || name.startsWith("META-INF/")
                        || name.endsWith("module-info.class")) {
                    continue;
                }
                if (name.startsWith("cn/blockforge/")) {
                    continue;
                }
                String internal = name.substring(0, name.length() - ".class".length());
                String dotted = internal.replace('/', '.');
                if (skipped(dotted)) {
                    continue;
                }
                int slash = internal.lastIndexOf('/');
                if (slash <= 0) {
                    continue;
                }
                String pkg = internal.substring(0, slash).replace('/', '.');
                pkgAcc.add(pkg);
                clsAcc.add(internal);
                ownerAcc.putIfAbsent(pkg, jarPath.getFileName().toString());
            }
        } catch (Throwable ignored) {
        }
    }

    private static boolean skipped(String dottedName) {
        for (String prefix : SKIP_PREFIXES) {
            if (dottedName.startsWith(prefix)) {
                return true;
            }
        }
        return false;
    }

    private static Path modsDirectory() {
        String[] candidates = {
                System.getProperty("user.dir", ".") + "/mods",
                "mods"
        };
        for (String candidate : candidates) {
            Path path = Paths.get(candidate);
            if (Files.isDirectory(path)) {
                return path;
            }
        }
        return null;
    }

    private static Path ownJar() {
        try {
            var source = WinTargets.class.getProtectionDomain().getCodeSource();
            if (source == null) {
                return null;
            }
            return Paths.get(source.getLocation().toURI()).toAbsolutePath().normalize();
        } catch (Throwable ignored) {
            return null;
        }
    }

    private static boolean same(Path a, Path b) {
        try {
            return Files.isSameFile(a, b);
        } catch (Throwable ignored) {
            return a.toAbsolutePath().normalize().equals(b.toAbsolutePath().normalize());
        }
    }

    static Set<String> packages() {
        return packages;
    }

    static Set<String> classes() {
        return classes;
    }

    static Map<String, String> owner() {
        return owner;
    }
}
