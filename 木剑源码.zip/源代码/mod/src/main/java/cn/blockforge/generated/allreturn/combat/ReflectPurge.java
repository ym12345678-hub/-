package cn.blockforge.generated.allreturn.combat;

import cn.blockforge.generated.allreturn.AllReturnMod;
import java.lang.reflect.Field;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;

public final class ReflectPurge {

    private static final String[] REMOVED_NAMES = {"removed", "f_19854_"};

    private static final String[] REASON_NAMES = {"removalReason", "f_19855_"};

    private static final String[] HEALTH_NAMES = {"health", "f_20920_"};

    private static final String[] DEAD_NAMES = {"dead", "f_20921_"};

    private static final String[] INVULNERABLE_NAMES = {"invulnerableTime", "f_20922_"};

    private static volatile Field removedField;
    private static volatile Field reasonField;
    private static volatile Field healthField;
    private static volatile Field deadField;
    private static volatile Field invulnerableField;

    private ReflectPurge() {
    }

    public static boolean forceRemove(Entity entity) {
        if (entity == null) {
            return false;
        }
        boolean touched = false;
        try {
            Field removed = removedField();
            if (removed != null) {
                removed.setBoolean(entity, true);
                touched = true;
            }
        } catch (Throwable throwable) {
            debug("removed 字段没写进去", throwable);
        }
        try {
            Field reason = reasonField();
            if (reason != null) {
                reason.set(entity, Entity.RemovalReason.DISCARDED);
                touched = true;
            }
        } catch (Throwable throwable) {
            debug("removalReason 字段没写进去", throwable);
        }
        return touched;
    }

    public static boolean forceSetHealth(LivingEntity entity, float health) {
        if (entity == null) {
            return false;
        }
        boolean touched = false;
        try {
            Field field = healthField();
            if (field != null) {
                field.setFloat(entity, health);
                touched = true;
            }
        } catch (Throwable throwable) {
            debug("health 字段没写进去", throwable);
        }
        if (health <= 0.0F) {
            try {
                Field field = deadField();
                if (field != null) {
                    field.setBoolean(entity, true);
                    touched = true;
                }
            } catch (Throwable throwable) {
                debug("dead 字段没写进去", throwable);
            }
        }
        return touched;
    }

    public static boolean clearInvulnerableTime(LivingEntity entity) {
        if (entity == null) {
            return false;
        }
        try {
            Field field = invulnerableField();
            if (field == null) {
                return false;
            }
            field.setInt(entity, 0);
            return true;
        } catch (Throwable throwable) {
            debug("invulnerableTime 字段没清零", throwable);
            return false;
        }
    }

    public static boolean clearDead(LivingEntity entity) {
        if (entity == null) {
            return false;
        }
        try {
            Field field = deadField();
            if (field == null) {
                return false;
            }
            field.setBoolean(entity, false);
            return true;
        } catch (Throwable throwable) {
            debug("dead 字段没清掉", throwable);
            return false;
        }
    }

    public static boolean forceDead(LivingEntity entity, boolean dead) {
        if (entity == null) {
            return false;
        }
        try {
            Field field = deadField();
            if (field == null) {
                return false;
            }
            field.setBoolean(entity, dead);
            return true;
        } catch (Throwable throwable) {
            debug("dead 标记没写进去", throwable);
            return false;
        }
    }

    public static boolean clearRemoved(Entity entity) {
        if (entity == null) {
            return false;
        }
        boolean touched = false;
        try {
            Field field = removedField();
            if (field != null) {
                field.setBoolean(entity, false);
                touched = true;
            }
        } catch (Throwable throwable) {
            debug("removed 字段没清掉", throwable);
        }
        try {
            Field field = reasonField();
            if (field != null) {
                field.set(entity, null);
                touched = true;
            }
        } catch (Throwable throwable) {
            debug("removalReason 没清掉", throwable);
        }
        return touched;
    }

    public static String describe(Entity entity) {
        if (entity == null) {
            return "entity=null";
        }
        StringBuilder builder = new StringBuilder();
        builder.append("removed=").append(readBoolean(removedField(), entity));
        builder.append(" reason=").append(readObject(reasonField(), entity));
        if (entity instanceof LivingEntity living) {
            builder.append(" health=").append(readFloat(healthField(), living));
            builder.append(" dead=").append(readBoolean(deadField(), living));
            builder.append(" invul=").append(readInt(invulnerableField(), living));
        }
        return builder.toString();
    }

    private static Field removedField() {
        Field cached = removedField;
        if (cached != null) {
            return cached;
        }
        Field resolved = resolve(Entity.class, REMOVED_NAMES, boolean.class, "remove");
        removedField = resolved;
        return resolved;
    }

    private static Field reasonField() {
        Field cached = reasonField;
        if (cached != null) {
            return cached;
        }
        Field resolved = resolve(Entity.class, REASON_NAMES, Entity.RemovalReason.class, "Reason");
        reasonField = resolved;
        return resolved;
    }

    private static Field healthField() {
        Field cached = healthField;
        if (cached != null) {
            return cached;
        }
        Field resolved = resolve(LivingEntity.class, HEALTH_NAMES, float.class, "ealth");
        healthField = resolved;
        return resolved;
    }

    private static Field deadField() {
        Field cached = deadField;
        if (cached != null) {
            return cached;
        }
        Field resolved = resolve(LivingEntity.class, DEAD_NAMES, boolean.class, "dead");
        deadField = resolved;
        return resolved;
    }

    private static Field invulnerableField() {
        Field cached = invulnerableField;
        if (cached != null) {
            return cached;
        }
        Field resolved = resolve(LivingEntity.class, INVULNERABLE_NAMES, int.class, "nvuln");
        invulnerableField = resolved;
        return resolved;
    }

    private static Field resolve(Class<?> owner, String[] names, Class<?> type, String hint) {

        for (String name : names) {
            Field field = findByName(owner, name);
            if (field != null) {
                field.setAccessible(true);
                return field;
            }
        }

        for (Class<?> current = owner; current != null && current != Object.class; current = current.getSuperclass()) {
            for (Field field : current.getDeclaredFields()) {
                if (field.getType() != type) {
                    continue;
                }
                if (!field.getName().contains(hint)) {
                    continue;
                }
                field.setAccessible(true);
                return field;
            }
        }

        Field unique = null;
        int matches = 0;
        for (Class<?> current = owner; current != null && current != Object.class; current = current.getSuperclass()) {
            for (Field field : current.getDeclaredFields()) {
                if (field.getType() == type && !java.lang.reflect.Modifier.isStatic(field.getModifiers())) {
                    unique = field;
                    matches++;
                }
            }
        }
        if (matches == 1 && unique != null) {
            unique.setAccessible(true);
            return unique;
        }
        AllReturnMod.LOGGER.debug("反射清除：{} 上找不到类型为 {} 的字段（候选名 {}）",
                owner.getSimpleName(), type.getSimpleName(), String.join("/", names));
        InterceptStats.blocked();
        return null;
    }

    private static Field findByName(Class<?> owner, String name) {
        for (Class<?> current = owner; current != null && current != Object.class; current = current.getSuperclass()) {
            try {
                return current.getDeclaredField(name);
            } catch (NoSuchFieldException ignored) {

            } catch (SecurityException ignored) {
                return null;
            }
        }
        return null;
    }

    private static String readBoolean(Field field, Object owner) {
        if (field == null) {
            return "n/a";
        }
        try {
            return Boolean.toString(field.getBoolean(owner));
        } catch (Throwable throwable) {
            return "n/a";
        }
    }

    private static String readFloat(Field field, Object owner) {
        if (field == null) {
            return "n/a";
        }
        try {
            return Float.toString(field.getFloat(owner));
        } catch (Throwable throwable) {
            return "n/a";
        }
    }

    private static String readInt(Field field, Object owner) {
        if (field == null) {
            return "n/a";
        }
        try {
            return Integer.toString(field.getInt(owner));
        } catch (Throwable throwable) {
            return "n/a";
        }
    }

    private static String readObject(Field field, Object owner) {
        if (field == null) {
            return "n/a";
        }
        try {
            Object value = field.get(owner);
            return value == null ? "null" : String.valueOf(value);
        } catch (Throwable throwable) {
            return "n/a";
        }
    }

    private static void debug(String message, Throwable throwable) {
        AllReturnMod.LOGGER.debug("反射清除：{}", message, throwable);
        InterceptStats.blocked();
    }
}
