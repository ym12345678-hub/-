package cn.blockforge.generated.allreturn.client;

import cn.blockforge.generated.allreturn.AllReturnMod;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.logging.LogUtils;
import java.io.IOException;
import net.minecraft.client.renderer.RenderStateShard;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.ShaderInstance;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.client.event.RegisterShadersEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import org.slf4j.Logger;

@OnlyIn(Dist.CLIENT)
public final class StarUiShader {
    private static final Logger LOGGER = LogUtils.getLogger();
    private static final String SHADER_NAME = "star_ui";
    private static final String RENDER_TYPE_NAME = "all_return_star_ui";

    private static volatile ShaderInstance shader;
    private static RenderType renderType;

    private StarUiShader() {
    }

    public static void register(IEventBus modBus) {
        modBus.addListener(StarUiShader::onRegisterShaders);
    }

    public static RenderType renderType() {
        if (shader == null) {
            return null;
        }
        RenderType type = renderType;
        if (type == null) {
            type = States.createStarRenderType();
            renderType = type;
        }
        return type;
    }

    public static void setTime(float seconds) {
        ShaderInstance instance = shader;
        if (instance == null) {
            return;
        }
        try {
            instance.safeGetUniform("UiTime").set(seconds);
        } catch (Throwable ignored) {
        }
    }

    private static void onRegisterShaders(RegisterShadersEvent event) {
        shader = null;
        renderType = null;
        try {
            ShaderInstance instance = new ShaderInstance(
                    event.getResourceProvider(),
                    new ResourceLocation(AllReturnMod.MOD_ID, SHADER_NAME),
                    DefaultVertexFormat.POSITION_TEX_COLOR);
            event.registerShader(instance, loaded -> shader = loaded);
        } catch (IOException | RuntimeException exception) {
            LOGGER.error("星空 UI 着色器 star_ui 没能编译，面板会退回纯色背景", exception);
        }
    }

    private static final class States extends RenderStateShard {
        private States() {
            super(RENDER_TYPE_NAME, () -> {
            }, () -> {
            });
        }

        private static RenderType createStarRenderType() {
            return RenderType.create(
                    RENDER_TYPE_NAME,
                    DefaultVertexFormat.POSITION_TEX_COLOR,
                    VertexFormat.Mode.QUADS,
                    256,
                    false,
                    true,
                    RenderType.CompositeState.builder()
                            .setShaderState(new ShaderStateShard(() -> shader))
                            .setTransparencyState(TRANSLUCENT_TRANSPARENCY)
                            .setDepthTestState(NO_DEPTH_TEST)
                            .setCullState(NO_CULL)
                            .setWriteMaskState(COLOR_WRITE)
                            .setOutputState(MAIN_TARGET)
                            .createCompositeState(true));
        }
    }
}
