package cn.blockforge.generated.allreturn.win;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.Type;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.InsnNode;
import org.objectweb.asm.tree.JumpInsnNode;
import org.objectweb.asm.tree.LabelNode;
import org.objectweb.asm.tree.LdcInsnNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;

/**
 * Windows 原生拦截层的 Java 端。
 *
 * <p>JVMTI 的 {@code ClassFileLoadHook}（见 {@code native/windows/allreturn_jvmti.c}）
 * 把每个类文件原样丢给这里的 {@link #transform}，我们只做一件事：在方法开头
 * 插一段「开关打开就直接返回默认值」的判断，然后把改好的字节还回去。
 *
 * <p>为什么必须在原生层做，而不是普通 {@code ClassFileTransformer}：
 * <ul>
 *   <li>别的模组用 {@code MethodHandles.Lookup.defineHiddenClass} 造出来的隐藏类
 *       不会经过 {@code ClassFileTransformer}，只有 JVMTI 能看到；</li>
 *   <li>JVMTI 回调发生在类定义之前，比任何 Java 层 transformer 都早，
 *       不存在「后注册被人压住」的问题；</li>
 *   <li>事件打开前就已经加载完的类，用 {@link #retransformLoaded()} 补一遍。</li>
 * </ul>
 *
 * <p>不点名任何模组：目标集合来自扫描 {@code mods/*.jar} 得到的包名。
 */
public final class NativeHook {

    /** 开关：和普通 transformer 读同一个系统属性。 */
    private static final String FLAG = "allreturn.flag";

    private static volatile boolean registered;

    private static volatile boolean failed;

    private static volatile Set<String> packages = Collections.emptySet();

    private static volatile Set<String> classes = Collections.emptySet();

    /** 回调中防止重入（ASM 自己加载类时不要再进一次）。 */
    private static final ThreadLocal<Boolean> BUSY = ThreadLocal.withInitial(() -> Boolean.FALSE);

    private NativeHook() {
    }

    /* ------------------------------------------------------------ 装载 */

    public static synchronized boolean ensure() {
        if (registered) {
            return true;
        }
        if (failed) {
            return false;
        }
        try {
            warmUp();
            /*
             * 先用 WinBridge 把 DLL 装进来，再注册。
             *
             * 不能依赖「-agentpath 已经装过，所以 JNI 直接可用」这个假设：
             * 实测 JVM 虽然执行了 Agent_OnLoad（JVMTI 事件也确实装上了），
             * 但它不会把 agent 库的 JNI 方法表挂到 Java 的 native 解析链上，
             * 第一次 nativeRegister 会解析失败。所以这里一律先 System.load 一次
             * （Windows 对同一模块是引用计数，不会重复初始化）。
             */
            if (!WinBridge.loadLibrary()) {
                failed = true;
                return false;
            }
            registered = nativeRegister();
            if (!registered) {
                failed = true;
            }
        } catch (Throwable throwable) {
            failed = true;
            WinLog.warn("原生拦截层注册失败：" + throwable);
        }
        return registered;
    }

    /**
     * 预热：在挂上回调之前先把 ASM、目标集合都加载好。
     * 回调里第一次加载类非常危险（会重入 ClassFileLoadHook）。
     */
    private static void warmUp() {
        new ClassNode();
        new ClassReader(new byte[]{(byte) 0xCA, (byte) 0xFE, (byte) 0xBA, (byte) 0xBE,
                0, 0, 0, 52, 0, 0});
        Type.getReturnType("()V");
        LdcInsnNode probe = new LdcInsnNode("x");
        InsnList list = new InsnList();
        list.add(probe);
        list.add(new InsnNode(Opcodes.NOP));
        JumpInsnNode jump = new JumpInsnNode(Opcodes.GOTO, new LabelNode());
        MethodNode method = new MethodNode();
        method.instructions.add(jump);
        new MethodInsnNode(Opcodes.INVOKESTATIC, "java/lang/System",
                "getProperty", "(Ljava/lang/String;)Ljava/lang/String;", false);

        WinTargets.refresh();
        packages = WinTargets.packages();
        classes = WinTargets.classes();
        WinLog.info("目标集合：包 " + packages.size() + " 个，类 " + classes.size() + " 个");
    }

    /**
     * 把事件打开前就已经加载好的目标类补拦一遍。开关关着时也值得调一次——
     * 补进去的只是「判断开关」的前缀，开不开由 {@code allreturn.flag} 决定。
     */
    public static int retransformLoaded() {
        if (!registered) {
            return 0;
        }
        try {
            return nativeRetransformLoaded();
        } catch (Throwable throwable) {
            WinLog.warn("补拦已加载类失败：" + throwable);
            return 0;
        }
    }

    /* ------------------------------------------------- 原生方法声明 */

    private static native boolean nativeRegister();

    private static native int nativeRetransformLoaded();

    private static native boolean nativeInstalled();

    private static native String nativeStatus();

    /* --------------------------------------------------------- 回调 */

    /**
     * 由 JVMTI 的 {@code ClassFileLoadHook} 直接调用（JNI 静态调用）。
     *
     * @param loader    定义这个类的加载器，bootstrap 时为 {@code null}
     * @param name      内部类名，例如 {@code net/mcreator/x/Y}；隐藏类形如 {@code pkg/Type/0x...}
     * @param classData 原始类字节
     * @return 改写后的字节；{@code null} 表示原样放行
     */
    public static byte[] transform(ClassLoader loader, String name, byte[] classData) {
        if (name == null || classData == null || classData.length == 0) {
            return null;
        }
        if (!"true".equals(System.getProperty(FLAG))) {
            return null;
        }
        if (!shouldTransform(name)) {
            return null;
        }
        if (BUSY.get()) {
            return null;
        }
        BUSY.set(Boolean.TRUE);
        try {
            return inject(classData);
        } catch (Throwable throwable) {
            /* 任何问题都放行原类：拦错一个类远没有崩掉一个类危险。 */
            return null;
        } finally {
            BUSY.set(Boolean.FALSE);
        }
    }

    /**
     * 这个类要不要补拦（给 C 层的 RetransformClasses 筛选用）。
     */
    public static boolean wantsRetransform(String internalName) {
        if (internalName == null) {
            return false;
        }
        return shouldTransform(internalName);
    }

    /** 这个类要不要动：看它的包是不是来自 mods 里的别的模组。 */
    static boolean shouldTransform(String internalName) {
        String base = internalName;
        int hidden = base.indexOf("/0x");
        if (hidden > 0) {
            /* 隐藏类名形如 pkg/Type/0x0000000601001000，去掉后缀再判断 */
            base = base.substring(0, hidden);
        }
        if (classes.contains(base)) {
            return true;
        }
        int slash = base.lastIndexOf('/');
        if (slash <= 0) {
            return false;
        }
        return packages.contains(base.substring(0, slash));
    }

    private static byte[] inject(byte[] classData) {
        ClassNode node = new ClassNode();
        new ClassReader(classData).accept(node, 0);

        if ((node.access & (Opcodes.ACC_INTERFACE | Opcodes.ACC_ABSTRACT | Opcodes.ACC_RECORD)) != 0) {
            return null;
        }
        if ("java/lang/Record".equals(node.superName)) {
            return null;
        }

        boolean touched = false;
        for (MethodNode method : node.methods) {
            if ("<init>".equals(method.name) || "<clinit>".equals(method.name)) {
                continue;
            }
            if ((method.access & (Opcodes.ACC_ABSTRACT | Opcodes.ACC_NATIVE)) != 0) {
                continue;
            }
            injectMethod(method);
            touched = true;
        }
        if (!touched) {
            return null;
        }

        ClassWriter writer = new ClassWriter(ClassWriter.COMPUTE_FRAMES) {
            @Override
            protected String getCommonSuperClass(String type1, String type2) {
                /* 不加载任何类：合并点一律退到 Object，验证器可以接受保守结果。 */
                return "java/lang/Object";
            }
        };
        node.accept(writer);
        return writer.toByteArray();
    }

    private static void injectMethod(MethodNode method) {
        Type returnType = Type.getReturnType(method.desc);
        LabelNode original = new LabelNode();
        InsnList check = new InsnList();
        check.add(new LdcInsnNode("true"));
        check.add(new LdcInsnNode(FLAG));
        check.add(new MethodInsnNode(Opcodes.INVOKESTATIC, "java/lang/System",
                "getProperty", "(Ljava/lang/String;)Ljava/lang/String;", false));
        check.add(new MethodInsnNode(Opcodes.INVOKEVIRTUAL, "java/lang/String",
                "equals", "(Ljava/lang/Object;)Z", false));
        check.add(new JumpInsnNode(Opcodes.IFEQ, original));
        generateDefaultReturn(check, returnType);
        check.add(original);
        method.instructions.insert(check);
    }

    private static void generateDefaultReturn(InsnList list, Type returnType) {
        switch (returnType.getSort()) {
            case Type.VOID -> list.add(new InsnNode(Opcodes.RETURN));
            case Type.BOOLEAN, Type.BYTE, Type.SHORT, Type.CHAR, Type.INT -> {
                list.add(new InsnNode(Opcodes.ICONST_0));
                list.add(new InsnNode(Opcodes.IRETURN));
            }
            case Type.LONG -> {
                list.add(new InsnNode(Opcodes.LCONST_0));
                list.add(new InsnNode(Opcodes.LRETURN));
            }
            case Type.FLOAT -> {
                list.add(new InsnNode(Opcodes.FCONST_0));
                list.add(new InsnNode(Opcodes.FRETURN));
            }
            case Type.DOUBLE -> {
                list.add(new InsnNode(Opcodes.DCONST_0));
                list.add(new InsnNode(Opcodes.DRETURN));
            }
            default -> {
                list.add(new InsnNode(Opcodes.ACONST_NULL));
                list.add(new InsnNode(Opcodes.ARETURN));
            }
        }
    }

    /* --------------------------------------------------------- 状态 */

    public static boolean isRegistered() {
        return registered;
    }

    public static boolean isInstalled() {
        if (!registered) {
            return false;
        }
        try {
            return nativeInstalled();
        } catch (Throwable throwable) {
            return false;
        }
    }

    public static String describe() {
        if (failed) {
            return "原生拦截：不可用（DLL 没加载或注册失败）";
        }
        if (!registered) {
            return "原生拦截：未启用";
        }
        String raw;
        try {
            raw = nativeStatus();
        } catch (Throwable throwable) {
            raw = "status-error " + throwable;
        }
        return "原生拦截：" + raw + " | 目标包 " + packages.size()
                + " 个 / 目标类 " + classes.size() + " 个";
    }

    /** 刷新目标集合（新装模组后可以手动调）。 */
    public static void refreshTargets() {
        WinTargets.refresh();
        packages = WinTargets.packages();
        classes = WinTargets.classes();
    }

    /**
     * 测试用：把某个包临时加进目标集合。
     * 自测里用不到真实的 mods 目录，靠这个让样本类能命中。
     */
    static void addTargetForTest(String pkg) {
        Set<String> merged = new HashSet<>(packages);
        merged.add(pkg);
        packages = Collections.unmodifiableSet(merged);
    }

    /**
     * 检查某个内部类名会不会被拦（不改字节，只看目标判断），
     * 给自测和 /allreturn native 诊断用。
     */
    public static boolean intercepts(String internalName) {
        return shouldTransform(internalName);
    }

    static Set<String> targetPackages() {
        return new HashSet<>(packages);
    }

    static Set<String> targetClasses() {
        return new HashSet<>(classes);
    }
}
