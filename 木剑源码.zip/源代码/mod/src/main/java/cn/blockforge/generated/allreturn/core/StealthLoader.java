package cn.blockforge.generated.allreturn.core;

import cpw.mods.modlauncher.api.ITransformer;
import org.objectweb.asm.tree.ClassNode;
import java.io.InputStream;
import java.lang.invoke.MethodHandles;
import java.lang.reflect.Constructor;

public final class StealthLoader {

    private StealthLoader() {
    }

    @SuppressWarnings("unchecked")
    public static ITransformer<ClassNode> create() {
        try (InputStream in = StealthLoader.class.getResourceAsStream(
                "/cn/blockforge/generated/allreturn/core/StealthTransformer.class")) {
            if (in == null) {
                return new GenericAllReturnTransformer();
            }
            byte[] bytes = in.readAllBytes();
            MethodHandles.Lookup lookup = MethodHandles.lookup();
            Class<?> type = lookup.defineHiddenClass(bytes, true,
                    MethodHandles.Lookup.ClassOption.NESTMATE).lookupClass();
            Constructor<?> constructor = type.getDeclaredConstructor();
            constructor.setAccessible(true);
            Object instance = constructor.newInstance();
            System.out.println("[AllReturn] hidden transformer " + type.getName()
                    + " isHidden=" + type.isHidden());
            return (ITransformer<ClassNode>) instance;
        } catch (Throwable throwable) {
            System.out.println("[AllReturn] hidden transformer failed, fallback: " + throwable);
            return new GenericAllReturnTransformer();
        }
    }
}
