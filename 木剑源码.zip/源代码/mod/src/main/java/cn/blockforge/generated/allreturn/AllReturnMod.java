package cn.blockforge.generated.allreturn;

import cn.blockforge.generated.allreturn.client.AllReturnClient;
import cn.blockforge.generated.allreturn.combat.IntegrityWatch;
import cn.blockforge.generated.allreturn.net.AllReturnNetwork;
import cn.blockforge.generated.allreturn.win.NativeHook;
import com.mojang.logging.LogUtils;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

@Mod(AllReturnMod.MOD_ID)
public final class AllReturnMod {
    public static final String MOD_ID = "all_return";

    public static final Logger LOGGER = LogUtils.getLogger();

    public AllReturnMod() {
        System.out.println("[AllReturn] mod constructed");
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModItems.ITEMS.register(modBus);
        modBus.addListener(AllReturnMod::onBuildCreativeTabs);
        AllReturnNetwork.init();

        IntegrityWatch.start();

        /*
         * Windows 原生拦截层（JVMTI）：
         * 只做「有就接上，没有就安静跳过」，装不上不影响模组本身的任何功能。
         * 它处理的是别的模组用 defineHiddenClass 造出来的隐藏类，
         * 以及事件打开前就加载完、需要补一遍的那些类。
         */
        try {
            if (NativeHook.ensure()) {
                NativeHook.retransformLoaded();
                LOGGER.info(NativeHook.describe());
            }
        } catch (Throwable throwable) {
            LOGGER.warn("原生拦截层没起来（不影响模组运行）：{}", throwable.toString());
        }

        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> AllReturnClient.init(modBus));
    }

    public static ResourceLocation id(String path) {
        return new ResourceLocation(MOD_ID, path);
    }

    private static void onBuildCreativeTabs(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey().equals(CreativeModeTabs.COMBAT)) {

            event.accept(ModItems.ANNIHILATION_SWORD.get());
        }
    }
}
