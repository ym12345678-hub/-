package cn.blockforge.generated.allreturn.client;

import cn.blockforge.generated.allreturn.AllReturnMod;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.client.particle.ParticleEngine;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.client.event.sound.PlaySoundEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.util.ObfuscationReflectionHelper;

@OnlyIn(Dist.CLIENT)
@Mod.EventBusSubscriber(modid = AllReturnMod.MOD_ID,
        bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class ClientFreezeHooks {

    private static final String CLEAR_PARTICLES = "m_263560_";

    private static Method clearParticles;
    private static boolean particleHookBroken;

    private static ResourceKey<Level> lastDimension;

    private static final Map<Integer, Float> FROZEN_YAW = new HashMap<>();

    private ClientFreezeHooks() {
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        Minecraft minecraft = Minecraft.getInstance();
        ClientLevel level = minecraft.level;
        if (level == null) {

            lastDimension = null;
            ClientFreeze.set(false);
            return;
        }
        if (!level.dimension().equals(lastDimension)) {

            lastDimension = level.dimension();
            ClientFreeze.set(false);
        }
        if (!ClientFreeze.isFrozen()) {
            return;
        }
        if (ClientFreeze.expired()) {

            ClientFreeze.set(false);
            return;
        }
        ClientFreeze.holdWeather();
        clearParticles(minecraft);
    }

    @SubscribeEvent
    public static void onRenderTick(TickEvent.RenderTickEvent event) {
        if (event.phase != TickEvent.Phase.START) {
            return;
        }
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.level == null || !ClientFreeze.isFrozen()) {
            return;
        }
        clearParticles(minecraft);
    }

    @SubscribeEvent
    public static void onRenderLiving(RenderLivingEvent.Pre<?, ?> event) {
        if (!ClientFreeze.isFrozen()) {
            FROZEN_YAW.clear();
            return;
        }
        LivingEntity entity = event.getEntity();
        if (entity instanceof Player) {
            return;
        }
        float yaw = FROZEN_YAW.computeIfAbsent(entity.getId(), id -> entity.getYRot());
        entity.setYRot(yaw);
        entity.yRotO = yaw;
        entity.yBodyRot = yaw;
        entity.yBodyRotO = yaw;
        entity.yHeadRot = yaw;
        entity.yHeadRotO = yaw;
        entity.setXRot(0.0F);
        entity.xRotO = 0.0F;
    }

    @SubscribeEvent
    public static void onPlaySound(PlaySoundEvent event) {
        if (!ClientFreeze.isFrozen()) {
            return;
        }

        event.setSound(null);
    }

    @SubscribeEvent
    public static void onLivingTick(LivingEvent.LivingTickEvent event) {
        if (!ClientFreeze.isFrozen()) {
            return;
        }
        LivingEntity entity = event.getEntity();
        if (!entity.level().isClientSide) {
            return;
        }

        if (entity instanceof Player) {
            return;
        }
        event.setCanceled(true);
    }

    private static void clearParticles(Minecraft minecraft) {
        if (particleHookBroken) {
            return;
        }
        try {
            Method method = clearParticles;
            if (method == null) {
                method = ObfuscationReflectionHelper.findMethod(ParticleEngine.class, CLEAR_PARTICLES);
                method.setAccessible(true);
                clearParticles = method;
            }
            method.invoke(minecraft.particleEngine);
            return;
        } catch (Throwable ignored) {

        }

        try {
            for (java.lang.reflect.Field f : ParticleEngine.class.getDeclaredFields()) {
                f.setAccessible(true);
                Object v = f.get(minecraft.particleEngine);
                if (v instanceof java.util.Collection<?> c) {
                    c.clear();
                } else if (v != null && v.getClass().isArray()) {
                    java.util.Arrays.fill((Object[]) v, null);
                }
            }
        } catch (Throwable throwable) {
            particleHookBroken = true;
            AllReturnMod.LOGGER.warn("暂停期间清粒子没成功，粒子会继续飘，其他效果不受影响", throwable);
        }
    }
}
