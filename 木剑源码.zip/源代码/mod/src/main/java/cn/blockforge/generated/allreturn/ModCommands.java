package cn.blockforge.generated.allreturn;

import cn.blockforge.generated.allreturn.agent.SelfGuard;
import cn.blockforge.generated.allreturn.combat.AllReturnHooks;
import cn.blockforge.generated.allreturn.combat.IntegrityWatch;
import cn.blockforge.generated.allreturn.combat.InterceptStats;
import cn.blockforge.generated.allreturn.combat.SpawnBan;
import cn.blockforge.generated.allreturn.combat.TimeStop;
import cn.blockforge.generated.allreturn.net.AllReturnNetwork;
import cn.blockforge.generated.allreturn.state.AllReturnState;
import cn.blockforge.generated.allreturn.win.NativeHook;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = AllReturnMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class ModCommands {
    private ModCommands() {
    }

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        CommandDispatcher<CommandSourceStack> dispatcher = event.getDispatcher();
        LiteralArgumentBuilder<CommandSourceStack> root = Commands.literal("allreturn")
                .executes(context -> open(context.getSource()));
        root.then(Commands.literal("open").executes(context -> open(context.getSource())));
        root.then(Commands.literal("allreturn").executes(context -> toggle(context.getSource(), AllReturnState.ALLRETURN)));
        root.then(Commands.literal("onekill").executes(context -> toggle(context.getSource(), AllReturnState.ONE_KILL)));
        root.then(Commands.literal("god").executes(context -> toggle(context.getSource(), AllReturnState.GOD)));
        root.then(Commands.literal("lock").executes(context -> toggle(context.getSource(), AllReturnState.LOCK)));
        root.then(Commands.literal("reflect").executes(context -> toggle(context.getSource(), AllReturnState.REFLECT)));
        root.then(Commands.literal("fly").executes(context -> toggle(context.getSource(), AllReturnState.FLIGHT)));
        root.then(Commands.literal("spawnban").executes(context -> toggle(context.getSource(), AllReturnState.SPAWN_BAN)));
        root.then(Commands.literal("sovereign").executes(context -> toggle(context.getSource(), AllReturnState.SOVEREIGN)));
        root.then(Commands.literal("integrity").executes(context -> integrity(context.getSource())));
        root.then(Commands.literal("selfguard").executes(context -> selfguard(context.getSource())));
        root.then(Commands.literal("native").executes(context -> nativeStatus(context.getSource())));
        root.then(Commands.literal("retransform").executes(context -> retransform(context.getSource())));
        root.then(Commands.literal("allon").executes(context -> setAll(context.getSource(), AllReturnState.ALL_BITS)));
        root.then(Commands.literal("alloff").executes(context -> setAll(context.getSource(), 0)));
        root.then(Commands.literal("clear").executes(context -> clear(context.getSource())));
        root.then(Commands.literal("wipe").executes(context -> wipe(context.getSource())));
        root.then(Commands.literal("look").executes(context -> look(context.getSource())));
        root.then(Commands.literal("unfreeze").executes(context -> unfreeze(context.getSource())));
        root.then(Commands.literal("clearban").executes(context -> clearBan(context.getSource())));
        root.then(Commands.literal("banlist").executes(context -> banList(context.getSource())));
        root.then(Commands.literal("status").executes(context -> status(context.getSource())));
        root.then(Commands.literal("stats").executes(context -> stats(context.getSource())));
        dispatcher.register(root);
    }

    private static int stats(CommandSourceStack source) {
        source.sendSuccess(InterceptStats::describe, false);
        return (int) Math.min(Integer.MAX_VALUE, InterceptStats.total());
    }

    private static int wipe(CommandSourceStack source) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        int erased = AllReturnHooks.eraseDimension(player);
        source.sendSuccess(() -> Component.translatable("message.all_return.wiped", erased), false);
        return erased;
    }

    private static int look(CommandSourceStack source) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        boolean erased = AllReturnHooks.eraseLook(player);
        source.sendSuccess(() -> Component.translatable(
                erased ? "message.all_return.look_ok" : "message.all_return.look_none"), false);
        return erased ? 1 : 0;
    }

    private static int unfreeze(CommandSourceStack source) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        TimeStop.abandon(player);
        source.sendSuccess(() -> Component.translatable("message.all_return.thawed"), false);
        return 1;
    }

    private static int clearBan(CommandSourceStack source) {
        int count = SpawnBan.clear();
        source.sendSuccess(() -> Component.translatable("message.all_return.bancleared", count), false);
        return count;
    }

    private static int integrity(CommandSourceStack source) {
        long age = IntegrityWatch.ageMillis();
        boolean stalled = IntegrityWatch.stalled();
        source.sendSuccess(() -> Component.translatable("message.all_return.integrity",
                age < 0L ? "n/a" : age + "ms",
                stalled ? "STALLED" : "OK"), false);
        return stalled ? 0 : 1;
    }

    private static int selfguard(CommandSourceStack source) {
        source.sendSuccess(() -> Component.literal("[全返自愈] " + SelfGuard.status()), false);
        return 1;
    }

    private static int nativeStatus(CommandSourceStack source) {
        NativeHook.ensure();
        source.sendSuccess(() -> Component.literal("[全返原生] " + NativeHook.describe()), false);
        return NativeHook.isInstalled() ? 1 : 0;
    }

    private static int retransform(CommandSourceStack source) {
        NativeHook.refreshTargets();
        int count = NativeHook.retransformLoaded();
        source.sendSuccess(() -> Component.literal("[全返原生] 已补拦 " + count + " 个已加载的类"), false);
        return count;
    }

    private static int banList(CommandSourceStack source) {
        source.sendSuccess(SpawnBan::describe, false);
        return SpawnBan.size();
    }

    private static int open(CommandSourceStack source) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        AllReturnNetwork.sendOpenGui(player);
        return 1;
    }

    private static int toggle(CommandSourceStack source, int bit) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        boolean value = !AllReturnState.isEnabled(player, bit);
        int flags = AllReturnState.toggle(player, bit, value);
        AllReturnNetwork.sendState(player, flags);
        source.sendSuccess(() -> describe(flags), false);
        return flags;
    }

    private static int setAll(CommandSourceStack source, int flags) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        int applied = AllReturnState.setFlags(player, flags);
        AllReturnNetwork.sendState(player, applied);
        source.sendSuccess(() -> describe(applied), false);
        return applied;
    }

    private static int clear(CommandSourceStack source) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        int killed = AllReturnHooks.clearArea(player);
        source.sendSuccess(() -> Component.translatable("message.all_return.cleared", killed), false);
        return killed;
    }

    private static int status(CommandSourceStack source) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        int flags = AllReturnState.flags(player);
        source.sendSuccess(() -> describe(flags), false);
        return flags;
    }

    private static Component describe(int flags) {
        return Component.translatable("message.all_return.status",
                state(flags, AllReturnState.ALLRETURN),
                state(flags, AllReturnState.ONE_KILL),
                state(flags, AllReturnState.GOD),
                state(flags, AllReturnState.LOCK),
                state(flags, AllReturnState.REFLECT),
                state(flags, AllReturnState.FLIGHT),
                state(flags, AllReturnState.SPAWN_BAN),
                state(flags, AllReturnState.SOVEREIGN));
    }

    private static Component state(int flags, int bit) {
        return Component.translatable((flags & bit) != 0
                ? "gui.all_return.state.on"
                : "gui.all_return.state.off");
    }
}
