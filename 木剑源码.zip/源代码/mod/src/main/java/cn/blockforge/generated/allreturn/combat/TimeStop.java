package cn.blockforge.generated.allreturn.combat;

import cn.blockforge.generated.allreturn.AllReturnMod;
import cn.blockforge.generated.allreturn.item.AnnihilationSwordItem;
import cn.blockforge.generated.allreturn.net.AllReturnNetwork;
import cn.blockforge.generated.allreturn.state.AllReturnState;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

public final class TimeStop {

    public static final int HOLD_TICKS = 10;

    private static final int MAX_HOLD_TICKS = 20 * 60;
    private static final double STILL = 1.0E-6D;

    private static final Map<UUID, Hold> HOLDS = new ConcurrentHashMap<>();

    private static final Map<ResourceKey<Level>, UUID> FROZEN = new ConcurrentHashMap<>();

    private static final Map<ResourceKey<Level>, Map<UUID, Pose>> POSES = new ConcurrentHashMap<>();

    private static final Map<ResourceKey<Level>, Long> DAYTIME = new ConcurrentHashMap<>();

    private TimeStop() {
    }

    private record Hold(ResourceKey<Level> dimension, long startTick) {
    }

    private record Pose(Vec3 position, float yRot, float xRot, Vec3 velocity, boolean noGravity,
                         int hurtTime, int deathTime, int invulnerableTime, float fallDistance) {
        static Pose of(Entity entity) {
            int hurt = 0, death = 0, invul = 0;
            float fall = 0.0F;
            if (entity instanceof LivingEntity living) {
                hurt = living.hurtTime;
                death = living.deathTime;
                invul = living.invulnerableTime;
            }
            try { fall = entity.fallDistance; } catch (Throwable ignored) { }
            return new Pose(entity.position(), entity.getYRot(), entity.getXRot(),
                    entity.getDeltaMovement(), entity.isNoGravity(), hurt, death, invul, fall);
        }
    }

    public static void beginHold(ServerPlayer player) {
        HOLDS.put(player.getUUID(), new Hold(player.level().dimension(), player.level().getGameTime()));
    }

    public static boolean endHold(ServerPlayer player) {
        HOLDS.remove(player.getUUID());
        return player.level() instanceof ServerLevel level && thaw(level);
    }

    public static void cancelHold(ServerPlayer player) {
        HOLDS.remove(player.getUUID());
    }

    public static boolean isFrozen(Level level) {
        return FROZEN.containsKey(level.dimension());
    }

    public static boolean isCaster(Entity entity) {
        UUID caster = FROZEN.get(entity.level().dimension());
        return caster != null && caster.equals(entity.getUUID());
    }

    public static boolean freezes(Entity entity) {
        return entity != null
                && !(entity instanceof Player)
                && isFrozen(entity.level())
                && !isCaster(entity);
    }

    public static void playerGone(ServerPlayer player) {
        abandon(player);
    }

    public static void abandon(ServerPlayer player) {
        cancelHold(player);
        if (player.level() instanceof ServerLevel level && isCaster(player)) {
            thaw(level);
        }
    }

    public static void tickServer(MinecraftServer server) {
        long gameTime = server.overworld().getGameTime();
        for (Map.Entry<UUID, Hold> entry : new ArrayList<>(HOLDS.entrySet())) {
            ServerPlayer player = server.getPlayerList().getPlayer(entry.getKey());
            if (player == null) {
                HOLDS.remove(entry.getKey());
                continue;
            }
            if (!(player.level() instanceof ServerLevel level)) {
                continue;
            }
            Hold hold = entry.getValue();
            if (!level.dimension().equals(hold.dimension())) {

                HOLDS.remove(entry.getKey());
                continue;
            }
            long elapsed = gameTime - hold.startTick();
            if (elapsed >= MAX_HOLD_TICKS) {
                HOLDS.remove(entry.getKey());
                thaw(level);
                continue;
            }
            if (elapsed >= HOLD_TICKS && !isFrozen(level)) {
                if (!(player.getMainHandItem().getItem() instanceof AnnihilationSwordItem)) {
                    continue;
                }
                freeze(level, player);
            }
        }

        for (Map.Entry<ResourceKey<Level>, UUID> entry : new ArrayList<>(FROZEN.entrySet())) {
            ServerLevel level = server.getLevel(entry.getKey());
            if (level == null) {
                FROZEN.remove(entry.getKey());
                continue;
            }
            ServerPlayer caster = server.getPlayerList().getPlayer(entry.getValue());
            if (caster == null || caster.level() != level) {
                thaw(level);
                continue;
            }

            if (!(caster.getMainHandItem().getItem() instanceof AnnihilationSwordItem)
                    || !AllReturnState.isEnabled(caster, AllReturnState.ALLRETURN)) {
                HOLDS.remove(caster.getUUID());
                thaw(level);
                continue;
            }

            Long frozenDayTime = DAYTIME.get(entry.getKey());
            if (frozenDayTime != null) {
                level.setDayTime(frozenDayTime);
            }
            holdStill(level, entry.getValue());
        }
    }

    private static void holdStill(ServerLevel level, UUID caster) {
        Map<UUID, Pose> poses = POSES.computeIfAbsent(level.dimension(), key -> new HashMap<>());
        boolean any = false;
        for (Entity entity : level.getAllEntities()) {
            if (entity instanceof Player || entity.getUUID().equals(caster)) {
                continue;
            }
            any = true;
            try {
                Pose pose = poses.computeIfAbsent(entity.getUUID(), id -> Pose.of(entity));
                if (!entity.isNoGravity()) {
                    entity.setNoGravity(true);
                }
                if (entity.getDeltaMovement().lengthSqr() > 0.0D) {
                    entity.setDeltaMovement(Vec3.ZERO);
                }
                if (!entity.position().closerThan(pose.position(), STILL)) {
                    entity.setPos(pose.position().x, pose.position().y, pose.position().z);
                }
                if (entity.getYRot() != pose.yRot() || entity.getXRot() != pose.xRot()) {
                    entity.setYRot(pose.yRot());
                    entity.setXRot(pose.xRot());
                }

                if (entity instanceof LivingEntity living) {
                    living.hurtTime = 0;
                    living.deathTime = 0;
                    living.invulnerableTime = 0;
                }
                try { entity.fallDistance = 0.0F; } catch (Throwable ignored) { }
            } catch (RuntimeException exception) {
                InterceptStats.blocked();
                AllReturnMod.LOGGER.debug("暂停期间定格某个实体失败，这个实体这一帧保持原样", exception);
            }
        }

        if (any) {
            InterceptStats.frozen();
        }
    }

    public static void freeze(ServerLevel level, ServerPlayer caster) {
        FROZEN.put(level.dimension(), caster.getUUID());
        POSES.put(level.dimension(), new HashMap<>());
        DAYTIME.put(level.dimension(), level.getDayTime());
        AllReturnNetwork.sendFreeze(level, true);
        level.playSound(null, caster.blockPosition(), SoundEvents.BEACON_ACTIVATE,
                SoundSource.PLAYERS, 1.0F, 0.5F);
        Component message = Component.translatable("message.all_return.frozen", caster.getDisplayName());
        for (ServerPlayer other : level.players()) {
            other.displayClientMessage(message, true);
        }
    }

    public static boolean thaw(Level level) {
        UUID caster = FROZEN.remove(level.dimension());
        DAYTIME.remove(level.dimension());
        Map<UUID, Pose> poses = POSES.remove(level.dimension());
        if (caster == null) {
            return false;
        }
        if (level instanceof ServerLevel serverLevel) {
            if (poses != null) {

                for (Entity entity : serverLevel.getAllEntities()) {
                    Pose pose = poses.get(entity.getUUID());
                    if (pose == null) {
                        continue;
                    }
                    try {
                        entity.setNoGravity(pose.noGravity());
                        entity.setDeltaMovement(pose.velocity());
                        if (entity instanceof LivingEntity living) {
                            living.hurtTime = pose.hurtTime();
                            living.deathTime = pose.deathTime();
                            living.invulnerableTime = pose.invulnerableTime();
                        }
                        try { entity.fallDistance = pose.fallDistance(); } catch (Throwable ignored) { }
                    } catch (RuntimeException exception) {
                        AllReturnMod.LOGGER.debug("解冻时恢复某个实体失败，这个实体保持静止", exception);
                    }
                }
            }
            AllReturnNetwork.sendFreeze(serverLevel, false);
            serverLevel.playSound(null, serverLevel.getSharedSpawnPos(), SoundEvents.BEACON_DEACTIVATE,
                    SoundSource.PLAYERS, 0.6F, 0.7F);
            Component message = Component.translatable("message.all_return.thawed");
            for (ServerPlayer other : serverLevel.players()) {
                other.displayClientMessage(message, true);
            }
        }
        return true;
    }
}
