package cn.blockforge.generated.allreturn.item;

import cn.blockforge.generated.allreturn.combat.AllReturnHooks;
import cn.blockforge.generated.allreturn.net.AllReturnNetwork;
import cn.blockforge.generated.allreturn.util.RainbowText;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

public class AnnihilationSwordItem extends SwordItem implements ModGear {

    private static final float ATTACK_SPEED = -2.4F;

    public AnnihilationSwordItem() {
        super(Tiers.NETHERITE, 997, ATTACK_SPEED,
                new Item.Properties());
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!player.isShiftKeyDown()) {
            return InteractionResultHolder.pass(stack);
        }
        if (!level.isClientSide && player instanceof ServerPlayer serverPlayer) {
            AllReturnNetwork.sendOpenGui(serverPlayer);
        }
        return InteractionResultHolder.success(stack);
    }

    @Override
    public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        if (attacker instanceof Player player) {
            AllReturnHooks.onGearAttack(player, target, stack);
        }
        return super.hurtEnemy(stack, target, attacker);
    }

    @Override
    public Component getName(ItemStack stack) {
        return RainbowText.of("木剑");
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {

        tooltip.add(RainbowText.of(Component.translatable("tooltip.all_return.artifact")));
        tooltip.add(Component.translatable("tooltip.all_return.look").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.all_return.wipe").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.all_return.stop").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.all_return.open").withStyle(ChatFormatting.DARK_GRAY));
        tooltip.add(Component.translatable("tooltip.all_return.unbreak").withStyle(ChatFormatting.DARK_GRAY));
    }
}
