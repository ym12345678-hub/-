package cn.blockforge.generated.allreturn.agent;

import java.lang.instrument.Instrumentation;

public final class AllReturnAgent {
    private AllReturnAgent() {
    }

    public static void premain(String args, Instrumentation instrumentation) {
        SelfGuard.install(instrumentation, "premain");
    }

    public static void agentmain(String args, Instrumentation instrumentation) {
        SelfGuard.install(instrumentation, "agentmain");
    }
}
