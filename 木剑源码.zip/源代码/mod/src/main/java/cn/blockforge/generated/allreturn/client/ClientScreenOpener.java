package cn.blockforge.generated.allreturn.client;

import cn.blockforge.generated.allreturn.state.AllReturnState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public final class ClientScreenOpener {

    private static int flags = AllReturnState.DEFAULTS;

    private ClientScreenOpener() {
    }

    public static int flags() {
        return flags;
    }

    public static void open(int flags) {
        ClientScreenOpener.flags = flags;
        Minecraft.getInstance().setScreen(new AllReturnScreen(flags));
    }

    public static void sync(int flags) {
        ClientScreenOpener.flags = flags;
        Screen screen = Minecraft.getInstance().screen;
        if (screen instanceof AllReturnScreen allReturnScreen) {
            allReturnScreen.applyFlags(flags);
        }
    }
}
