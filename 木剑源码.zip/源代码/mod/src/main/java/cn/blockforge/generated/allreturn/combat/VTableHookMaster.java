package cn.blockforge.generated.allreturn.combat;

import cn.blockforge.generated.allreturn.AllReturnMod;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public final class VTableHookMaster {

    private VTableHookMaster() {
    }

    public static boolean available() {
        return UnsafeMaster.available() && UnsafeMaster.hardcore();
    }

    public static boolean hookMethod(Class<?> targetClass, String methodName,
                                    Class<?>[] paramTypes, Method replacement) {
        if (!available() || targetClass == null || methodName == null || replacement == null) {
            return false;
        }
        try {
            Method targetMethod = targetClass.getDeclaredMethod(methodName, paramTypes);
            long klassPtr = getKlassPointer(targetClass);
            if (klassPtr == 0L) {
                return false;
            }
            int vtableIndex = findVTableIndex(klassPtr, targetMethod);
            if (vtableIndex < 0) {
                return false;
            }
            long replacementAddr = getMethodAddress(replacement);
            if (replacementAddr == 0L) {
                return false;
            }
            setVTableEntry(klassPtr, vtableIndex, replacementAddr);
            AllReturnMod.LOGGER.info("VTableHook: {}#{} 已 hook", targetClass.getSimpleName(), methodName);
            return true;
        } catch (Throwable throwable) {
            AllReturnMod.LOGGER.debug("VTableHook 失败", throwable);
            InterceptStats.blocked();
            return false;
        }
    }

    private static long getKlassPointer(Class<?> clazz) {
        try {

            for (Field field : Class.class.getDeclaredFields()) {
                if (field.getType() == long.class && !java.lang.reflect.Modifier.isStatic(field.getModifiers())) {
                    field.setAccessible(true);
                    long value = field.getLong(clazz);
                    if (value != 0L) {
                        return value;
                    }
                }
            }
        } catch (Throwable throwable) {
            AllReturnMod.LOGGER.debug("取 Klass 指针失败", throwable);
        }
        return 0L;
    }

    private static int findVTableIndex(long klassPtr, Method method) {
        try {
            int vtableLen = UnsafeMaster.readRawInt(klassPtr + 0x40);
            if (vtableLen <= 0 || vtableLen > 4096) {
                return -1;
            }
            for (int i = 0; i < vtableLen; i++) {
                long entry = UnsafeMaster.readRawLong(klassPtr + 0x48 + (long) i * 8L);
                if (entry == getMethodAddress(method)) {
                    return i;
                }
            }
        } catch (Throwable throwable) {
            AllReturnMod.LOGGER.debug("查找 vtable 槽位失败", throwable);
        }
        return -1;
    }

    private static void setVTableEntry(long klassPtr, int index, long value) {
        UnsafeMaster.writeRawLong(klassPtr + 0x48 + (long) index * 8L, value);
    }

    private static long getMethodAddress(Method method) {
        String[] candidates = {"fromCompiledCode", "methodHandle", "entryPoint"};
        for (String name : candidates) {
            try {
                Field field = Method.class.getDeclaredField(name);
                field.setAccessible(true);
                if (field.getType() == long.class) {
                    long value = field.getLong(method);
                    if (value != 0L) {
                        return value;
                    }
                }
            } catch (NoSuchFieldException ignored) {

            } catch (Throwable throwable) {
                AllReturnMod.LOGGER.debug("取方法地址失败", throwable);
            }
        }
        return 0L;
    }
}
