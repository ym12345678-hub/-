package cn.blockforge.generated.allreturn.combat;

import cn.blockforge.generated.allreturn.AllReturnMod;
import cn.blockforge.generated.allreturn.state.AllReturnState;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.GameType;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

public final class AllReturnHooks {

    public static final float OVERKILL = Float.MAX_VALUE;

    public static final float BASE_FORCE_DAMAGE = 1000.0F;

    public static final double CLEAR_RADIUS = 32.0D;

    public static final double LOOK_RANGE = 64.0D;

    public static final double SWEEP_RADIUS = 2.5D;

    private static final int SWEEP_LIMIT = 64;

    private static final ThreadLocal<Boolean> REFLECTING = ThreadLocal.withInitial(() -> Boolean.FALSE);

    private AllReturnHooks() {
    }

    public static Player attackerOf(DamageSource source) {
        if (source == null) {
            return null;
        }
        if (source.getEntity() instanceof Player player) {
            return player;
        }
        return null;
    }

    public static boolean onGearAttack(Player player, LivingEntity target, ItemStack held) {
        if (player.level().isClientSide || target == player || !target.isAlive()) {
            return false;
        }
        if (!AllReturnState.hasGear(player)) {
            return false;
        }
        if (!AllReturnState.isEnabled(player, AllReturnState.ALLRETURN)) {
            return false;
        }
        if (!AllReturnState.isEnabled(player, AllReturnState.ONE_KILL)) {
            return false;
        }

        if (AllReturnState.protectedFromPurge(target)) {
            return false;
        }
        if (!forceKill(player, target)) {
            return false;
        }
        if (player instanceof ServerPlayer serverPlayer && serverPlayer.tickCount % 5 == 0) {
            serverPlayer.displayClientMessage(Component.literal("全返 · 必杀"), true);
        }
        if (!held.isEmpty() && held.getItem() instanceof SwordItem) {
            sweep(player, target);
        }
        return true;
    }

    public static boolean forceKill(Player attacker, LivingEntity target) {
        return kill(attacker, target, true);
    }

    private static boolean kill(Player attacker, LivingEntity target, boolean burst) {
        if (target.level().isClientSide || !target.isAlive()) {
            return false;
        }

        if (target instanceof ServerPlayer victim && (victim.isCreative() || victim.isSpectator())) {
            step(() -> victim.setGameMode(GameType.SURVIVAL));
        }

        if (AllReturnState.protectedFromPurge(target)) {
            return false;
        }
        AllReturnState.suppress(target);

        if (target instanceof ServerPlayer serverPlayer) {
            FinalSay.mark(serverPlayer);
        }
        enforceRemoval(target, attacker);
        InterceptStats.killed();

        ErasureWatch.watch(target);
        if (burst) {
            playBurst(attacker.level(), target);
        }
        return true;
    }

    public static boolean enforceRemoval(Entity target) {
        return enforceRemoval(target, null);
    }

    public static boolean enforceRemoval(Entity target, Player attacker) {
        if (target == null || target.isRemoved()) {
            return false;
        }

        if (AllReturnState.protectedFromPurge(target)) {
            return false;
        }

        step(() -> target.setInvulnerable(false));
        if (target instanceof LivingEntity living) {
            step(() -> living.setAbsorptionAmount(0.0F));
            step(() -> living.removeAllEffects());
            step(() -> living.invulnerableTime = 0);
            step(() -> living.setDeltaMovement(Vec3.ZERO));

            if (!(living instanceof Player)) {
                step(() -> {
                    AttributeInstance maxHealth = living.getAttribute(Attributes.MAX_HEALTH);
                    if (maxHealth != null) {
                        maxHealth.setBaseValue(0.0D);
                    }
                });
            }
            step(() -> ReflectPurge.forceSetHealth(living, 0.0F));
            step(() -> ReflectPurge.forceDead(living, true));
            DamageSource hit = attacker == null
                    ? living.damageSources().genericKill()
                    : attacker.damageSources().playerAttack(attacker);
            step(() -> living.hurt(hit, OVERKILL));

            if (living.isAlive()) {
                step(() -> living.hurt(living.damageSources().genericKill(), OVERKILL));
            }

            if (living.isAlive()) {
                step(() -> ReflectPurge.forceSetHealth(living, 0.0F));
                step(() -> ReflectPurge.forceDead(living, true));
                step(() -> living.setHealth(0.0F));
                step(() -> living.die(living.damageSources().genericKill()));
            }
        }

        if (!(target instanceof Player)) {
            if (!target.isRemoved()) {
                step(() -> target.remove(Entity.RemovalReason.KILLED));
            }
            if (!target.isRemoved()) {
                step(target::discard);
            }
        }
        return target.isRemoved();
    }

    private static void step(Runnable action) {
        try {
            action.run();
        } catch (RuntimeException exception) {
            InterceptStats.blocked();
            AllReturnMod.LOGGER.debug("全返强制结束的某一步被目标自己的逻辑挡住了", exception);
        }
    }

    public static int sweep(Player attacker, LivingEntity center) {
        Level level = attacker.level();
        if (level.isClientSide) {
            return 0;
        }
        AABB box = center.getBoundingBox().inflate(SWEEP_RADIUS, 1.5D, SWEEP_RADIUS);
        List<LivingEntity> targets = level.getEntitiesOfClass(LivingEntity.class, box,
                entity -> entity != attacker && entity != center && entity.isAlive()
                        && !AllReturnState.protectedFromPurge(entity));
        int killed = 0;
        for (LivingEntity target : targets) {
            if (killed >= SWEEP_LIMIT) {
                break;
            }
            if (kill(attacker, target, false)) {
                killed++;
            }
        }
        playSweep(level, center);
        return killed;
    }

    public static void lockTarget(LivingEntity target) {
        AllReturnState.suppress(target);
    }

    public static void reflect(Player victim, LivingEntity attacker, float amount) {

        if (AllReturnState.protectedFromPurge(victim)) {
            return;
        }
        if (REFLECTING.get() || attacker == victim || !attacker.isAlive()) {
            return;
        }
        REFLECTING.set(Boolean.TRUE);
        try {
            boolean lethal = AllReturnState.isEnabled(victim, AllReturnState.ALLRETURN)
                    && AllReturnState.isEnabled(victim, AllReturnState.ONE_KILL);
            if (lethal) {
                forceKill(victim, attacker);
            } else {
                attacker.hurt(victim.damageSources().thorns(victim), Math.max(1.0F, amount));
            }
            playBurst(attacker.level(), attacker);
        } finally {
            REFLECTING.set(Boolean.FALSE);
        }
    }

    private static void playBurst(Level level, LivingEntity target) {
        if (level instanceof ServerLevel serverLevel) {
            serverLevel.sendParticles(ParticleTypes.SOUL_FIRE_FLAME,
                    target.getX(), target.getY() + target.getBbHeight() * 0.5D, target.getZ(),
                    24, 0.4D, 0.5D, 0.4D, 0.02D);
            serverLevel.sendParticles(ParticleTypes.END_ROD,
                    target.getX(), target.getY() + target.getBbHeight() * 0.5D, target.getZ(),
                    12, 0.3D, 0.4D, 0.3D, 0.01D);
        }
    }

    private static void playSweep(Level level, LivingEntity center) {
        if (!(level instanceof ServerLevel serverLevel)) {
            return;
        }
        double y = center.getY() + center.getBbHeight() * 0.5D;
        for (int i = 0; i < 10; i++) {
            double angle = Math.PI * 2.0D * i / 10.0D;
            double x = center.getX() + Math.cos(angle) * 1.7D;
            double z = center.getZ() + Math.sin(angle) * 1.7D;
            serverLevel.sendParticles(ParticleTypes.SWEEP_ATTACK, x, y, z, 1, 0.0D, 0.0D, 0.0D, 0.0D);
        }
        serverLevel.playSound(null, center.getX(), center.getY(), center.getZ(),
                SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.PLAYERS, 1.0F, 1.0F);
    }

    public static int clearArea(ServerPlayer player) {
        Level level = player.level();
        AABB box = player.getBoundingBox().inflate(CLEAR_RADIUS);
        List<LivingEntity> targets = level.getEntitiesOfClass(LivingEntity.class, box,
                entity -> entity != player && entity.isAlive()
                        && !AllReturnState.protectedFromPurge(entity));
        int killed = 0;
        for (LivingEntity target : targets) {
            if (killed >= 256) {
                break;
            }
            if (kill(player, target, false)) {
                killed++;
            }
        }
        return killed;
    }

    public static boolean canErase(ServerPlayer player, Entity entity) {
        return entity != null && entity != player && !entity.isRemoved()
                && !(entity instanceof Player) && !AllReturnState.protectedFromPurge(entity);
    }

    public static boolean eraseLook(ServerPlayer player) {
        if (!(player.level() instanceof ServerLevel)) {
            return false;
        }
        Vec3 start = player.getEyePosition();
        Vec3 view = player.getViewVector(1.0F);
        Vec3 end = start.add(view.scale(LOOK_RANGE));
        AABB box = player.getBoundingBox().expandTowards(view.scale(LOOK_RANGE)).inflate(1.0D);
        EntityHitResult hit = ProjectileUtil.getEntityHitResult(player, start, end, box,
                entity -> canErase(player, entity), LOOK_RANGE * LOOK_RANGE);
        if (hit == null) {
            BlockHitResult blockHit = player.level().clip(new ClipContext(start, end,
                    ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, player));
            if (blockHit.getType() == HitResult.Type.BLOCK) {
                BlockPos pos = blockHit.getBlockPos();
                if (player.level().getBlockState(pos).is(Blocks.SPAWNER)) {
                    player.level().removeBlock(pos, false);
                    if (player.level() instanceof ServerLevel level) {
                        level.sendParticles(ParticleTypes.SOUL_FIRE_FLAME,
                                pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D,
                                28, 0.45D, 0.45D, 0.45D, 0.03D);
                        level.sendParticles(ParticleTypes.END_ROD,
                                pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D,
                                18, 0.4D, 0.4D, 0.4D, 0.02D);
                        level.playSound(null, pos, SoundEvents.STONE_BREAK,
                                SoundSource.PLAYERS, 1.0F, 0.8F);
                    }
                    InterceptStats.erased();
                    return true;
                }
            }
            return false;
        }
        return eraseEntity(player, hit.getEntity());
    }

    public static int eraseDimension(ServerPlayer player) {
        if (!(player.level() instanceof ServerLevel level)) {
            return 0;
        }
        List<Entity> victims = new ArrayList<>();
        for (Entity entity : level.getAllEntities()) {
            if (canErase(player, entity)) {
                victims.add(entity);
            }
        }
        int erased = 0;
        for (Entity entity : victims) {
            if (eraseEntity(player, entity)) {
                erased++;
            }
        }
        if (erased > 0) {
            level.playSound(null, player.blockPosition(), SoundEvents.END_PORTAL_SPAWN,
                    SoundSource.PLAYERS, 0.7F, 1.4F);
        }
        return erased;
    }

    public static boolean eraseEntity(ServerPlayer player, Entity target) {
        if (!canErase(player, target) || AllReturnState.protectedFromPurge(target)) {
            return false;
        }
        if (AllReturnState.isEnabled(player, AllReturnState.SPAWN_BAN) && target instanceof LivingEntity living) {
            SpawnBan.ban(player, living.getType());
        }
        playErase(target);
        enforceRemoval(target, player);
        InterceptStats.erased();

        ErasureWatch.watch(target);
        return true;
    }

    private static void playErase(Entity target) {
        if (!(target.level() instanceof ServerLevel serverLevel)) {
            return;
        }
        double y = target.getY() + target.getBbHeight() * 0.5D;
        serverLevel.sendParticles(ParticleTypes.END_ROD,
                target.getX(), y, target.getZ(), 16, 0.3D, 0.4D, 0.3D, 0.02D);
        serverLevel.sendParticles(ParticleTypes.ELECTRIC_SPARK,
                target.getX(), y, target.getZ(), 10, 0.3D, 0.3D, 0.3D, 0.05D);
    }
}
