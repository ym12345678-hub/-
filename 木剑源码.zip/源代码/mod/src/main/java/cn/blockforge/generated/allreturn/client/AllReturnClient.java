package cn.blockforge.generated.allreturn.client;

import cn.blockforge.generated.allreturn.AllReturnMod;
import cn.blockforge.generated.allreturn.item.AnnihilationSwordItem;
import cn.blockforge.generated.allreturn.net.AllReturnNetwork;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.util.RandomSource;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = AllReturnMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class AllReturnClient {
    private static final int PRESS = 1;

    private static boolean holdingUse;
    private static boolean holdingAttack;

    private AllReturnClient() {
    }

    public static void init(IEventBus modBus) {
        modBus.addListener(AllReturnClient::onRegisterOverlays);

        StarUiShader.register(modBus);
    }

    private static void onRegisterOverlays(RegisterGuiOverlaysEvent event) {
        event.registerAboveAll("all_return_button", new AllReturnHud());
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        Minecraft minecraft = Minecraft.getInstance();
        LocalPlayer player = minecraft.player;
        if (player == null) {
            holdingUse = false;
            holdingAttack = false;
            return;
        }
        boolean armed = minecraft.screen == null
                && !minecraft.options.hideGui
                && player.getMainHandItem().getItem() instanceof AnnihilationSwordItem;

        boolean use = armed && !player.isShiftKeyDown() && minecraft.options.keyUse.isDown();
        if (use != holdingUse) {
            holdingUse = use;
            AllReturnNetwork.sendRightHoldToServer(use);
        }

        boolean attack = armed && minecraft.options.keyAttack.isDown();
        if (attack && !holdingAttack) {
            AllReturnNetwork.sendLookClearToServer();
        }
        holdingAttack = attack;

        if (armed && !ClientFreeze.isFrozen() && player.tickCount % 4 == 0) {
            spawnStardust(player);
        }
    }

    private static void spawnStardust(LocalPlayer player) {
        RandomSource random = player.getRandom();
        double x = player.getX() + (random.nextDouble() - 0.5D) * 1.1D;
        double y = player.getY() + 0.9D + random.nextDouble() * 0.9D;
        double z = player.getZ() + (random.nextDouble() - 0.5D) * 1.1D;
        player.level().addParticle(ParticleTypes.END_ROD, x, y, z, 0.0D, 0.004D, 0.0D);
    }

    @SubscribeEvent
    public static void onMouseButton(InputEvent.MouseButton.Pre event) {
        if (event.getAction() != PRESS) {
            return;
        }
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player == null || minecraft.screen != null || minecraft.options.hideGui) {
            return;
        }

        if (minecraft.mouseHandler.isMouseGrabbed()) {
            return;
        }
        int guiWidth = minecraft.getWindow().getGuiScaledWidth();
        int guiHeight = minecraft.getWindow().getGuiScaledHeight();
        double guiX = minecraft.mouseHandler.xpos() * guiWidth / (double) minecraft.getWindow().getScreenWidth();
        double guiY = minecraft.mouseHandler.ypos() * guiHeight / (double) minecraft.getWindow().getScreenHeight();
        if (!AllReturnHud.hit(guiX, guiY, guiHeight)) {
            return;
        }
        event.setCanceled(true);
        AllReturnNetwork.sendOpenRequest();
    }
}
