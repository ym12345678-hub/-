package cn.blockforge.generated.allreturn;

import cn.blockforge.generated.allreturn.item.AnnihilationSwordItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, AllReturnMod.MOD_ID);

    public static final RegistryObject<Item> ANNIHILATION_SWORD =
            ITEMS.register("wooden_sword", AnnihilationSwordItem::new);

    private ModItems() {
    }
}
