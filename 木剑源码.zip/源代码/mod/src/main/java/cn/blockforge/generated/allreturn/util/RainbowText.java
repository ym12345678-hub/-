package cn.blockforge.generated.allreturn.util;

import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.network.chat.TextColor;
import net.minecraft.util.Mth;

public final class RainbowText {

    private static final long CYCLE_MILLIS = 6000L;

    private static final float STEP = 0.18F;

    private RainbowText() {
    }

    public static Component of(String text) {
        return of(text, 0.0F);
    }

    public static Component of(Component source) {
        return of(source.getString());
    }

    public static Component of(String text, float offset) {
        MutableComponent result = Component.empty();
        if (text == null || text.isEmpty()) {
            return result;
        }
        float phase = (System.currentTimeMillis() % CYCLE_MILLIS) / (float) CYCLE_MILLIS;
        for (int i = 0; i < text.length(); i++) {
            float hue = (phase + offset + i * STEP) % 1.0F;
            if (hue < 0.0F) {
                hue += 1.0F;
            }
            int rgb = Mth.hsvToRgb(hue, 0.75F, 1.0F);
            result.append(Component.literal(String.valueOf(text.charAt(i)))
                    .withStyle(Style.EMPTY.withColor(TextColor.fromRgb(rgb))));
        }
        return result;
    }
}
