package cn.blockforge.generated.allreturn.combat;

import cn.blockforge.generated.allreturn.AllReturnMod;
import cn.blockforge.generated.allreturn.state.AllReturnState;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;

public final class SovereignGuard {

    private static final float HEALTH_EPSILON = 0.05F;

    private static final Map<UUID, Long> LAST_REFLECT = new ConcurrentHashMap<>();

    private static final Map<UUID, Vitals> SNAPSHOTS = new ConcurrentHashMap<>();

    private SovereignGuard() {
    }

    public static boolean isSovereign(Player player) {
        return player != null
                && AllReturnState.hasGear(player)
                && AllReturnState.isEnabled(player, AllReturnState.SOVEREIGN);
    }

    public static void tick(ServerPlayer player) {
        if (player == null) {
            return;
        }
        if (!isSovereign(player)) {
            clear(player.getUUID());
            return;
        }

        if (FinalSay.isDoomed(player)) {
            return;
        }
        UUID id = player.getUUID();
        Vitals baseline = SNAPSHOTS.computeIfAbsent(id, ignored -> Vitals.of(player));

        boolean dead = player.isDeadOrDying() || player.getHealth() <= 0.0F;
        boolean dropped = player.getHealth() + HEALTH_EPSILON < baseline.health();
        if (dead || dropped) {
            restore(player, baseline);
            if (player.tickCount % 20 == 0) {
                playShield(player);
            }
        }

        if (!dead && player.tickCount % 20 == 0) {
            SNAPSHOTS.put(id, Vitals.of(player));
        }
    }

    public static boolean shield(ServerPlayer player, DamageSource source, float amount) {
        if (!isSovereign(player)) {
            return false;
        }
        UUID id = player.getUUID();
        long now = player.level().getGameTime();
        Long last = LAST_REFLECT.get(id);
        if (last == null || last.longValue() != now) {
            LAST_REFLECT.put(id, now);
            playShield(player);
            Entity attacker = source == null ? null : source.getEntity();
            if (attacker instanceof LivingEntity living && living != player && living.isAlive()) {
                try {
                    AllReturnHooks.reflect(player, living, Math.max(1.0F, amount));
                } catch (Throwable throwable) {
                    AllReturnMod.LOGGER.debug("主权防御反弹失败，这一下只取消不反弹", throwable);
                }
            }
        }
        InterceptStats.blocked();
        return true;
    }

    public static void revive(ServerPlayer player) {
        if (player == null) {
            return;
        }
        Vitals baseline = SNAPSHOTS.getOrDefault(player.getUUID(), Vitals.of(player));
        restore(player, baseline);
        InterceptStats.blocked();
    }

    public static void clear(UUID id) {
        if (id == null) {
            return;
        }
        SNAPSHOTS.remove(id);
        LAST_REFLECT.remove(id);
    }

    public static String describe(ServerPlayer player) {
        if (player == null) {
            return "n/a";
        }
        Vitals baseline = SNAPSHOTS.get(player.getUUID());
        if (baseline == null) {
            return "no-baseline";
        }
        return "health=" + player.getHealth() + "/" + baseline.health()
                + " dead=" + player.isDeadOrDying()
                + " removed=" + player.isRemoved();
    }

    private static void playShield(ServerPlayer player) {
        try {
            if (player.level() instanceof ServerLevel level) {
                level.sendParticles(ParticleTypes.END_ROD,
                        player.getX(), player.getY() + 1.0D, player.getZ(),
                        18, 0.55D, 0.8D, 0.55D, 0.02D);
                level.sendParticles(ParticleTypes.ENCHANT,
                        player.getX(), player.getY() + 1.0D, player.getZ(),
                        12, 0.5D, 0.7D, 0.5D, 0.1D);
                level.playSound(null, player.getX(), player.getY(), player.getZ(),
                        SoundEvents.SHIELD_BLOCK, SoundSource.PLAYERS, 1.0F, 1.5F);
            }
            if (player.tickCount % 10 == 0) {
                player.displayClientMessage(Component.literal("全返 · 拦截 + 反弹"), true);
            }
        } catch (Throwable ignored) {
        }
    }

    private static void restore(ServerPlayer player, Vitals baseline) {

        try {
            ReflectPurge.clearDead(player);
        } catch (Throwable throwable) {
            AllReturnMod.LOGGER.debug("主权防御：dead 标记没清掉", throwable);
        }
        try {
            ReflectPurge.clearRemoved(player);
        } catch (Throwable throwable) {
            AllReturnMod.LOGGER.debug("主权防御：removed 标记没清掉", throwable);
        }
        try {
            player.deathTime = 0;
            player.hurtTime = 0;
            player.invulnerableTime = 0;
        } catch (Throwable ignored) {

        }

        try {
            float target = Math.max(baseline.health(), 1.0F);
            if (player.getHealth() <= 0.0F || player.isDeadOrDying()) {
                target = Math.max(target, player.getMaxHealth());
            }
            player.setHealth(target);
        } catch (Throwable throwable) {
            AllReturnMod.LOGGER.debug("主权防御：血量没写回去", throwable);
        }

        try {
            player.setAbsorptionAmount(Math.max(player.getAbsorptionAmount(), baseline.absorption()));
        } catch (Throwable ignored) {
        }
        try {

            player.getFoodData().setFoodLevel(20);
            player.getFoodData().setSaturation(Math.max(baseline.saturation(), 5.0F));
        } catch (Throwable ignored) {
        }
        try {
            player.setAirSupply(player.getMaxAirSupply());
        } catch (Throwable ignored) {
        }
        try {
            player.clearFire();
        } catch (Throwable ignored) {
        }
        try {
            player.setTicksFrozen(0);
        } catch (Throwable ignored) {
        }

        purgeHarmfulEffects(player);
        InterceptStats.blocked();
    }

    private static void purgeHarmfulEffects(ServerPlayer player) {
        List<MobEffectInstance> harmful = new ArrayList<>();
        try {
            for (MobEffectInstance instance : player.getActiveEffects()) {
                if (instance != null && instance.getEffect().getCategory() == MobEffectCategory.HARMFUL) {
                    harmful.add(instance);
                }
            }
        } catch (Throwable throwable) {
            return;
        }
        for (MobEffectInstance instance : harmful) {
            try {
                player.removeEffect(instance.getEffect());
            } catch (Throwable ignored) {
            }
        }
    }

    private record Vitals(float health, float absorption, int food, float saturation, int air) {
        static Vitals of(ServerPlayer player) {
            float health = 1.0F;
            float absorption = 0.0F;
            int food = 20;
            float saturation = 0.0F;
            int air = 300;
            try {
                health = player.getHealth();
                absorption = player.getAbsorptionAmount();
                food = player.getFoodData().getFoodLevel();
                saturation = player.getFoodData().getSaturationLevel();
                air = player.getAirSupply();
            } catch (Throwable ignored) {

            }
            return new Vitals(health, absorption, food, saturation, air);
        }
    }
}
