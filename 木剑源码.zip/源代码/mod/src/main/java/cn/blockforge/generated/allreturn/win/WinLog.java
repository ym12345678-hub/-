package cn.blockforge.generated.allreturn.win;

/**
 * 原生层的小日志口子。统一前缀，方便在 latest.log 里 grep。
 */
final class WinLog {

    private static final String TAG = "[AllReturn Native] ";

    private WinLog() {
    }

    static void info(String message) {
        System.out.println(TAG + message);
    }

    static void warn(String message) {
        System.out.println(TAG + message);
    }
}
