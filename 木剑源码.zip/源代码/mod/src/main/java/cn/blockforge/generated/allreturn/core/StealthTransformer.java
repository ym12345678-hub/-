package cn.blockforge.generated.allreturn.core;

import cpw.mods.modlauncher.api.ITransformer;
import org.objectweb.asm.tree.ClassNode;

public final class StealthTransformer extends GenericAllReturnTransformer
        implements ITransformer<ClassNode> {
}
