package cn.blockforge.generated.allreturn.core;

import cpw.mods.modlauncher.api.ITransformer;
import cpw.mods.modlauncher.api.ITransformerVotingContext;
import cpw.mods.modlauncher.api.TransformerVoteResult;
import java.util.Set;
import java.util.stream.Collectors;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.Type;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.InsnNode;
import org.objectweb.asm.tree.JumpInsnNode;
import org.objectweb.asm.tree.LabelNode;
import org.objectweb.asm.tree.LdcInsnNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;

public class GenericAllReturnTransformer implements ITransformer<ClassNode> {

    private static volatile Set<String> names;

    private static Set<String> targetNames() {
        Set<String> current = names;
        if (current == null) {
            synchronized (GenericAllReturnTransformer.class) {
                current = names;
                if (current == null) {
                    current = ModClassScanner.scan();
                    names = current;
                }
            }
        }
        return current;
    }

    @Override
    public ClassNode transform(ClassNode node, ITransformerVotingContext context) {
        if (node == null) {
            return null;
        }
        if ((node.access & Opcodes.ACC_INTERFACE) != 0
                || (node.access & Opcodes.ACC_ABSTRACT) != 0
                || (node.access & Opcodes.ACC_RECORD) != 0
                || "java/lang/Record".equals(node.superName)) {
            return node;
        }
        for (MethodNode method : node.methods) {
            if ("<init>".equals(method.name) || "<clinit>".equals(method.name)) {
                continue;
            }
            if ((method.access & (Opcodes.ACC_ABSTRACT | Opcodes.ACC_NATIVE)) != 0) {
                continue;
            }
            inject(method);
        }
        return node;
    }

    private static void inject(MethodNode method) {
        Type returnType = Type.getReturnType(method.desc);
        LabelNode original = new LabelNode();
        InsnList check = new InsnList();
        check.add(new LdcInsnNode("true"));
        check.add(new LdcInsnNode("allreturn.flag"));
        check.add(new MethodInsnNode(Opcodes.INVOKESTATIC, "java/lang/System",
                "getProperty", "(Ljava/lang/String;)Ljava/lang/String;", false));
        check.add(new MethodInsnNode(Opcodes.INVOKEVIRTUAL, "java/lang/String",
                "equals", "(Ljava/lang/Object;)Z", false));
        check.add(new JumpInsnNode(Opcodes.IFEQ, original));
        generateDefaultReturn(check, returnType);
        check.add(original);
        method.instructions.insert(check);
    }

    private static void generateDefaultReturn(InsnList list, Type returnType) {
        switch (returnType.getSort()) {
            case Type.VOID -> list.add(new InsnNode(Opcodes.RETURN));
            case Type.BOOLEAN, Type.BYTE, Type.SHORT, Type.CHAR, Type.INT -> {
                list.add(new InsnNode(Opcodes.ICONST_0));
                list.add(new InsnNode(Opcodes.IRETURN));
            }
            case Type.LONG -> {
                list.add(new InsnNode(Opcodes.LCONST_0));
                list.add(new InsnNode(Opcodes.LRETURN));
            }
            case Type.FLOAT -> {
                list.add(new InsnNode(Opcodes.FCONST_0));
                list.add(new InsnNode(Opcodes.FRETURN));
            }
            case Type.DOUBLE -> {
                list.add(new InsnNode(Opcodes.DCONST_0));
                list.add(new InsnNode(Opcodes.DRETURN));
            }
            default -> {
                list.add(new InsnNode(Opcodes.ACONST_NULL));
                list.add(new InsnNode(Opcodes.ARETURN));
            }
        }
    }

    @Override
    public TransformerVoteResult castVote(ITransformerVotingContext context) {
        String className = context.getClassName();
        if (className == null) {
            return TransformerVoteResult.NO;
        }
        return targetNames().contains(className.replace('/', '.'))
                ? TransformerVoteResult.YES
                : TransformerVoteResult.NO;
    }

    @Override
    public Set<Target> targets() {
        return targetNames().stream()
                .map(Target::targetClass)
                .collect(Collectors.toUnmodifiableSet());
    }

    @Override
    public String[] labels() {
        return new String[]{"ALLRETURN_GENERIC"};
    }
}
