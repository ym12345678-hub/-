package cn.blockforge.generated.allreturn.win;

/**
 * JVMTI 拦截层的自测入口（不进游戏也能跑）。
 *
 * <p>用法（编译好的类和 ASM 都在 classpath 上之后）：
 * <pre>
 *   java -cp ... -Dallreturn.flag=false cn.blockforge.generated.allreturn.win.NativeHookSelfTest
 * </pre>
 *
 * <p>它会：加载 DLL → 注册 → 生成一个「别的模组」风格的类字节 →
 * 交给 {@link NativeHook#transform} → 断言开关关时原样、开时被改成默认返回。
 */
public final class NativeHookSelfTest {

    /** 目标类必须落在扫描到的包里才不会被跳过，这里用固定包名注入。 */
    private static final String TARGET_NAME = "com/example/othermod/Shield";

    private NativeHookSelfTest() {
    }

    public static void main(String[] args) throws Exception {
        System.out.println("== AllReturn NativeHook self test ==");

        boolean ok = NativeHook.ensure();
        System.out.println("ensure() = " + ok);
        System.out.println("describe() = " + NativeHook.describe());
        if (!ok) {
            System.out.println("原生层不可用，测试到此为止（不算失败：没装 DLL 时应安静降级）");
            System.exit(2);
        }

        byte[] original = buildTargetClass();
        System.out.println("样本类大小: " + original.length);

        // 自测环境里没有 mods 目录里别的模组，手动把这个包登记成目标，
        // 模拟「mods 里放了一个别的模组」时的判断结果。
        NativeHook.addTargetForTest("com/example/othermod");
        System.out.println("intercepts(" + TARGET_NAME + ") = " + NativeHook.intercepts(TARGET_NAME));
        if (!NativeHook.intercepts(TARGET_NAME)) {
            System.out.println("FAIL: 目标判断没命中，样本包没登记进目标集合");
            System.exit(1);
        }

        System.setProperty("allreturn.flag", "false");
        byte[] off = NativeHook.transform(NativeHookSelfTest.class.getClassLoader(), TARGET_NAME, original);
        System.out.println("flag=false -> " + (off == null ? "null（原样放行）" : off.length + " bytes"));

        System.setProperty("allreturn.flag", "true");
        byte[] on = NativeHook.transform(NativeHookSelfTest.class.getClassLoader(), TARGET_NAME, original);
        System.out.println("flag=true  -> " + (on == null ? "null（没改！）" : on.length + " bytes"));

        if (on == null || on.length <= original.length) {
            System.out.println("FAIL: 开关打开时没有改写字节");
            System.exit(1);
        }

        // 用加载器真正跑一遍，确认注入的字节是合法的
        Class<?> type = define(TARGET_NAME.replace('/', '.'), on);
        Object instance = type.getDeclaredConstructor().newInstance();
        Object number = type.getMethod("number").invoke(instance);
        Object text = type.getMethod("text").invoke(instance);
        Object banner = type.getMethod("banner").invoke(instance);
        System.out.println("flag=true 调用结果: number=" + number + " text=" + text + " banner=" + banner);

        System.setProperty("allreturn.flag", "false");
        byte[] originalOff = buildTargetClass("com/example/othermod/ShieldOff");
        Class<?> type2 = define("com.example.othermod.ShieldOff", originalOff);
        Object instance2 = type2.getDeclaredConstructor().newInstance();
        System.out.println("flag=false 调用结果: number=" + type2.getMethod("number").invoke(instance2)
                + " text=" + type2.getMethod("text").invoke(instance2));

        boolean pass = Integer.valueOf(0).equals(number)
                && text == null
                && Boolean.FALSE.equals(banner)
                && Integer.valueOf(7).equals(type2.getMethod("number").invoke(instance2));

        System.out.println(pass ? "PASS" : "FAIL");
        System.exit(pass ? 0 : 1);
    }

    private static Class<?> define(String name, byte[] bytes) throws Exception {
        final String target = name;
        return new ClassLoader(NativeHookSelfTest.class.getClassLoader()) {
            Class<?> make(byte[] b) {
                return defineClass(target, b, 0, b.length);
            }
        }.make(bytes);
    }

    /**
     * 手写一个「像别的模组」的类：
     * <pre>
     * public class Shield {
     *     public int number() { return 7; }
     *     public String text() { return "x"; }
     *     public boolean banner() { return true; }
     * }
     * </pre>
     */
    private static byte[] buildTargetClass() {
        return buildTargetClass(TARGET_NAME);
    }

    private static byte[] buildTargetClass(String internalName) {
        org.objectweb.asm.tree.ClassNode node = new org.objectweb.asm.tree.ClassNode();
        node.version = org.objectweb.asm.Opcodes.V17;
        node.access = org.objectweb.asm.Opcodes.ACC_PUBLIC;
        node.name = internalName;
        node.superName = "java/lang/Object";

        org.objectweb.asm.tree.MethodNode ctor = new org.objectweb.asm.tree.MethodNode(
                org.objectweb.asm.Opcodes.ACC_PUBLIC, "<init>", "()V", null, null);
        ctor.instructions.add(new org.objectweb.asm.tree.VarInsnNode(org.objectweb.asm.Opcodes.ALOAD, 0));
        ctor.instructions.add(new org.objectweb.asm.tree.MethodInsnNode(
                org.objectweb.asm.Opcodes.INVOKESPECIAL, "java/lang/Object", "<init>", "()V", false));
        ctor.instructions.add(new org.objectweb.asm.tree.InsnNode(org.objectweb.asm.Opcodes.RETURN));
        ctor.maxStack = 1;
        ctor.maxLocals = 1;
        node.methods.add(ctor);

        node.methods.add(simple("number", "()I",
                new org.objectweb.asm.tree.InsnList() {{
                    add(new org.objectweb.asm.tree.IntInsnNode(org.objectweb.asm.Opcodes.BIPUSH, 7));
                    add(new org.objectweb.asm.tree.InsnNode(org.objectweb.asm.Opcodes.IRETURN));
                }}));

        node.methods.add(simple("text", "()Ljava/lang/String;",
                new org.objectweb.asm.tree.InsnList() {{
                    add(new org.objectweb.asm.tree.LdcInsnNode("x"));
                    add(new org.objectweb.asm.tree.InsnNode(org.objectweb.asm.Opcodes.ARETURN));
                }}));

        node.methods.add(simple("banner", "()Z",
                new org.objectweb.asm.tree.InsnList() {{
                    add(new org.objectweb.asm.tree.InsnNode(org.objectweb.asm.Opcodes.ICONST_1));
                    add(new org.objectweb.asm.tree.InsnNode(org.objectweb.asm.Opcodes.IRETURN));
                }}));

        org.objectweb.asm.ClassWriter writer = new org.objectweb.asm.ClassWriter(
                org.objectweb.asm.ClassWriter.COMPUTE_FRAMES | org.objectweb.asm.ClassWriter.COMPUTE_MAXS);
        node.accept(writer);
        return writer.toByteArray();
    }

    private static org.objectweb.asm.tree.MethodNode simple(
            String name, String desc, org.objectweb.asm.tree.InsnList body) {
        org.objectweb.asm.tree.MethodNode m = new org.objectweb.asm.tree.MethodNode(
                org.objectweb.asm.Opcodes.ACC_PUBLIC, name, desc, null, null);
        m.instructions.add(body);
        m.maxStack = 2;
        m.maxLocals = 1;
        return m;
    }
}
