package cn.blockforge.generated.allreturn.state;

import cn.blockforge.generated.allreturn.item.ModGear;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;

public final class AllReturnState {

    public static final int ALLRETURN = 1;

    public static final int ONE_KILL = 1 << 1;

    public static final int GOD = 1 << 2;

    public static final int LOCK = 1 << 3;

    public static final int REFLECT = 1 << 4;

    public static final int FLIGHT = 1 << 5;

    public static final int SPAWN_BAN = 1 << 6;

    public static final int SOVEREIGN = 1 << 7;

    public static final int ALL_BITS = ALLRETURN | ONE_KILL | GOD | LOCK | REFLECT | FLIGHT | SPAWN_BAN | SOVEREIGN;

    public static final int DEFAULTS = ALLRETURN | ONE_KILL | LOCK | REFLECT | SOVEREIGN;

    private static final String TAG_FLAGS = "all_return_flags";

    private static final String TAG_SOVEREIGN_MIGRATED = "all_return_sovereign_v1";

    private static final int SUPPRESS_TICKS = 20 * 15;

    private static final EquipmentSlot[] GEAR_SLOTS = {
            EquipmentSlot.MAINHAND,
            EquipmentSlot.OFFHAND
    };

    private static final Map<UUID, Long> SUPPRESS_UNTIL = new ConcurrentHashMap<>();

    private AllReturnState() {
    }

    public static int flags(Player player) {
        CompoundTag data = player.getPersistentData();
        if (!data.contains(TAG_FLAGS)) {
            data.putInt(TAG_FLAGS, DEFAULTS);
            data.putBoolean(TAG_SOVEREIGN_MIGRATED, true);
            return DEFAULTS;
        }
        int flags = data.getInt(TAG_FLAGS) & ALL_BITS;
        if (!data.getBoolean(TAG_SOVEREIGN_MIGRATED)) {
            flags |= SOVEREIGN;
            data.putInt(TAG_FLAGS, flags);
            data.putBoolean(TAG_SOVEREIGN_MIGRATED, true);
        }
        return flags;
    }

    public static void applyFlag(Player player) {
        System.setProperty("allreturn.flag", String.valueOf(isEnabled(player, ALLRETURN)));
    }

    public static int setFlags(Player player, int flags) {
        int value = flags & ALL_BITS;
        player.getPersistentData().putInt(TAG_FLAGS, value);
        System.setProperty("allreturn.flag", String.valueOf((value & ALLRETURN) != 0));
        return value;
    }

    public static boolean isEnabled(Player player, int bit) {
        return (flags(player) & bit) != 0;
    }

    public static boolean hasGear(Player player) {
        for (EquipmentSlot slot : GEAR_SLOTS) {
            if (player.getItemBySlot(slot).getItem() instanceof ModGear) {
                return true;
            }
        }
        return false;
    }

    public static boolean isGod(Player player) {
        return player != null && hasGear(player) && (flags(player) & GOD) != 0;
    }

    public static boolean protectedFromPurge(Entity entity) {
        return entity instanceof Player player && isGod(player);
    }

    public static int toggle(Player player, int bit, boolean value) {
        int flags = flags(player);
        flags = value ? (flags | bit) : (flags & ~bit);
        return setFlags(player, flags);
    }

    public static void suppress(LivingEntity entity) {
        if (entity.level().isClientSide) {
            return;
        }
        long now = entity.level().getGameTime();
        SUPPRESS_UNTIL.put(entity.getUUID(), now + SUPPRESS_TICKS);
        if (SUPPRESS_UNTIL.size() > 512) {
            SUPPRESS_UNTIL.values().removeIf(until -> until < now);
        }
    }

    public static boolean isSuppressed(LivingEntity entity) {
        Long until = SUPPRESS_UNTIL.get(entity.getUUID());
        if (until == null) {
            return false;
        }
        if (until < entity.level().getGameTime()) {
            SUPPRESS_UNTIL.remove(entity.getUUID());
            return false;
        }
        return true;
    }

    public static void clearSuppressed(LivingEntity entity) {
        SUPPRESS_UNTIL.remove(entity.getUUID());
    }
}
