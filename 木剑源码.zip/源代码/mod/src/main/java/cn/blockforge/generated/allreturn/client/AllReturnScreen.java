package cn.blockforge.generated.allreturn.client;

import cn.blockforge.generated.allreturn.net.AllReturnNetwork;
import cn.blockforge.generated.allreturn.state.AllReturnState;
import cn.blockforge.generated.allreturn.util.RainbowText;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.joml.Matrix4f;

@OnlyIn(Dist.CLIENT)
public class AllReturnScreen extends Screen {
    private static final int PANEL_W = 400;
    private static final int PANEL_H = 394;
    private static final int BTN_W = 186;
    private static final int BTN_H = 44;
    private static final int COL_1 = 10;
    private static final int COL_2 = 204;
    private static final int ROW_1 = 92;
    private static final int ROW_2 = 144;
    private static final int ROW_3 = 196;
    private static final int ROW_4 = 248;
    private static final int ACTION_W = 124;
    private static final int ACTION_H = 38;
    private static final int ACTION_Y_1 = 302;
    private static final int ACTION_Y_2 = 346;
    private static final int ACTION_X_1 = 10;
    private static final int ACTION_X_2 = 138;
    private static final int ACTION_X_3 = 266;

    private static final int[] BITS = {
            AllReturnState.ALLRETURN,
            AllReturnState.ONE_KILL,
            AllReturnState.GOD,
            AllReturnState.LOCK,
            AllReturnState.REFLECT,
            AllReturnState.FLIGHT,
            AllReturnState.SPAWN_BAN,
            AllReturnState.SOVEREIGN
    };
    private static final int TOGGLE_COUNT = BITS.length;

    private static final String[] ACTION_LABELS = {
            "gui.all_return.all_on",
            "gui.all_return.all_off",
            "gui.all_return.wipe",
            "gui.all_return.clear_ban",
            "gui.all_return.unfreeze",
            "gui.all_return.close"
    };
    private static final int[] ACTION_COLORS = {
            0xFF3A1D6E,
            0xFF1B1226,
            0xFF4A1030,
            0xFF2F1A4E,
            0xFF2A1533,
            0xFF2A1533
    };

    private static final int PANEL_BORDER = 0xFF7A3CFF;
    private static final int PANEL_BG = 0xF5120A1C;
    private static final int ACCENT = 0xFFFF7AFF;
    private static final int TEXT = 0xFFE8E0FF;
    private static final int TEXT_DIM = 0xFF9C93B8;
    private static final int ON_COLOR = 0xFF5CFF9D;
    private static final int OFF_COLOR = 0xFFFF6B6B;

    private int flags;
    private float uiScale = 1.0F;
    private int originX;
    private int originY;

    public AllReturnScreen(int flags) {
        super(Component.translatable("gui.all_return.title"));
        this.flags = flags;
    }

    @Override
    protected void init() {
        float fitW = this.width / (float) (PANEL_W + 16);
        float fitH = this.height / (float) (PANEL_H + 16);
        this.uiScale = Math.max(0.5F, Math.min(Math.min(fitW, fitH), 2.5F));
        this.originX = Math.round((this.width - PANEL_W * this.uiScale) * 0.5F);
        this.originY = Math.round((this.height - PANEL_H * this.uiScale) * 0.5F);
    }

    public void applyFlags(int flags) {
        this.flags = flags;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    private boolean isOn(int index) {
        return (this.flags & BITS[index]) != 0;
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        graphics.fill(0, 0, this.width, this.height, 0xB0000000);

        float mx = (mouseX - this.originX) / this.uiScale;
        float my = (mouseY - this.originY) / this.uiScale;

        PoseStack pose = graphics.pose();
        pose.pushPose();
        pose.translate(this.originX, this.originY, 0.0F);
        pose.scale(this.uiScale, this.uiScale, 1.0F);

        graphics.fill(-3, -3, PANEL_W + 3, PANEL_H + 3, PANEL_BORDER);
        graphics.fill(0, 0, PANEL_W, PANEL_H, PANEL_BG);

        drawStarfield(graphics);
        graphics.fill(0, 0, PANEL_W, PANEL_H, 0x6E100A1C);
        graphics.fill(0, 0, PANEL_W, 2, ACCENT);

        graphics.drawCenteredString(this.font, RainbowText.of(Component.translatable("gui.all_return.title")),
                PANEL_W / 2, 59, ACCENT);
        graphics.drawCenteredString(this.font, Component.translatable("gui.all_return.subtitle"),
                PANEL_W / 2, 76, TEXT_DIM);

        for (int i = 0; i < TOGGLE_COUNT; i++) {
            drawToggle(graphics, i, toggleX(i), toggleY(i), mx, my);
        }

        for (int i = 0; i < ACTION_LABELS.length; i++) {
            drawAction(graphics, actionX(i), actionY(i), ACTION_LABELS[i], ACTION_COLORS[i], mx, my);
        }

        pose.popPose();
    }

    private static int toggleX(int index) {
        return (index % 2 == 0) ? COL_1 : COL_2;
    }

    private static int toggleY(int index) {
        return switch (index / 2) {
            case 0 -> ROW_1;
            case 1 -> ROW_2;
            case 2 -> ROW_3;
            default -> ROW_4;
        };
    }

    private static int actionX(int index) {
        return switch (index % 3) {
            case 0 -> ACTION_X_1;
            case 1 -> ACTION_X_2;
            default -> ACTION_X_3;
        };
    }

    private static int actionY(int index) {
        return index < 3 ? ACTION_Y_1 : ACTION_Y_2;
    }

    private void drawStarfield(GuiGraphics graphics) {
        RenderType type = StarUiShader.renderType();
        if (type == null) {
            return;
        }
        StarUiShader.setTime((System.currentTimeMillis() % 120000L) / 1000.0F);
        VertexConsumer buffer = graphics.bufferSource().getBuffer(type);
        Matrix4f matrix = graphics.pose().last().pose();
        buffer.vertex(matrix, 0.0F, PANEL_H, 0.0F).uv(0.0F, 1.0F).color(255, 255, 255, 255).endVertex();
        buffer.vertex(matrix, PANEL_W, PANEL_H, 0.0F).uv(1.0F, 1.0F).color(255, 255, 255, 255).endVertex();
        buffer.vertex(matrix, PANEL_W, 0.0F, 0.0F).uv(1.0F, 0.0F).color(255, 255, 255, 255).endVertex();
        buffer.vertex(matrix, 0.0F, 0.0F, 0.0F).uv(0.0F, 0.0F).color(255, 255, 255, 255).endVertex();
        graphics.flush();
    }

    private void drawToggle(GuiGraphics graphics, int index, int x, int y, float mouseX, float mouseY) {
        boolean on = isOn(index);
        boolean hover = inside(mouseX, mouseY, x, y, BTN_W, BTN_H);
        int background;
        if (on) {
            background = hover ? 0xFF4A2585 : 0xFF3A1D6E;
        } else {
            background = hover ? 0xFF33283F : 0xFF1B1226;
        }
        graphics.fill(x, y, x + BTN_W, y + BTN_H, background);

        int accent = on ? 0xFFB47CFF : 0xFF4A3B62;
        graphics.fill(x, y, x + BTN_W, y + 2, accent);
        graphics.fill(x, y, x + 2, y + BTN_H, accent);

        graphics.drawString(this.font, RainbowText.of(Component.translatable("gui.all_return.toggle." + index)),
                x + 10, y + 6, TEXT, false);
        graphics.drawString(this.font,
                Component.translatable(on ? "gui.all_return.state.on" : "gui.all_return.state.off"),
                x + 10, y + 19, on ? ON_COLOR : OFF_COLOR, false);
        graphics.drawString(this.font, Component.translatable("gui.all_return.hint." + index),
                x + 10, y + 31, TEXT_DIM, false);
    }

    private void drawAction(GuiGraphics graphics, int x, int y, String labelKey, int color,
                            float mouseX, float mouseY) {
        boolean hover = inside(mouseX, mouseY, x, y, ACTION_W, ACTION_H);
        graphics.fill(x, y, x + ACTION_W, y + ACTION_H, hover ? 0xFF5B2FA8 : color);
        graphics.fill(x, y, x + ACTION_W, y + 2, ACCENT);
        graphics.drawCenteredString(this.font, RainbowText.of(Component.translatable(labelKey)),
                x + ACTION_W / 2, y + ACTION_H / 2 - 4, TEXT);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        float mx = (float) ((mouseX - this.originX) / this.uiScale);
        float my = (float) ((mouseY - this.originY) / this.uiScale);

        for (int i = 0; i < TOGGLE_COUNT; i++) {
            if (inside(mx, my, toggleX(i), toggleY(i), BTN_W, BTN_H)) {
                toggle(i);
                return true;
            }
        }
        for (int i = 0; i < ACTION_LABELS.length; i++) {
            if (inside(mx, my, actionX(i), actionY(i), ACTION_W, ACTION_H)) {
                clickAction(i);
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    private void clickAction(int index) {
        switch (index) {
            case 0 -> AllReturnNetwork.sendSetAllToServer(true);
            case 1 -> AllReturnNetwork.sendSetAllToServer(false);
            case 2 -> AllReturnNetwork.sendWipeToServer();
            case 3 -> AllReturnNetwork.sendClearBanToServer();
            case 4 -> AllReturnNetwork.sendUnfreezeToServer();
            default -> this.onClose();
        }
    }

    private void toggle(int index) {
        boolean newValue = !isOn(index);
        this.flags = newValue ? (this.flags | BITS[index]) : (this.flags & ~BITS[index]);
        AllReturnNetwork.sendToggleToServer(BITS[index], newValue);
    }

    private static boolean inside(float mouseX, float mouseY, int x, int y, int width, int height) {
        return mouseX >= x && mouseX < x + width && mouseY >= y && mouseY < y + height;
    }
}
