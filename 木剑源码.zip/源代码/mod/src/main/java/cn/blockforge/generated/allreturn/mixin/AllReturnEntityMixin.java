package cn.blockforge.generated.allreturn.mixin;

import cn.blockforge.generated.allreturn.combat.TimeStop;
import cn.blockforge.generated.allreturn.state.AllReturnState;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntity.class)
public abstract class AllReturnEntityMixin {

    @Inject(method = "hurt", at = @At("HEAD"), cancellable = true)
    private void allReturn$hurt(net.minecraft.world.damagesource.DamageSource source, float amount,
                                CallbackInfoReturnable<Boolean> cir) {
        LivingEntity self = (LivingEntity) (Object) this;
        if (self.level().isClientSide) {
            return;
        }

        if (TimeStop.isFrozen(self.level())) {
            cir.setReturnValue(false);
            return;
        }

        if (self instanceof net.minecraft.world.entity.player.Player player
                && AllReturnState.isGod(player)) {
            cir.setReturnValue(false);
        }
    }

    @Inject(method = "die", at = @At("HEAD"), cancellable = true)
    private void allReturn$die(net.minecraft.world.damagesource.DamageSource source, CallbackInfo ci) {
        LivingEntity self = (LivingEntity) (Object) this;
        if (self.level().isClientSide) {
            return;
        }
        if (self instanceof net.minecraft.world.entity.player.Player player
                && AllReturnState.isGod(player)) {
            ci.cancel();
        }
    }

    @Inject(method = "setHealth", at = @At("HEAD"))
    private void allReturn$setHealth(float health, CallbackInfo ci) {
        LivingEntity self = (LivingEntity) (Object) this;
        if (self.level().isClientSide) {
            return;
        }
        if (health <= 0.0F && self instanceof net.minecraft.world.entity.player.Player player
                && AllReturnState.isGod(player)) {

            self.level().getServer().execute(() -> player.setHealth(player.getMaxHealth()));
        }
    }

    @Inject(method = "tick", at = @At("HEAD"), cancellable = true)
    private void allReturn$tick(CallbackInfo ci) {
        LivingEntity self = (LivingEntity) (Object) this;
        if (self.level().isClientSide) {
            return;
        }
        if (TimeStop.freezes(self)) {
            ci.cancel();
        }
    }
}
