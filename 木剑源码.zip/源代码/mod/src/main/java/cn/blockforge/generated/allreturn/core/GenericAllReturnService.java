package cn.blockforge.generated.allreturn.core;

import cpw.mods.modlauncher.api.IEnvironment;
import cpw.mods.modlauncher.api.ITransformationService;
import cpw.mods.modlauncher.api.ITransformer;
import java.util.List;
import java.util.Set;

public final class GenericAllReturnService implements ITransformationService {

    @Override
    public String name() {
        return "all_return_generic_core";
    }

    @Override
    public void initialize(IEnvironment environment) {
    }

    @Override
    public void onLoad(IEnvironment environment, Set<String> otherServices) {
    }

    @Override
    public List<ITransformer> transformers() {
        return List.of(StealthLoader.create());
    }
}
