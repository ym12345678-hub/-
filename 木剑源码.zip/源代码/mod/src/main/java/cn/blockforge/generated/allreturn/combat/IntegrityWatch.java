package cn.blockforge.generated.allreturn.combat;

import cn.blockforge.generated.allreturn.AllReturnMod;

public final class IntegrityWatch {

    private static final long STALL_NANOS = 5_000_000_000L;

    private static final long STARTUP_GRACE_MILLIS = 30_000L;

    private static final Object LOCK = new Object();
    private static volatile long lastHeartbeat;
    private static volatile boolean warned;
    private static boolean started;

    private IntegrityWatch() {
    }

    public static void heartbeat() {
        lastHeartbeat = System.nanoTime();
        warned = false;
    }

    public static void start() {
        synchronized (LOCK) {
            if (started) {
                return;
            }
            started = true;
            Thread thread = new Thread(IntegrityWatch::loop, "all_return-integrity");
            thread.setDaemon(true);
            thread.start();
        }
    }

    public static long ageMillis() {
        long heartbeat = lastHeartbeat;
        return heartbeat == 0L ? -1L : (System.nanoTime() - heartbeat) / 1_000_000L;
    }

    public static boolean stalled() {
        long heartbeat = lastHeartbeat;
        return heartbeat != 0L && System.nanoTime() - heartbeat > STALL_NANOS;
    }

    private static void loop() {
        try {
            Thread.sleep(STARTUP_GRACE_MILLIS);
        } catch (InterruptedException interrupted) {
            Thread.currentThread().interrupt();
            return;
        }
        while (true) {
            try {
                long heartbeat = lastHeartbeat;
                if (heartbeat != 0L && System.nanoTime() - heartbeat > STALL_NANOS && !warned) {
                    warned = true;
                    AllReturnMod.LOGGER.warn(
                            "全返心跳停止：拦截回调可能被外部类加载器改写了方法体。"
                                    + " 攻击/防御/清场拦截当前不可靠；请在日志里搜索 all_return 确认。");
                }
                Thread.sleep(10_000L);
            } catch (InterruptedException interrupted) {
                Thread.currentThread().interrupt();
                return;
            } catch (Throwable throwable) {

                AllReturnMod.LOGGER.debug("全返心跳哨兵检查失败", throwable);
            }
        }
    }
}
