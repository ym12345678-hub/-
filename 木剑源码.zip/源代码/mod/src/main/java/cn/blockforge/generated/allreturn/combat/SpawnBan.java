package cn.blockforge.generated.allreturn.combat;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;

public final class SpawnBan {
    private static final Set<EntityType<?>> BANNED = ConcurrentHashMap.newKeySet();

    private SpawnBan() {
    }

    public static boolean ban(ServerPlayer player, EntityType<?> type) {
        if (type == null) {
            return false;
        }
        if (!BANNED.add(type)) {
            return false;
        }
        player.displayClientMessage(
                Component.translatable("message.all_return.banned", type.getDescription()), true);
        return true;
    }

    public static boolean isBanned(EntityType<?> type) {
        return type != null && BANNED.contains(type);
    }

    public static int size() {
        return BANNED.size();
    }

    public static int clear() {
        int count = BANNED.size();
        BANNED.clear();
        return count;
    }

    public static Component describe() {
        if (BANNED.isEmpty()) {
            return Component.translatable("message.all_return.banlist.empty");
        }
        List<EntityType<?>> types = new ArrayList<>(BANNED);
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < types.size(); i++) {
            if (i > 0) {
                builder.append("、");
            }
            builder.append(types.get(i).getDescription().toString());
        }
        return Component.translatable("message.all_return.banlist", builder.toString());
    }
}
