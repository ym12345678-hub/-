package cn.blockforge.generated.allreturn.combat;

import cn.blockforge.generated.allreturn.AllReturnMod;
import java.lang.reflect.Field;

public final class ObjectHeaderMaster {

    private static final int KLASS_OFFSET_COMPRESSED = 4;

    private static final int KLASS_OFFSET_FULL = 8;

    private static final int KLASS_OFFSET = detectKlassOffset();

    private static final int UNKNOWN = -1;

    private ObjectHeaderMaster() {
    }

    public static boolean writable() {
        return KLASS_OFFSET != UNKNOWN && UnsafeMaster.available() && UnsafeMaster.hardcore();
    }

    public static boolean readable() {
        return KLASS_OFFSET != UNKNOWN && UnsafeMaster.available();
    }

    public static int klassOffset() {
        return KLASS_OFFSET;
    }

    public static long readMarkWord(Object object) {
        if (!readable() || object == null) {
            return 0L;
        }
        long address = UnsafeMaster.getObjectAddress(object);
        if (address == 0L) {
            return 0L;
        }
        try {
            return UnsafeMaster.readRawLong(address);
        } catch (Throwable throwable) {
            AllReturnMod.LOGGER.debug("读 Mark Word 失败", throwable);
            return 0L;
        }
    }

    public static boolean swapKlass(Object target, Object donor) {
        if (!writable() || target == null || donor == null) {
            return false;
        }
        long targetAddress = UnsafeMaster.getObjectAddress(target);
        long donorAddress = UnsafeMaster.getObjectAddress(donor);
        if (targetAddress == 0L || donorAddress == 0L) {
            return false;
        }
        try {
            long donorKlass = UnsafeMaster.readRawLong(donorAddress + KLASS_OFFSET);

            if (KLASS_OFFSET == KLASS_OFFSET_COMPRESSED) {
                UnsafeMaster.writeRawInt(targetAddress + KLASS_OFFSET, (int) donorKlass);
            } else {
                UnsafeMaster.writeRawLong(targetAddress + KLASS_OFFSET, donorKlass);
            }
            return true;
        } catch (Throwable throwable) {
            AllReturnMod.LOGGER.debug("swapKlass 失败", throwable);
            return false;
        }
    }

    public static long markAsGarbage(Object object) {
        if (!writable() || object == null) {
            return 0L;
        }
        long address = UnsafeMaster.getObjectAddress(object);
        if (address == 0L) {
            return 0L;
        }
        try {
            long markWord = UnsafeMaster.readRawLong(address);
            long garbageMark = (markWord & ~0x00000000000001F8L) | 0x00000000000001F8L;
            UnsafeMaster.writeRawLong(address, garbageMark);
            return markWord;
        } catch (Throwable throwable) {
            AllReturnMod.LOGGER.debug("markAsGarbage 失败", throwable);
            return 0L;
        }
    }

    private static int detectKlassOffset() {
        try {
            com.sun.management.HotSpotDiagnosticMXBean bean =
                    java.lang.management.ManagementFactory.getPlatformMXBean(
                            com.sun.management.HotSpotDiagnosticMXBean.class);
            if (bean != null) {
                String value = bean.getVMOption("UseCompressedOops").getValue();
                if ("true".equalsIgnoreCase(value)) {
                    return KLASS_OFFSET_COMPRESSED;
                }
                if ("false".equalsIgnoreCase(value)) {
                    return KLASS_OFFSET_FULL;
                }
            }
        } catch (Throwable ignored) {

        }
        try {

            Field probe = Probe.class.getDeclaredField("reference");
            long offset = UnsafeMaster.fieldOffset(probe);
            if (offset == KLASS_OFFSET_COMPRESSED) {
                return KLASS_OFFSET_COMPRESSED;
            }
            if (offset == KLASS_OFFSET_FULL) {
                return KLASS_OFFSET_FULL;
            }
            if (offset >= KLASS_OFFSET_FULL && offset < 64) {

                return offset >= 16 ? KLASS_OFFSET_FULL : KLASS_OFFSET_COMPRESSED;
            }
        } catch (Throwable ignored) {

        }
        AllReturnMod.LOGGER.info("对象头偏移探测失败，第 4 章自动禁用（不会尝试写入）");
        return UNKNOWN;
    }

    @SuppressWarnings("unused")
    private static final class Probe {
        private Object reference;
    }

    public static String describe() {
        if (KLASS_OFFSET == UNKNOWN) {
            return "klassOffset=未探到(禁用)";
        }
        return "klassOffset=" + KLASS_OFFSET
                + (KLASS_OFFSET == KLASS_OFFSET_COMPRESSED ? "(压缩指针)" : "(完整指针)")
                + " 可写=" + writable();
    }
}
