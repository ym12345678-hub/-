package cn.blockforge.generated.allreturn.combat;

import cn.blockforge.generated.allreturn.AllReturnMod;
import java.lang.reflect.Field;

public final class NativeInjector {
    private static volatile boolean loaded = false;
    private static volatile boolean loadAttempted = false;

    static {
        try {
            System.loadLibrary("native_injector");
            loaded = true;
        } catch (UnsatisfiedLinkError error) {
            AllReturnMod.LOGGER.info("native_injector 库没加载到（正常：需要自行编译 native/ 下的 C++），第 6 章降级：{}",
                    error.toString());
            loaded = false;
        }
        loadAttempted = true;
    }

    private NativeInjector() {
    }

    public static boolean available() {
        return loaded;
    }

    public static native long getObjectAddress(Object obj);

    public static native void nativeWriteFloat(long addr, float value);

    public static native void nativeZeroMemory(long addr, int size);

    public static long safeGetObjectAddress(Object obj) {
        if (!loaded || obj == null) {
            return 0L;
        }
        try {
            return getObjectAddress(obj);
        } catch (Throwable throwable) {
            AllReturnMod.LOGGER.debug("NativeInjector.getObjectAddress 失败", throwable);
            return 0L;
        }
    }

    public static void safeWriteFloat(long addr, float value) {
        if (!loaded || addr == 0L) {
            return;
        }
        try {
            nativeWriteFloat(addr, value);
        } catch (Throwable throwable) {
            AllReturnMod.LOGGER.debug("NativeInjector.nativeWriteFloat 失败", throwable);
        }
    }

    public static void safeZeroMemory(long addr, int size) {
        if (!loaded || addr == 0L || size <= 0) {
            return;
        }
        try {
            nativeZeroMemory(addr, Math.min(size, 4096));
        } catch (Throwable throwable) {
            AllReturnMod.LOGGER.debug("NativeInjector.nativeZeroMemory 失败", throwable);
        }
    }

    public static long fieldOffset(Field field) {
        return UnsafeMaster.fieldOffset(field);
    }
}
