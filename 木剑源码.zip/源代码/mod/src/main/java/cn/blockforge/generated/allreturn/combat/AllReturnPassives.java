package cn.blockforge.generated.allreturn.combat;

import cn.blockforge.generated.allreturn.item.ModGear;
import cn.blockforge.generated.allreturn.state.AllReturnState;
import java.util.List;
import java.util.UUID;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.player.Abilities;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.common.ForgeMod;

public final class AllReturnPassives {

    private static final double REACH_BONUS = 7.0D;

    private static final double BLOCK_REACH_BONUS = 5.0D;

    private static final double STEP_BONUS = 0.6D;

    private static final UUID REACH_ID = UUID.fromString("6f1a0d2c-2b7a-4a1f-9a55-0c1e2d3f4a55");
    private static final UUID BLOCK_REACH_ID = UUID.fromString("7a2b1e3d-3c8b-4b2a-8b66-1d2f3e4a5b66");
    private static final UUID STEP_ID = UUID.fromString("8b3c2f4e-4d9c-4c3b-9c77-2e3a4f5b6c77");

    private AllReturnPassives() {
    }

    public static void apply(Player player) {
        add(player, ForgeMod.ENTITY_REACH.get(), REACH_ID, "all_return_reach", REACH_BONUS);
        add(player, ForgeMod.BLOCK_REACH.get(), BLOCK_REACH_ID, "all_return_block_reach", BLOCK_REACH_BONUS);
        add(player, ForgeMod.STEP_HEIGHT_ADDITION.get(), STEP_ID, "all_return_step", STEP_BONUS);

        Abilities abilities = player.getAbilities();
        if (AllReturnState.isEnabled(player, AllReturnState.FLIGHT)) {
            if (!abilities.mayfly) {
                abilities.mayfly = true;
                player.onUpdateAbilities();
            }
        } else if (abilities.mayfly && !player.isCreative() && !player.isSpectator()) {

            abilities.mayfly = false;
            abilities.flying = false;
            player.onUpdateAbilities();
        }

        resetDurability(player);
    }

    public static void clear(Player player) {
        remove(player, ForgeMod.ENTITY_REACH.get(), REACH_ID);
        remove(player, ForgeMod.BLOCK_REACH.get(), BLOCK_REACH_ID);
        remove(player, ForgeMod.STEP_HEIGHT_ADDITION.get(), STEP_ID);

        Abilities abilities = player.getAbilities();
        if (abilities.mayfly && !player.isCreative() && !player.isSpectator()) {
            abilities.mayfly = false;
            abilities.flying = false;
            player.onUpdateAbilities();
        }
    }

    private static void add(Player player, Attribute attribute, UUID id, String name, double amount) {
        AttributeInstance instance = player.getAttribute(attribute);
        if (instance == null) {
            return;
        }
        if (instance.getModifier(id) == null) {
            instance.addTransientModifier(new AttributeModifier(id, name, amount, AttributeModifier.Operation.ADDITION));
        }
    }

    private static void remove(Player player, Attribute attribute, UUID id) {
        AttributeInstance instance = player.getAttribute(attribute);
        if (instance != null && instance.getModifier(id) != null) {
            instance.removeModifier(id);
        }
    }

    private static void resetDurability(Player player) {
        if (player.tickCount % 10 != 0) {
            return;
        }
        resetStacks(player.getInventory().items);
        resetStacks(player.getInventory().armor);
        resetStacks(player.getInventory().offhand);
    }

    private static void resetStacks(List<ItemStack> stacks) {
        for (ItemStack stack : stacks) {
            if (stack.isEmpty() || stack.getDamageValue() == 0) {
                continue;
            }
            if (stack.getItem() instanceof ModGear && stack.isDamageableItem()) {
                stack.setDamageValue(0);
            }
        }
    }
}
