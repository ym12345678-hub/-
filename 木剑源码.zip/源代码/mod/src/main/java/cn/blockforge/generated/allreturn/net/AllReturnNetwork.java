package cn.blockforge.generated.allreturn.net;

import cn.blockforge.generated.allreturn.AllReturnMod;
import cn.blockforge.generated.allreturn.client.ClientFreeze;
import cn.blockforge.generated.allreturn.client.ClientScreenOpener;
import cn.blockforge.generated.allreturn.combat.AllReturnHooks;
import cn.blockforge.generated.allreturn.combat.InterceptStats;
import cn.blockforge.generated.allreturn.combat.SpawnBan;
import cn.blockforge.generated.allreturn.combat.TimeStop;
import cn.blockforge.generated.allreturn.item.AnnihilationSwordItem;
import cn.blockforge.generated.allreturn.state.AllReturnState;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

public final class AllReturnNetwork {
    private static final String PROTOCOL = "3";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(AllReturnMod.MOD_ID, "main"),
            () -> PROTOCOL,
            PROTOCOL::equals,
            PROTOCOL::equals);

    private AllReturnNetwork() {
    }

    public static void init() {
        int id = 0;
        CHANNEL.registerMessage(id++, TogglePacket.class,
                TogglePacket::encode, TogglePacket::decode, TogglePacket::handle);
        CHANNEL.registerMessage(id++, OpenGuiPacket.class,
                OpenGuiPacket::encode, OpenGuiPacket::decode, OpenGuiPacket::handle);
        CHANNEL.registerMessage(id++, StatePacket.class,
                StatePacket::encode, StatePacket::decode, StatePacket::handle);
        CHANNEL.registerMessage(id++, ClearAreaPacket.class,
                ClearAreaPacket::encode, ClearAreaPacket::decode, ClearAreaPacket::handle);
        CHANNEL.registerMessage(id++, SetFlagsPacket.class,
                SetFlagsPacket::encode, SetFlagsPacket::decode, SetFlagsPacket::handle);
        CHANNEL.registerMessage(id++, RequestOpenPacket.class,
                RequestOpenPacket::encode, RequestOpenPacket::decode, RequestOpenPacket::handle);
        CHANNEL.registerMessage(id++, LookClearPacket.class,
                LookClearPacket::encode, LookClearPacket::decode, LookClearPacket::handle);
        CHANNEL.registerMessage(id++, RightHoldPacket.class,
                RightHoldPacket::encode, RightHoldPacket::decode, RightHoldPacket::handle);
        CHANNEL.registerMessage(id++, WipePacket.class,
                WipePacket::encode, WipePacket::decode, WipePacket::handle);
        CHANNEL.registerMessage(id++, ClearBanPacket.class,
                ClearBanPacket::encode, ClearBanPacket::decode, ClearBanPacket::handle);
        CHANNEL.registerMessage(id++, UnfreezePacket.class,
                UnfreezePacket::encode, UnfreezePacket::decode, UnfreezePacket::handle);
        CHANNEL.registerMessage(id++, FreezePacket.class,
                FreezePacket::encode, FreezePacket::decode, FreezePacket::handle);
    }

    public static void sendFreeze(ServerLevel level, boolean frozen) {
        CHANNEL.send(PacketDistributor.DIMENSION.with(level::dimension), new FreezePacket(frozen));
    }

    public static void sendLookClearToServer() {
        CHANNEL.sendToServer(new LookClearPacket());
    }

    public static void sendRightHoldToServer(boolean start) {
        CHANNEL.sendToServer(new RightHoldPacket(start));
    }

    public static void sendWipeToServer() {
        CHANNEL.sendToServer(new WipePacket());
    }

    public static void sendClearBanToServer() {
        CHANNEL.sendToServer(new ClearBanPacket());
    }

    public static void sendUnfreezeToServer() {
        CHANNEL.sendToServer(new UnfreezePacket());
    }

    public static void sendOpenGui(ServerPlayer player) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player),
                new OpenGuiPacket(AllReturnState.flags(player)));
    }

    public static void sendState(ServerPlayer player, int flags) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new StatePacket(flags));
    }

    public static void sendToggleToServer(int bit, boolean value) {
        CHANNEL.sendToServer(new TogglePacket(bit, value));
    }

    public static void sendClearToServer() {
        CHANNEL.sendToServer(new ClearAreaPacket());
    }

    public static void sendSetAllToServer(boolean on) {
        CHANNEL.sendToServer(new SetFlagsPacket(on ? AllReturnState.ALL_BITS : 0));
    }

    public static void sendOpenRequest() {
        CHANNEL.sendToServer(new RequestOpenPacket());
    }

    public record TogglePacket(int bit, boolean value) {
        public static void encode(TogglePacket message, FriendlyByteBuf buf) {
            buf.writeVarInt(message.bit());
            buf.writeByte(message.value() ? 1 : 0);
        }

        public static TogglePacket decode(FriendlyByteBuf buf) {
            return new TogglePacket(buf.readVarInt(), buf.readByte() != 0);
        }

        public static void handle(TogglePacket message, Supplier<NetworkEvent.Context> supplier) {
            NetworkEvent.Context context = supplier.get();
            context.enqueueWork(() -> {
                ServerPlayer sender = context.getSender();
                if (sender == null) {
                    return;
                }
                int flags = AllReturnState.toggle(sender, message.bit(), message.value());
                sendState(sender, flags);
            });
            context.setPacketHandled(true);
        }
    }

    public record OpenGuiPacket(int flags) {
        public static void encode(OpenGuiPacket message, FriendlyByteBuf buf) {
            buf.writeVarInt(message.flags());
        }

        public static OpenGuiPacket decode(FriendlyByteBuf buf) {
            return new OpenGuiPacket(buf.readVarInt());
        }

        public static void handle(OpenGuiPacket message, Supplier<NetworkEvent.Context> supplier) {
            NetworkEvent.Context context = supplier.get();
            int flags = message.flags();
            context.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                    () -> () -> ClientScreenOpener.open(flags)));
            context.setPacketHandled(true);
        }
    }

    public record StatePacket(int flags) {
        public static void encode(StatePacket message, FriendlyByteBuf buf) {
            buf.writeVarInt(message.flags());
        }

        public static StatePacket decode(FriendlyByteBuf buf) {
            return new StatePacket(buf.readVarInt());
        }

        public static void handle(StatePacket message, Supplier<NetworkEvent.Context> supplier) {
            NetworkEvent.Context context = supplier.get();
            int flags = message.flags();
            context.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                    () -> () -> ClientScreenOpener.sync(flags)));
            context.setPacketHandled(true);
        }
    }

    public record ClearAreaPacket() {
        public static void encode(ClearAreaPacket message, FriendlyByteBuf buf) {
        }

        public static ClearAreaPacket decode(FriendlyByteBuf buf) {
            return new ClearAreaPacket();
        }

        public static void handle(ClearAreaPacket message, Supplier<NetworkEvent.Context> supplier) {
            NetworkEvent.Context context = supplier.get();
            context.enqueueWork(() -> {
                ServerPlayer sender = context.getSender();
                if (sender == null || !AllReturnState.isEnabled(sender, AllReturnState.ALLRETURN)) {
                    return;
                }
                int killed = AllReturnHooks.clearArea(sender);
                sender.displayClientMessage(Component.translatable("message.all_return.cleared", killed), true);
            });
            context.setPacketHandled(true);
        }
    }

    public record SetFlagsPacket(int flags) {
        public static void encode(SetFlagsPacket message, FriendlyByteBuf buf) {
            buf.writeVarInt(message.flags());
        }

        public static SetFlagsPacket decode(FriendlyByteBuf buf) {
            return new SetFlagsPacket(buf.readVarInt());
        }

        public static void handle(SetFlagsPacket message, Supplier<NetworkEvent.Context> supplier) {
            NetworkEvent.Context context = supplier.get();
            context.enqueueWork(() -> {
                ServerPlayer sender = context.getSender();
                if (sender == null) {
                    return;
                }
                int flags = AllReturnState.setFlags(sender, message.flags());
                sendState(sender, flags);
            });
            context.setPacketHandled(true);
        }
    }

    public record RequestOpenPacket() {
        public static void encode(RequestOpenPacket message, FriendlyByteBuf buf) {
        }

        public static RequestOpenPacket decode(FriendlyByteBuf buf) {
            return new RequestOpenPacket();
        }

        public static void handle(RequestOpenPacket message, Supplier<NetworkEvent.Context> supplier) {
            NetworkEvent.Context context = supplier.get();
            context.enqueueWork(() -> {
                ServerPlayer sender = context.getSender();
                if (sender != null) {
                    sendOpenGui(sender);
                }
            });
            context.setPacketHandled(true);
        }
    }

    private static boolean armed(ServerPlayer player) {
        return player != null
                && player.getMainHandItem().getItem() instanceof AnnihilationSwordItem
                && AllReturnState.hasGear(player)
                && AllReturnState.isEnabled(player, AllReturnState.ALLRETURN);
    }

    public record LookClearPacket() {
        public static void encode(LookClearPacket message, FriendlyByteBuf buf) {
        }

        public static LookClearPacket decode(FriendlyByteBuf buf) {
            return new LookClearPacket();
        }

        public static void handle(LookClearPacket message, Supplier<NetworkEvent.Context> supplier) {
            NetworkEvent.Context context = supplier.get();
            context.enqueueWork(() -> {
                ServerPlayer sender = context.getSender();
                if (armed(sender)) {
                    AllReturnHooks.eraseLook(sender);
                }
            });
            context.setPacketHandled(true);
        }
    }

    public record RightHoldPacket(boolean start) {
        public static void encode(RightHoldPacket message, FriendlyByteBuf buf) {
            buf.writeByte(message.start() ? 1 : 0);
        }

        public static RightHoldPacket decode(FriendlyByteBuf buf) {
            return new RightHoldPacket(buf.readByte() != 0);
        }

        public static void handle(RightHoldPacket message, Supplier<NetworkEvent.Context> supplier) {
            NetworkEvent.Context context = supplier.get();
            context.enqueueWork(() -> {
                ServerPlayer sender = context.getSender();
                if (!armed(sender)) {
                    if (sender != null) {
                        TimeStop.abandon(sender);
                    }
                    return;
                }
                if (message.start()) {
                    TimeStop.beginHold(sender);
                    return;
                }
                boolean wasFrozen = TimeStop.endHold(sender);
                int erased = AllReturnHooks.eraseDimension(sender);
                long intercepted = InterceptStats.total();
                sender.displayClientMessage(Component.translatable(
                        wasFrozen ? "message.all_return.wiped_after_stop" : "message.all_return.wiped",
                        erased, intercepted), true);
            });
            context.setPacketHandled(true);
        }
    }

    public record WipePacket() {
        public static void encode(WipePacket message, FriendlyByteBuf buf) {
        }

        public static WipePacket decode(FriendlyByteBuf buf) {
            return new WipePacket();
        }

        public static void handle(WipePacket message, Supplier<NetworkEvent.Context> supplier) {
            NetworkEvent.Context context = supplier.get();
            context.enqueueWork(() -> {
                ServerPlayer sender = context.getSender();
                if (!armed(sender)) {
                    return;
                }
                int erased = AllReturnHooks.eraseDimension(sender);
                sender.displayClientMessage(Component.translatable("message.all_return.wiped", erased), true);
            });
            context.setPacketHandled(true);
        }
    }

    public record ClearBanPacket() {
        public static void encode(ClearBanPacket message, FriendlyByteBuf buf) {
        }

        public static ClearBanPacket decode(FriendlyByteBuf buf) {
            return new ClearBanPacket();
        }

        public static void handle(ClearBanPacket message, Supplier<NetworkEvent.Context> supplier) {
            NetworkEvent.Context context = supplier.get();
            context.enqueueWork(() -> {
                ServerPlayer sender = context.getSender();
                if (sender == null) {
                    return;
                }
                int count = SpawnBan.clear();
                sender.displayClientMessage(Component.translatable("message.all_return.bancleared", count), true);
            });
            context.setPacketHandled(true);
        }
    }

    public record UnfreezePacket() {
        public static void encode(UnfreezePacket message, FriendlyByteBuf buf) {
        }

        public static UnfreezePacket decode(FriendlyByteBuf buf) {
            return new UnfreezePacket();
        }

        public static void handle(UnfreezePacket message, Supplier<NetworkEvent.Context> supplier) {
            NetworkEvent.Context context = supplier.get();
            context.enqueueWork(() -> {
                ServerPlayer sender = context.getSender();
                if (sender != null) {
                    TimeStop.abandon(sender);
                }
            });
            context.setPacketHandled(true);
        }
    }

    public record FreezePacket(boolean frozen) {
        public static void encode(FreezePacket message, FriendlyByteBuf buf) {
            buf.writeByte(message.frozen() ? 1 : 0);
        }

        public static FreezePacket decode(FriendlyByteBuf buf) {
            return new FreezePacket(buf.readByte() != 0);
        }

        public static void handle(FreezePacket message, Supplier<NetworkEvent.Context> supplier) {
            NetworkEvent.Context context = supplier.get();
            boolean frozen = message.frozen();
            context.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                    () -> () -> ClientFreeze.set(frozen)));
            context.setPacketHandled(true);
        }
    }
}
