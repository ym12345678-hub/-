package cn.blockforge.generated.allreturn.combat;

import cn.blockforge.generated.allreturn.AllReturnMod;
import java.lang.reflect.Field;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;

public final class UnsafeMaster {

    private static final int MAX_ZERO_BYTES = 4096;

    private static final boolean HARDCORE = Boolean.getBoolean("allreturn.hardcore");

    private static final Object UNSAFE;

    private static final Class<?> UNSAFE_TYPE;

    private static final java.lang.reflect.Method OBJECT_FIELD_OFFSET;
    private static final java.lang.reflect.Method ARRAY_BASE_OFFSET;
    private static final java.lang.reflect.Method PUT_FLOAT;
    private static final java.lang.reflect.Method PUT_INT;
    private static final java.lang.reflect.Method PUT_BOOLEAN;
    private static final java.lang.reflect.Method PUT_LONG;
    private static final java.lang.reflect.Method GET_LONG;
    private static final java.lang.reflect.Method GET_FLOAT;
    private static final java.lang.reflect.Method PUT_OBJECT;

    private static final java.lang.reflect.Method RAW_GET_LONG;
    private static final java.lang.reflect.Method RAW_GET_INT;
    private static final java.lang.reflect.Method RAW_PUT_LONG;
    private static final java.lang.reflect.Method RAW_PUT_INT;

    static {
        Object unsafe = null;
        Class<?> type = null;
        java.lang.reflect.Method objectFieldOffset = null;
        java.lang.reflect.Method arrayBaseOffset = null;
        java.lang.reflect.Method putFloat = null;
        java.lang.reflect.Method putInt = null;
        java.lang.reflect.Method putBoolean = null;
        java.lang.reflect.Method putLong = null;
        java.lang.reflect.Method getLong = null;
        java.lang.reflect.Method getFloat = null;
        java.lang.reflect.Method putObject = null;
        java.lang.reflect.Method rawGetLong = null;
        java.lang.reflect.Method rawGetInt = null;
        java.lang.reflect.Method rawPutLong = null;
        java.lang.reflect.Method rawPutInt = null;
        try {
            type = Class.forName("sun.misc.Unsafe");
            Field theUnsafe = type.getDeclaredField("theUnsafe");
            theUnsafe.setAccessible(true);
            unsafe = theUnsafe.get(null);
            objectFieldOffset = type.getMethod("objectFieldOffset", Field.class);
            arrayBaseOffset = type.getMethod("arrayBaseOffset", Class.class);
            putFloat = type.getMethod("putFloat", Object.class, long.class, float.class);
            putInt = type.getMethod("putInt", Object.class, long.class, int.class);
            putBoolean = type.getMethod("putBoolean", Object.class, long.class, boolean.class);
            putLong = type.getMethod("putLong", Object.class, long.class, long.class);
            getLong = type.getMethod("getLong", Object.class, long.class);
            getFloat = type.getMethod("getFloat", Object.class, long.class);
            putObject = type.getMethod("putObject", Object.class, long.class, Object.class);
            rawGetLong = type.getMethod("getLong", long.class);
            rawGetInt = type.getMethod("getInt", long.class);
            rawPutLong = type.getMethod("putLong", long.class, long.class);
            rawPutInt = type.getMethod("putInt", long.class, int.class);
        } catch (Throwable throwable) {
            AllReturnMod.LOGGER.info("Unsafe 拿不到（JDK 17 模块化限制），第 2 章自动降级：{}",
                    throwable.toString());
            unsafe = null;
        }
        UNSAFE = unsafe;
        UNSAFE_TYPE = type;
        OBJECT_FIELD_OFFSET = objectFieldOffset;
        ARRAY_BASE_OFFSET = arrayBaseOffset;
        PUT_FLOAT = putFloat;
        PUT_INT = putInt;
        PUT_BOOLEAN = putBoolean;
        PUT_LONG = putLong;
        GET_LONG = getLong;
        GET_FLOAT = getFloat;
        PUT_OBJECT = putObject;
        RAW_GET_LONG = rawGetLong;
        RAW_GET_INT = rawGetInt;
        RAW_PUT_LONG = rawPutLong;
        RAW_PUT_INT = rawPutInt;
    }

    private static volatile long healthOffset = Long.MIN_VALUE;
    private static volatile long deadOffset = Long.MIN_VALUE;
    private static volatile long reasonOffset = Long.MIN_VALUE;
    private static volatile long removalReasonOffsetResolved = Long.MIN_VALUE;

    private UnsafeMaster() {
    }

    public static boolean available() {
        return UNSAFE != null && OBJECT_FIELD_OFFSET != null;
    }

    public static boolean hardcore() {
        return HARDCORE;
    }

    public static long getObjectAddress(Object object) {
        if (!available() || object == null) {
            return 0L;
        }
        try {
            Object[] array = new Object[]{object};
            long base = (long) ARRAY_BASE_OFFSET.invoke(UNSAFE, Object[].class);
            return (long) GET_LONG.invoke(UNSAFE, array, base);
        } catch (Throwable throwable) {
            AllReturnMod.LOGGER.debug("取对象地址失败", throwable);
            return 0L;
        }
    }

    public static boolean forceSetHealth(LivingEntity entity, float health) {
        if (!available() || entity == null) {
            return false;
        }
        boolean touched = false;
        long offset = healthOffset();
        if (offset != Long.MIN_VALUE) {
            try {
                PUT_FLOAT.invoke(UNSAFE, entity, offset, health);
                touched = true;
            } catch (Throwable throwable) {
                AllReturnMod.LOGGER.debug("Unsafe 写 health 失败", throwable);
            }
        }
        if (health <= 0.0F) {
            long dead = deadOffset();
            if (dead != Long.MIN_VALUE) {
                try {
                    PUT_BOOLEAN.invoke(UNSAFE, entity, dead, true);
                    touched = true;
                } catch (Throwable throwable) {
                    AllReturnMod.LOGGER.debug("Unsafe 写 dead 失败", throwable);
                }
            }
            long reason = reasonOffset();
            if (reason != Long.MIN_VALUE) {
                try {
                    PUT_OBJECT.invoke(UNSAFE, entity, reason, Entity.RemovalReason.KILLED);
                    touched = true;
                } catch (Throwable throwable) {
                    AllReturnMod.LOGGER.debug("Unsafe 写 removalReason 失败", throwable);
                }
            }
        }
        return touched;
    }

    public static int zeroMemory(Object object, int size) {
        if (!available() || !HARDCORE || object == null) {
            return 0;
        }
        long address = getObjectAddress(object);
        if (address == 0L) {
            return 0;
        }
        int bytes = Math.max(0, Math.min(size, MAX_ZERO_BYTES));
        try {
            for (int i = 0; i < bytes; i += 8) {
                PUT_LONG.invoke(UNSAFE, address + i, 0L);
            }
            return bytes;
        } catch (Throwable throwable) {
            AllReturnMod.LOGGER.debug("zeroMemory 失败", throwable);
            return 0;
        }
    }

    public static java.util.List<String> dumpMemory(Object object, int size) {
        java.util.List<String> lines = new java.util.ArrayList<>();
        if (!available() || object == null) {
            return lines;
        }
        long address = getObjectAddress(object);
        if (address == 0L) {
            return lines;
        }
        int bytes = Math.max(0, Math.min(size, MAX_ZERO_BYTES));
        try {
            for (int i = 0; i < bytes; i += 8) {
                long value = (long) GET_LONG.invoke(UNSAFE, address + i);
                lines.add(String.format("[0x%04X] 0x%016X", i, value));
            }
        } catch (Throwable throwable) {
            lines.add("读取失败：" + throwable);
        }
        return lines;
    }

    public static float readHealth(LivingEntity entity) {
        if (!available() || entity == null) {
            return Float.NaN;
        }
        long offset = healthOffset();
        if (offset == Long.MIN_VALUE) {
            return Float.NaN;
        }
        try {
            return (float) GET_FLOAT.invoke(UNSAFE, entity, offset);
        } catch (Throwable throwable) {
            return Float.NaN;
        }
    }

    public static long fieldOffset(Field field) {
        if (!available() || field == null) {
            return -1L;
        }
        try {
            return (long) OBJECT_FIELD_OFFSET.invoke(UNSAFE, field);
        } catch (Throwable throwable) {
            return -1L;
        }
    }

    public static long readRawLong(long address) {
        if (!available() || address == 0L || RAW_GET_LONG == null) {
            return 0L;
        }
        try {
            return (long) RAW_GET_LONG.invoke(UNSAFE, address);
        } catch (Throwable throwable) {
            return 0L;
        }
    }

    public static int readRawInt(long address) {
        if (!available() || address == 0L || RAW_GET_INT == null) {
            return 0;
        }
        try {
            return (int) RAW_GET_INT.invoke(UNSAFE, address);
        } catch (Throwable throwable) {
            return 0;
        }
    }

    public static boolean writeRawLong(long address, long value) {
        if (!available() || address == 0L || RAW_PUT_LONG == null) {
            return false;
        }
        try {
            RAW_PUT_LONG.invoke(UNSAFE, address, value);
            return true;
        } catch (Throwable throwable) {
            return false;
        }
    }

    public static boolean writeRawInt(long address, int value) {
        if (!available() || address == 0L || RAW_PUT_INT == null) {
            return false;
        }
        try {
            RAW_PUT_INT.invoke(UNSAFE, address, value);
            return true;
        } catch (Throwable throwable) {
            return false;
        }
    }

    private static long healthOffset() {
        long cached = healthOffset;
        if (cached != Long.MIN_VALUE) {
            return cached;
        }
        long resolved = offsetOf(LivingEntity.class, new String[]{"health", "f_20920_"}, float.class, "ealth");
        healthOffset = resolved;
        return resolved;
    }

    private static long deadOffset() {
        long cached = deadOffset;
        if (cached != Long.MIN_VALUE) {
            return cached;
        }
        long resolved = offsetOf(LivingEntity.class, new String[]{"dead", "f_20921_"}, boolean.class, "dead");
        deadOffset = resolved;
        return resolved;
    }

    private static long reasonOffset() {
        long cached = reasonOffset;
        if (cached != Long.MIN_VALUE) {
            return cached;
        }
        long resolved = offsetOf(Entity.class, new String[]{"removalReason", "f_19855_"},
                Entity.RemovalReason.class, "Reason");
        reasonOffset = resolved;
        return resolved;
    }

    private static long offsetOf(Class<?> owner, String[] names, Class<?> type, String hint) {
        Field field = locate(owner, names, type, hint);
        if (field == null) {
            return Long.MIN_VALUE;
        }
        try {
            return (long) OBJECT_FIELD_OFFSET.invoke(UNSAFE, field);
        } catch (Throwable throwable) {
            AllReturnMod.LOGGER.debug("取字段偏移失败：{}", field.getName(), throwable);
            return Long.MIN_VALUE;
        }
    }

    private static Field locate(Class<?> owner, String[] names, Class<?> type, String hint) {
        for (String name : names) {
            for (Class<?> current = owner; current != null && current != Object.class; current = current.getSuperclass()) {
                try {
                    Field field = current.getDeclaredField(name);
                    if (field.getType() == type) {
                        return field;
                    }
                } catch (NoSuchFieldException ignored) {

                }
            }
        }
        for (Class<?> current = owner; current != null && current != Object.class; current = current.getSuperclass()) {
            for (Field field : current.getDeclaredFields()) {
                if (field.getType() == type && field.getName().contains(hint)) {
                    return field;
                }
            }
        }
        return null;
    }
}
