package cn.blockforge.generated.allreturn.win;

import java.io.InputStream;
import java.lang.management.ManagementFactory;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

/**
 * 负责把 {@code allreturn_jvmti.dll} 装进 JVM。
 *
 * <p>按这个顺序找：
 * <ol>
 *   <li>JVM 启动参数里的 {@code -agentpath:<path>}：用户已经指定了路径，
 *       直接 {@code System.load} 那个文件（Windows 上重复加载同一模块是安全的，
 *       而且只有这样 JNI 方法表才对 Java 可见）；</li>
 *   <li>{@code System.loadLibrary("allreturn_jvmti")}：DLL 在
 *       {@code java.library.path} 或游戏目录里；</li>
 *   <li>jar 里自带的 {@code native/windows-x64/allreturn_jvmti.dll}：
 *       解压到临时目录再 load，适合「拖进 mods 就能用」；</li>
 *   <li>游戏目录 / 当前目录下的 {@code allreturn_jvmti.dll}。</li>
 * </ol>
 *
 * <p>任何一个成功就返回 true；全失败也只是原生层不可用，模组照常跑。
 */
final class WinBridge {

    private static final String LIB_NAME = "allreturn_jvmti";

    private static final String RESOURCE = "/native/windows-x64/allreturn_jvmti.dll";

    private static volatile boolean booted;

    private static volatile Path loadedFrom;

    private WinBridge() {
    }

    static synchronized boolean loadLibrary() {
        if (booted) {
            return true;
        }
        if (!isWindows()) {
            WinLog.info("不是 Windows，原生拦截层跳过（这一层本来就只有 Windows 版）。");
            return false;
        }
        if (tryAgentPath()) {
            booted = true;
            return true;
        }
        if (trySystemLoad()) {
            booted = true;
            return true;
        }
        if (tryExtractFromJar()) {
            booted = true;
            return true;
        }
        if (tryLooseFile()) {
            booted = true;
            return true;
        }
        WinLog.info("没找到 allreturn_jvmti.dll，原生拦截层不可用；"
                + "把 DLL 放到游戏目录，或用 -agentpath:... 启动即可启用。");
        return false;
    }

    private static boolean isWindows() {
        return System.getProperty("os.name", "").toLowerCase().contains("win");
    }

    /**
     * 用户用 {@code -agentpath:...} 启动时，从 JVM 参数里把这个路径捞出来再 load 一次。
     *
     * <p>为什么必须再 load 一次：{@code -agentpath} 加载的库虽然已经装好了 JVMTI，
     * 但 JVM 并不会把它的 JNI 方法表挂到 Java 的 native 解析链上（实测
     * {@code nativeRegister} 会抛 UnsatisfiedLinkError）。用 {@code System.load}
     * 显式打开同一个文件之后，JNI 就正常了；Windows 对同一模块的重复加载是引用计数，
     * 不会真的装两遍。
     */
    private static boolean tryAgentPath() {
        try {
            for (String arg : ManagementFactory.getRuntimeMXBean().getInputArguments()) {
                if (arg == null || !arg.startsWith("-agentpath:")) {
                    continue;
                }
                String raw = arg.substring("-agentpath:".length());
                int eq = raw.indexOf('=');
                if (eq > 0) {
                    raw = raw.substring(0, eq);
                }
                Path dll = Paths.get(raw);
                if (!Files.isRegularFile(dll)) {
                    continue;
                }
                System.load(dll.toAbsolutePath().toString());
                loadedFrom = dll.toAbsolutePath();
                WinLog.info("原生库按启动参数加载：" + loadedFrom);
                return true;
            }
        } catch (Throwable throwable) {
            WinLog.warn("按 -agentpath 二次加载失败（不影响已装上的 JVMTI）：" + throwable);
        }
        return false;
    }

    private static boolean trySystemLoad() {
        try {
            System.loadLibrary(LIB_NAME);
            loadedFrom = Paths.get(LIB_NAME + ".dll");
            WinLog.info("原生库已从 java.library.path 加载：" + LIB_NAME);
            return true;
        } catch (Throwable throwable) {
            return false;
        }
    }

    private static boolean tryExtractFromJar() {
        try (InputStream in = WinBridge.class.getResourceAsStream(RESOURCE)) {
            if (in == null) {
                return false;
            }
            Path dir = Files.createTempDirectory("allreturn-native");
            Path dll = dir.resolve(LIB_NAME + ".dll");
            Files.copy(in, dll, StandardCopyOption.REPLACE_EXISTING);
            dir.toFile().deleteOnExit();
            dll.toFile().deleteOnExit();
            System.load(dll.toAbsolutePath().toString());
            loadedFrom = dll;
            WinLog.info("原生库已从 jar 解压加载：" + dll);
            return true;
        } catch (Throwable throwable) {
            WinLog.warn("从 jar 解压原生库失败：" + throwable);
            return false;
        }
    }

    private static boolean tryLooseFile() {
        String[] candidates = {
                "allreturn_jvmti.dll",
                System.getProperty("user.dir", ".") + "/allreturn_jvmti.dll"
        };
        for (String candidate : candidates) {
            try {
                Path path = Paths.get(candidate);
                if (!Files.isRegularFile(path)) {
                    continue;
                }
                System.load(path.toAbsolutePath().toString());
                loadedFrom = path.toAbsolutePath();
                WinLog.info("原生库已加载：" + loadedFrom);
                return true;
            } catch (Throwable ignored) {
            }
        }
        return false;
    }

    static Path loadedFrom() {
        return loadedFrom;
    }
}
