package cn.blockforge.generated.allreturn.combat;

import cn.blockforge.generated.allreturn.AllReturnMod;
import cn.blockforge.generated.allreturn.item.AnnihilationSwordItem;
import cn.blockforge.generated.allreturn.item.ModGear;
import cn.blockforge.generated.allreturn.net.AllReturnNetwork;
import cn.blockforge.generated.allreturn.state.AllReturnState;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.EntityTeleportEvent;
import net.minecraftforge.event.entity.ProjectileImpactEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingConversionEvent;
import net.minecraftforge.event.entity.living.LivingDamageEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingDestroyBlockEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.event.entity.living.LivingHealEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.living.LivingKnockBackEvent;
import net.minecraftforge.event.entity.living.LivingUseTotemEvent;
import net.minecraftforge.event.entity.living.MobEffectEvent;
import net.minecraftforge.event.entity.living.MobSpawnEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.event.level.ExplosionEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = AllReturnMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class CombatEvents {
    private CombatEvents() {
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        Player player = event.player;
        if (player.level().isClientSide) {
            return;
        }
        if (player.tickCount % 20 == 0) {
            AllReturnState.applyFlag(player);
        }
        if (!AllReturnState.hasGear(player)) {

            AllReturnPassives.clear(player);
            SovereignGuard.clear(player.getUUID());

            if (!player.isCreative() && !player.isSpectator()) {
                player.setInvulnerable(false);
            }
            return;
        }
        AllReturnPassives.apply(player);

        if (player instanceof ServerPlayer serverPlayer) {
            SovereignGuard.tick(serverPlayer);
        }
        player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 60, 4, true, false, false));
        player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 60, 1, true, false, false));
        player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 60, 2, true, false, false));
        player.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 60, 0, true, false, false));
        player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 60, 1, true, false, false));

        if (AllReturnState.isGod(player)) {
            if (!player.isCreative() && !player.isSpectator()) {
                player.setInvulnerable(true);
            }
            if (player.isDeadOrDying() || player.getHealth() <= 0.0F) {
                player.setHealth(player.getMaxHealth());
                ReflectPurge.clearDead(player);
                ReflectPurge.clearInvulnerableTime(player);
            }

            if (player.hurtTime > 0) {
                player.hurtTime = 0;
            }
            if (player.deathTime > 0) {
                player.deathTime = 0;
            }
        } else {
            if (!player.isCreative() && !player.isSpectator()) {
                player.setInvulnerable(false);
            }
        }
    }

    @SubscribeEvent
    public static void onAttackEntity(AttackEntityEvent event) {
        Player player = event.getEntity();
        if (player.level().isClientSide) {
            return;
        }
        if (player instanceof ServerPlayer serverPlayer && FinalSay.isDoomed(serverPlayer)) {
            event.setCanceled(true);
            return;
        }
        Entity target = event.getTarget();
        if (!(target instanceof LivingEntity living) || living == player) {
            return;
        }
        if (AllReturnHooks.onGearAttack(player, living, player.getMainHandItem())) {

            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        Player player = event.getEntity();
        if (!(event.getItemStack().getItem() instanceof ModGear)) {
            return;
        }
        if (player.isShiftKeyDown()) {
            if (player.level().isClientSide) {

                return;
            }
            event.setCanceled(true);
            event.setCancellationResult(InteractionResult.SUCCESS);
            if (player instanceof ServerPlayer serverPlayer) {
                AllReturnNetwork.sendOpenGui(serverPlayer);
            }
            return;
        }

        if (event.getItemStack().getItem() instanceof AnnihilationSwordItem) {
            event.setCanceled(true);
            event.setCancellationResult(InteractionResult.SUCCESS);
        }
    }

    @SubscribeEvent
    public static void onLivingAttack(LivingAttackEvent event) {
        LivingEntity victim = event.getEntity();
        if (victim.level().isClientSide) {
            return;
        }

        if (TimeStop.isFrozen(victim.level())) {
            event.setCanceled(true);
            InterceptStats.blocked();
            return;
        }
        if (!(victim instanceof Player player)) {
            return;
        }
        if (!AllReturnState.hasGear(player)) {
            return;
        }
        DamageSource source = event.getSource();
        if (source.getEntity() instanceof ServerPlayer attacker && FinalSay.isDoomed(attacker)) {
            event.setCanceled(true);
            return;
        }

        if (AllReturnState.isGod(player)) {
            event.setCanceled(true);
            return;
        }

        if (AllReturnState.isEnabled(player, AllReturnState.REFLECT)) {
            Entity attacker = source.getEntity();
            if (attacker instanceof LivingEntity livingAttacker && livingAttacker != player) {
                AllReturnHooks.reflect(player, livingAttacker, event.getAmount());
            }
        }

        if (source.is(DamageTypeTags.IS_FALL)) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onLivingHurt(LivingHurtEvent event) {
        LivingEntity victim = event.getEntity();
        if (victim.level().isClientSide) {
            return;
        }

        if (TimeStop.isFrozen(victim.level())) {
            event.setCanceled(true);
            InterceptStats.blocked();
            return;
        }

        if (victim instanceof Player player && AllReturnState.isGod(player)) {
            event.setCanceled(true);
            return;
        }
        Player attacker = AllReturnHooks.attackerOf(event.getSource());
        if (attacker == null || attacker == victim) {
            return;
        }
        if (!AllReturnState.hasGear(attacker) || !AllReturnState.isEnabled(attacker, AllReturnState.ALLRETURN)) {
            return;
        }
        if (AllReturnState.isEnabled(attacker, AllReturnState.LOCK)) {
            AllReturnState.suppress(victim);
        }
        boolean oneKill = AllReturnState.isEnabled(attacker, AllReturnState.ONE_KILL);
        event.setAmount(Math.max(event.getAmount(), oneKill ? AllReturnHooks.OVERKILL : AllReturnHooks.BASE_FORCE_DAMAGE));
    }

    @SubscribeEvent
    public static void onLivingDamage(LivingDamageEvent event) {
        LivingEntity victim = event.getEntity();
        if (victim.level().isClientSide) {
            return;
        }

        if (TimeStop.isFrozen(victim.level())) {
            event.setCanceled(true);
            InterceptStats.blocked();
            return;
        }

        if (victim instanceof Player player && AllReturnState.isGod(player)) {
            event.setCanceled(true);
            return;
        }
        Player attacker = AllReturnHooks.attackerOf(event.getSource());
        if (attacker == null || attacker == victim) {
            return;
        }
        if (!AllReturnState.hasGear(attacker) || !AllReturnState.isEnabled(attacker, AllReturnState.ALLRETURN)) {
            return;
        }
        if (AllReturnState.isEnabled(attacker, AllReturnState.ONE_KILL)) {
            event.setAmount(Math.max(event.getAmount(), AllReturnHooks.OVERKILL));
        }
    }

    @SubscribeEvent
    public static void onLivingHeal(LivingHealEvent event) {
        LivingEntity entity = event.getEntity();
        if (entity.level().isClientSide) {
            return;
        }

        if (FinalSay.isDoomed(entity)) {
            event.setCanceled(true);
            InterceptStats.blocked();
            return;
        }

        if (TimeStop.freezes(entity)) {
            event.setCanceled(true);
            InterceptStats.blocked();
            return;
        }
        if (AllReturnState.isSuppressed(entity)) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onUseTotem(LivingUseTotemEvent event) {
        LivingEntity entity = event.getEntity();
        if (entity.level().isClientSide) {
            return;
        }
        if (AllReturnState.isSuppressed(entity) || FinalSay.isDoomed(entity)) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent(priority = EventPriority.LOWEST, receiveCanceled = true)
    public static void onEffectApplicable(MobEffectEvent.Applicable event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) {
            return;
        }
        MobEffectInstance instance = event.getEffectInstance();
        if (instance == null) {
            return;
        }
        if (FinalSay.isDoomed(player)) {
            if (event.isCancelable()) {
                event.setCanceled(true);
            }
            InterceptStats.blocked();
            return;
        }
        if (SovereignGuard.isSovereign(player)
                && instance.getEffect().getCategory() == MobEffectCategory.HARMFUL) {
            if (event.isCancelable()) {
                event.setCanceled(true);
            }
            InterceptStats.blocked();
        }
    }

    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone event) {
        if (event.getOriginal() instanceof ServerPlayer oldPlayer
                && event.getEntity() instanceof ServerPlayer newPlayer) {
            newPlayer.getPersistentData().merge(oldPlayer.getPersistentData());
            AllReturnNetwork.sendState(newPlayer, AllReturnState.flags(newPlayer));
        }
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent event) {
        LivingEntity victim = event.getEntity();
        if (victim.level().isClientSide) {
            return;
        }

        if (FinalSay.isDoomed(victim)) {
            InterceptStats.blocked();
            return;
        }

        if (victim instanceof Player player && AllReturnState.isGod(player)) {
            event.setCanceled(true);
            ReflectPurge.forceSetHealth(victim, victim.getMaxHealth());
            ReflectPurge.clearDead(victim);
            return;
        }
        AllReturnState.clearSuppressed(victim);
    }

    @SubscribeEvent
    public static void onLivingTick(LivingEvent.LivingTickEvent event) {
        if (event.getEntity().level().isClientSide) {
            return;
        }
        if (TimeStop.freezes(event.getEntity())) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onNeighborNotify(BlockEvent.NeighborNotifyEvent event) {
        if (event.getLevel() instanceof Level level && TimeStop.isFrozen(level)) {
            event.setCanceled(true);
            InterceptStats.blocked();
        }
    }

    @SubscribeEvent
    public static void onBlockBreak(BlockEvent.BreakEvent event) {
        if (event.getLevel() instanceof Level level && TimeStop.isFrozen(level)
                && !TimeStop.isCaster(event.getPlayer())) {
            event.setCanceled(true);
            InterceptStats.blocked();
        }
    }

    @SubscribeEvent
    public static void onBlockPlace(BlockEvent.EntityPlaceEvent event) {
        if (!(event.getLevel() instanceof Level level) || !TimeStop.isFrozen(level)) {
            return;
        }
        Entity placer = event.getEntity();
        if (placer == null || !TimeStop.isCaster(placer)) {
            event.setCanceled(true);
            InterceptStats.blocked();
        }
    }

    @SubscribeEvent
    public static void onKnockBack(LivingKnockBackEvent event) {
        if (TimeStop.freezes(event.getEntity())) {
            event.setCanceled(true);
            InterceptStats.blocked();
        }
    }

    @SubscribeEvent
    public static void onExplosionStart(ExplosionEvent.Start event) {
        if (TimeStop.isFrozen(event.getLevel())) {
            event.setCanceled(true);
            InterceptStats.blocked();
        }
    }

    @SubscribeEvent
    public static void onProjectileImpact(ProjectileImpactEvent event) {
        if (event.getProjectile() != null && TimeStop.isFrozen(event.getProjectile().level())) {
            event.setImpactResult(ProjectileImpactEvent.ImpactResult.STOP_AT_CURRENT_NO_DAMAGE);
            InterceptStats.blocked();
        }
    }

    @SubscribeEvent
    public static void onTeleport(EntityTeleportEvent event) {
        Entity entity = event.getEntity();
        if (entity != null && TimeStop.freezes(entity)) {
            event.setCanceled(true);
            InterceptStats.blocked();
        }
    }

    @SubscribeEvent
    public static void onConversion(LivingConversionEvent.Pre event) {
        if (TimeStop.freezes(event.getEntity())) {
            event.setCanceled(true);
            InterceptStats.blocked();
        }
    }

    @SubscribeEvent
    public static void onMobGrief(LivingDestroyBlockEvent event) {
        if (TimeStop.freezes(event.getEntity())) {
            event.setCanceled(true);
            InterceptStats.blocked();
        }
    }

    @SubscribeEvent
    public static void onEntityJoin(EntityJoinLevelEvent event) {
        if (event.getLevel().isClientSide()) {
            return;
        }
        Entity entity = event.getEntity();

        if (entity instanceof Player) {
            return;
        }

        if (ErasureWatch.isBlocked(entity.getUUID())) {
            event.setCanceled(true);
            InterceptStats.blocked();
            return;
        }

        if (event.loadedFromDisk()) {
            return;
        }

        if (TimeStop.isFrozen(event.getLevel())) {
            event.setCanceled(true);
            InterceptStats.blocked();
            return;
        }
        if (entity instanceof Mob mob && SpawnBan.isBanned(mob.getType())) {
            event.setCanceled(true);
            InterceptStats.blocked();
        }
    }

    @SubscribeEvent
    public static void onFinalizeSpawn(MobSpawnEvent.FinalizeSpawn event) {
        Mob mob = event.getEntity();
        if (mob.level().isClientSide) {
            return;
        }
        if (TimeStop.isFrozen(mob.level()) || SpawnBan.isBanned(mob.getType())) {
            event.setSpawnCancelled(true);
            InterceptStats.blocked();
        }
    }

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        IntegrityWatch.heartbeat();
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        TimeStop.tickServer(event.getServer());

        ErasureWatch.tick(event.getServer());

        FinalSay.tick(event.getServer());
    }

    @SubscribeEvent
    public static void onLoggedOut(PlayerEvent.PlayerLoggedOutEvent event) {
        if (event.getEntity() instanceof ServerPlayer serverPlayer) {
            TimeStop.playerGone(serverPlayer);
            SovereignGuard.clear(serverPlayer.getUUID());
        }
    }

    @SubscribeEvent(priority = EventPriority.LOWEST, receiveCanceled = true)
    public static void onSovereignAttack(LivingAttackEvent event) {
        if (event.getEntity() instanceof ServerPlayer player
                && SovereignGuard.shield(player, event.getSource(), event.getAmount())) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent(priority = EventPriority.LOWEST, receiveCanceled = true)
    public static void onSovereignHurt(LivingHurtEvent event) {
        if (event.getEntity() instanceof ServerPlayer player
                && SovereignGuard.shield(player, event.getSource(), event.getAmount())) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent(priority = EventPriority.LOWEST, receiveCanceled = true)
    public static void onSovereignDamage(LivingDamageEvent event) {
        if (event.getEntity() instanceof ServerPlayer player
                && SovereignGuard.shield(player, event.getSource(), event.getAmount())) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent(priority = EventPriority.LOWEST, receiveCanceled = true)
    public static void onSovereignDeath(LivingDeathEvent event) {
        if (event.getEntity() instanceof ServerPlayer player
                && SovereignGuard.isSovereign(player)
                && !FinalSay.isDoomed(player)) {
            event.setCanceled(true);
            SovereignGuard.revive(player);
        }
    }

    @SubscribeEvent(priority = EventPriority.LOWEST, receiveCanceled = true)
    public static void onDoomedInteract(PlayerInteractEvent event) {
        if (event.getEntity() instanceof ServerPlayer player && FinalSay.isDoomed(player)) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent(priority = EventPriority.LOWEST, receiveCanceled = true)
    public static void onSovereignKnockback(LivingKnockBackEvent event) {
        if (event.getEntity() instanceof ServerPlayer player && SovereignGuard.isSovereign(player)) {
            event.setCanceled(true);
        }
    }
}
