package cn.blockforge.generated.allreturn.agent;

import java.io.InputStream;
import java.lang.instrument.ClassDefinition;
import java.lang.instrument.ClassFileTransformer;
import java.lang.instrument.Instrumentation;
import java.lang.management.ManagementFactory;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.ProtectionDomain;
import java.util.Enumeration;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

public final class SelfGuard {
    private static final String PREFIX = "cn/blockforge/generated/allreturn/";
    private static final String AGENT_PREFIX = "cn/blockforge/generated/allreturn/agent/";
    private static final String INSTALLED_PROPERTY = "allreturn.selfguard.installed";
    private static final String STATUS_PROPERTY = "allreturn.selfguard.status";
    private static final Map<String, byte[]> ORIGINALS = new ConcurrentHashMap<>();

    private static volatile Instrumentation instrumentation;
    private static volatile SelfGuardTransformer transformer;
    private static volatile boolean watchdogStarted;
    private static volatile int healCount;
    private static volatile long lastHeal;

    private SelfGuard() {
    }

    public static synchronized void install(Instrumentation inst, String source) {
        if (inst == null) {
            log("Instrumentation 为空，自愈层不可用");
            return;
        }
        instrumentation = inst;
        if (ORIGINALS.isEmpty()) {
            loadOriginals();
        }
        if (transformer == null) {
            transformer = new SelfGuardTransformer();
            try {
                inst.addTransformer(transformer, true);
                log("自愈 transformer 已注册");
            } catch (Throwable throwable) {
                log("自愈 transformer 注册失败：" + throwable);
            }
        }
        System.setProperty(INSTALLED_PROPERTY, "true");
        log("自愈层已加载（" + source + "），原始类 " + ORIGINALS.size() + " 个");
        startWatchdog();
    }

    public static void ensure() {
        if (instrumentation != null) {
            startWatchdog();
            return;
        }
        if (Boolean.getBoolean(INSTALLED_PROPERTY)) {

            return;
        }
        try {
            System.setProperty("jdk.attach.allowAttachSelf", "true");
            String jar = ownJar();
            if (jar == null) {
                log("找不到自身 jar，自 attach 跳过；可改用 -javaagent");
                return;
            }
            Class<?> vmClass = Class.forName("com.sun.tools.attach.VirtualMachine");
            Object vm = vmClass.getMethod("attach", String.class).invoke(null, pid());
            try {
                vmClass.getMethod("loadAgent", String.class).invoke(vm, jar);
                log("自 attach 成功：" + jar);
            } finally {
                try {
                    vmClass.getMethod("detach").invoke(vm);
                } catch (Throwable ignored) {
                }
            }
        } catch (Throwable throwable) {
            log("自 attach 失败（可改用 -javaagent）：" + throwable);
        }
    }

    public static String status() {
        if (instrumentation == null && Boolean.getBoolean(INSTALLED_PROPERTY)) {
            return System.getProperty(STATUS_PROPERTY, "agent=installed");
        }
        return "instrumented=" + (instrumentation != null)
                + " originals=" + ORIGINALS.size()
                + " healed=" + healCount
                + " last=" + (lastHeal == 0L ? "never" : (System.currentTimeMillis() - lastHeal) + "ms-ago");
    }

    private static void startWatchdog() {
        if (watchdogStarted) {
            return;
        }
        watchdogStarted = true;
        Thread thread = new Thread(SelfGuard::watch, "all_return-selfguard");
        thread.setDaemon(true);
        thread.start();
        log("看门线程已启动（每 3 秒 redefine 一次自己的类）");
    }

    private static void watch() {

        try {
            Thread.sleep(15_000L);
        } catch (InterruptedException interrupted) {
            Thread.currentThread().interrupt();
            return;
        }
        while (true) {
            try {
                Instrumentation inst = instrumentation;
                if (inst == null) {
                    Thread.sleep(3_000L);
                    continue;
                }
                refreshTransformer(inst);
                int healed = 0;
                for (Class<?> clazz : inst.getAllLoadedClasses()) {
                    if (clazz == null || clazz.isArray() || clazz.isPrimitive() || clazz.isHidden()) {
                        continue;
                    }
                    String name = clazz.getName().replace('.', '/');
                    if (!name.startsWith(PREFIX) || name.startsWith(AGENT_PREFIX)) {
                        continue;
                    }
                    byte[] original = ORIGINALS.get(name);
                    if (original == null) {
                        continue;
                    }
                    if (redefine(inst, clazz, original)) {
                        healed++;
                    }
                }
                healCount = healed;
                lastHeal = System.currentTimeMillis();
                System.setProperty(STATUS_PROPERTY,
                        "agent=redefine originals=" + ORIGINALS.size() + " healed=" + healed);
                Thread.sleep(3_000L);
            } catch (InterruptedException interrupted) {
                Thread.currentThread().interrupt();
                return;
            } catch (Throwable throwable) {
                log("看门线程异常：" + throwable);
                try {
                    Thread.sleep(5_000L);
                } catch (InterruptedException interrupted) {
                    Thread.currentThread().interrupt();
                    return;
                }
            }
        }
    }

    private static boolean redefine(Instrumentation inst, Class<?> clazz, byte[] original) {
        try {

            inst.redefineClasses(new ClassDefinition(clazz, original));
            return true;
        } catch (Throwable redefineFailure) {

            try {
                inst.retransformClasses(clazz);
                return true;
            } catch (Throwable ignored) {
                return false;
            }
        }
    }

    private static String pid() {
        String name = ManagementFactory.getRuntimeMXBean().getName();
        int at = name.indexOf('@');
        return at > 0 ? name.substring(0, at) : name;
    }

    private static String ownJar() {
        try {
            ProtectionDomain domain = SelfGuard.class.getProtectionDomain();
            if (domain == null || domain.getCodeSource() == null) {
                return null;
            }
            URL url = domain.getCodeSource().getLocation();
            if (url == null || !"file".equals(url.getProtocol())) {
                return null;
            }
            Path path = Paths.get(url.toURI());
            if (!Files.isRegularFile(path)) {
                return null;
            }
            return path.toAbsolutePath().toString();
        } catch (Throwable throwable) {
            return null;
        }
    }

    private static void loadOriginals() {
        String jar = ownJar();
        if (jar == null) {
            log("不是从 jar 加载，读不到原始字节");
            return;
        }
        try (JarFile jarFile = new JarFile(jar)) {
            Enumeration<JarEntry> entries = jarFile.entries();
            while (entries.hasMoreElements()) {
                JarEntry entry = entries.nextElement();
                String name = entry.getName();
                if (!name.startsWith(PREFIX) || !name.endsWith(".class") || name.startsWith(AGENT_PREFIX)) {
                    continue;
                }
                try (InputStream in = jarFile.getInputStream(entry)) {
                    ORIGINALS.put(name.substring(0, name.length() - ".class".length()), in.readAllBytes());
                }
            }
            log("已缓存 " + ORIGINALS.size() + " 个原始类");
        } catch (Throwable throwable) {
            log("读取原始类失败：" + throwable);
        }
    }

    private static void refreshTransformer(Instrumentation inst) {
        SelfGuardTransformer fresh = new SelfGuardTransformer();
        SelfGuardTransformer old = transformer;
        try {
            inst.addTransformer(fresh, true);
            transformer = fresh;
        } catch (Throwable throwable) {
            log("transformer 挂到链尾失败：" + throwable);
            return;
        }
        if (old != null) {
            try {
                inst.removeTransformer(old);
            } catch (Throwable ignored) {
            }
        }
    }

    private static final class SelfGuardTransformer implements ClassFileTransformer {
        @Override
        public byte[] transform(ClassLoader loader, String className, Class<?> classBeingRedefined,
                                ProtectionDomain protectionDomain, byte[] classfileBuffer) {
            if (className == null || !className.startsWith(PREFIX) || className.startsWith(AGENT_PREFIX)) {
                return null;
            }
            return ORIGINALS.get(className);
        }
    }

    private static void log(String message) {
        System.out.println("[AllReturn SelfGuard] " + message);
    }
}
