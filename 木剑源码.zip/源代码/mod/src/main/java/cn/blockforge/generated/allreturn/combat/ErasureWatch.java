package cn.blockforge.generated.allreturn.combat;

import cn.blockforge.generated.allreturn.AllReturnMod;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;

public final class ErasureWatch {

    private static final int WATCH_TICKS = 100;

    private static final int BLACKLIST_TICKS = 20 * 60 * 5;

    private static final int MAX_TRACKED = 4096;

    private static final int MAX_BLACKLISTED = 8192;

    private static final int SCAN_INTERVAL = 10;

    private static final int SCAN_LIMIT = 512;

    private static final Map<UUID, Track> TRACKS = new ConcurrentHashMap<>();
    private static final Map<UUID, Integer> BLACKLIST = new ConcurrentHashMap<>();
    private static int scanCountdown = SCAN_INTERVAL;

    private ErasureWatch() {
    }

    private static final class Track {
        private final WeakReference<Entity> entity;
        private int ticksLeft;

        private Track(Entity entity, int ticksLeft) {
            this.entity = new WeakReference<>(entity);
            this.ticksLeft = ticksLeft;
        }
    }

    public static void watch(Entity entity) {
        if (entity == null || entity instanceof Player || entity.level().isClientSide) {
            return;
        }
        blocklist(entity.getUUID());
        if (TRACKS.size() >= MAX_TRACKED) {
            prune();
        }
        if (TRACKS.size() >= MAX_TRACKED) {

            return;
        }
        TRACKS.put(entity.getUUID(), new Track(entity, WATCH_TICKS));
    }

    private static void blocklist(UUID id) {
        if (BLACKLIST.size() >= MAX_BLACKLISTED) {
            BLACKLIST.entrySet().removeIf(entry -> entry.getValue() <= 0);
            if (BLACKLIST.size() >= MAX_BLACKLISTED) {
                return;
            }
        }
        BLACKLIST.put(id, BLACKLIST_TICKS);
    }

    public static boolean isBlocked(UUID id) {
        return id != null && BLACKLIST.containsKey(id);
    }

    public static void tick(MinecraftServer server) {
        if (server == null) {
            return;
        }
        if (!TRACKS.isEmpty()) {
            tickTracks();
        }
        if (!BLACKLIST.isEmpty()) {
            tickBlacklist();
        }
        if (--scanCountdown <= 0) {
            scanCountdown = SCAN_INTERVAL;

            if (!BLACKLIST.isEmpty()) {
                scanLevels(server);
            }
        }
    }

    private static void tickTracks() {
        Iterator<Map.Entry<UUID, Track>> iterator = TRACKS.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<UUID, Track> entry = iterator.next();
            Track track = entry.getValue();
            Entity entity = track.entity.get();
            if (entity == null || track.ticksLeft <= 0 || entity.level().isClientSide) {
                iterator.remove();
                continue;
            }
            track.ticksLeft--;

            if (entity.isRemoved()) {
                continue;
            }

            try {
                HardPurge.reseal(entity);
                InterceptStats.resealed();
                track.ticksLeft = WATCH_TICKS;
            } catch (RuntimeException exception) {
                AllReturnMod.LOGGER.debug("回魂重抹失败，这个目标保持原样", exception);
            }
        }
    }

    private static void tickBlacklist() {
        Iterator<Map.Entry<UUID, Integer>> iterator = BLACKLIST.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<UUID, Integer> entry = iterator.next();
            int left = entry.getValue() - 1;
            if (left <= 0) {
                iterator.remove();
            } else {
                entry.setValue(left);
            }
        }
    }

    private static void scanLevels(MinecraftServer server) {
        List<Entity> revived = new ArrayList<>();

        for (ServerLevel level : server.getAllLevels()) {
            if (level == null) {
                continue;
            }
            for (Entity entity : level.getAllEntities()) {
                if (revived.size() >= SCAN_LIMIT) {
                    break;
                }
                if (entity instanceof Player || entity.isRemoved()) {
                    continue;
                }
                if (isBlocked(entity.getUUID())) {
                    revived.add(entity);
                }
            }
        }
        for (Entity entity : revived) {
            try {
                HardPurge.reseal(entity);
                InterceptStats.resealed();
            } catch (RuntimeException exception) {
                AllReturnMod.LOGGER.debug("扫视时抹除失败，这个目标保持原样", exception);
            }
        }
    }

    private static void prune() {
        TRACKS.entrySet().removeIf(entry -> {
            Track track = entry.getValue();
            Entity entity = track.entity.get();
            return entity == null || track.ticksLeft <= 0;
        });
    }

    public static int tracked() {
        return TRACKS.size();
    }

    public static int blocked() {
        return BLACKLIST.size();
    }
}
