package cn.blockforge.generated.allreturn.core;

import java.net.URI;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

public final class ModClassScanner {

    private ModClassScanner() {
    }

    public static Set<String> scan() {
        Set<String> result = new HashSet<>();
        Path mods = Paths.get("mods");
        if (!Files.isDirectory(mods)) {
            return Collections.emptySet();
        }
        Path self = ownJar();
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(mods, "*.jar")) {
            for (Path jarPath : stream) {
                if (jarPath.getFileName().toString().startsWith("all_return")) {
                    continue;
                }
                if (self != null && same(self, jarPath)) {
                    continue;
                }
                try (JarFile jar = new JarFile(jarPath.toFile())) {
                    var entries = jar.entries();
                    while (entries.hasMoreElements()) {
                        JarEntry entry = entries.nextElement();
                        String name = entry.getName();
                        if (!name.endsWith(".class")) {
                            continue;
                        }
                        if (name.startsWith("META-INF/") || name.equals("module-info.class")) {
                            continue;
                        }
                        String className = name.substring(0, name.length() - 6).replace('/', '.');
                        if (className.startsWith("cn.blockforge.")) {
                            continue;
                        }
                        result.add(className);
                    }
                } catch (Throwable ignored) {
                }
            }
        } catch (Throwable ignored) {
        }
        return Collections.unmodifiableSet(result);
    }

    private static Path ownJar() {
        try {
            var source = ModClassScanner.class.getProtectionDomain().getCodeSource();
            if (source == null) {
                return null;
            }
            URI uri = source.getLocation().toURI();
            return Paths.get(uri).toAbsolutePath().normalize();
        } catch (Throwable ignored) {
            return null;
        }
    }

    private static boolean same(Path a, Path b) {
        try {
            return Files.isSameFile(a, b);
        } catch (Throwable ignored) {
            return a.toAbsolutePath().normalize().equals(b.toAbsolutePath().normalize());
        }
    }
}
