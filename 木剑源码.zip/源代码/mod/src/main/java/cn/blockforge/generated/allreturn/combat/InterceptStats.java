package cn.blockforge.generated.allreturn.combat;

import java.util.concurrent.atomic.AtomicLong;
import net.minecraft.network.chat.Component;

public final class InterceptStats {

    private static final AtomicLong ERASED = new AtomicLong();

    private static final AtomicLong KILLED = new AtomicLong();

    private static final AtomicLong BLOCKED = new AtomicLong();

    private static final AtomicLong FROZEN = new AtomicLong();

    private static final AtomicLong RESEALED = new AtomicLong();

    private static final AtomicLong PURGED = new AtomicLong();

    private InterceptStats() {
    }

    public static void erased() {
        ERASED.incrementAndGet();
    }

    public static void killed() {
        KILLED.incrementAndGet();
    }

    public static void blocked() {
        BLOCKED.incrementAndGet();
    }

    public static void frozen() {
        FROZEN.incrementAndGet();
    }

    public static void resealed() {
        RESEALED.incrementAndGet();
    }

    public static void purged() {
        PURGED.incrementAndGet();
    }

    public static long total() {
        return ERASED.get() + KILLED.get() + BLOCKED.get() + RESEALED.get() + PURGED.get();
    }

    public static Component describe() {
        return Component.translatable("message.all_return.stats",
                ERASED.get(), KILLED.get(), BLOCKED.get(), RESEALED.get(), PURGED.get(), FROZEN.get());
    }
}
