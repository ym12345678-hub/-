#version 150

uniform float UiTime;
uniform vec4 ColorModulator;

in vec2 uv;
in vec4 vColor;

out vec4 fragColor;

const float TAU = 6.28318530718;

float hash12(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

float valueNoise(vec2 p) {
    vec2 cell = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = hash12(cell);
    float b = hash12(cell + vec2(1.0, 0.0));
    float c = hash12(cell + vec2(0.0, 1.0));
    float d = hash12(cell + vec2(1.0, 1.0));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

float fbm(vec2 p) {
    float value = 0.0;
    float amp = 0.5;
    for (int i = 0; i < 4; i++) {
        value += amp * valueNoise(p);
        p *= 2.07;
        amp *= 0.52;
    }
    return value;
}

float starLayer(vec2 p, float scale, float threshold, float phase, float size) {
    vec2 grid = p * scale;
    vec2 cell = floor(grid);
    vec2 local = fract(grid) - 0.5;

    float seed = hash12(cell + 11.37);
    if (seed < threshold) {
        return 0.0;
    }
    vec2 offset = (vec2(hash12(cell + 3.11), hash12(cell + 7.53)) - 0.5) * 0.62;
    float dist = length(local - offset);
    float core = 1.0 - smoothstep(0.0, size, dist);
    float twinkle = 0.45 + 0.55 * sin(phase + seed * 40.0);
    return core * max(twinkle, 0.0);
}

void main() {

    vec2 p = vec2(uv.x * 1.015, uv.y);
    float t = UiTime;

    vec2 drift = vec2(cos(t * 0.07), sin(t * 0.06)) * 0.16;
    float cloud1 = fbm(p * 3.2 + drift);
    float cloud2 = fbm(p * 5.4 - drift * 1.7 + vec2(1.7, 0.0));

    vec3 deep = vec3(0.012, 0.008, 0.045);
    vec3 violet = vec3(0.22, 0.05, 0.48);
    vec3 ice = vec3(0.10, 0.42, 1.00);
    vec3 color = mix(deep, violet, smoothstep(0.30, 0.86, cloud1));
    color = mix(color, ice, smoothstep(0.60, 0.98, cloud2) * 0.70);

    float stars = starLayer(p, 9.0, 0.52, t * 2.0, 0.07) * 1.5;
    stars += starLayer(p + vec2(0.31, 0.17), 17.0, 0.66, t * 3.0, 0.055) * 1.9;
    stars += starLayer(p + vec2(0.07, 0.53), 31.0, 0.80, t * 4.0, 0.040) * 1.3;
    color += vec3(0.95, 0.97, 1.00) * stars;

    float edge = smoothstep(0.0, 0.14, min(min(uv.x, 1.0 - uv.x), min(uv.y, 1.0 - uv.y)));
    color *= 0.55 + 0.45 * edge;

    fragColor = vec4(color, 0.92) * ColorModulator * vColor;
}
