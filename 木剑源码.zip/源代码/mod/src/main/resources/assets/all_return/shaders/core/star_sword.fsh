#version 150

uniform sampler2D Sampler0;
uniform vec4 ColorModulator;
uniform float GameTime;

in vec4 vertexColor;
in vec2 texCoord0;
in vec2 localCoord;

out vec4 fragColor;

const float TAU = 6.28318530718;

float hash12(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

float valueNoise(vec2 p) {
    vec2 cell = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = hash12(cell);
    float b = hash12(cell + vec2(1.0, 0.0));
    float c = hash12(cell + vec2(0.0, 1.0));
    float d = hash12(cell + vec2(1.0, 1.0));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

float fbm(vec2 p) {
    float value = 0.0;
    float amp = 0.5;
    for (int i = 0; i < 4; i++) {
        value += amp * valueNoise(p);
        p *= 2.07;
        amp *= 0.52;
    }
    return value;
}

float starLayer(vec2 p, float scale, float threshold, float phase, float sizeMin, float sizeMax) {
    vec2 grid = p * scale;
    vec2 cell = floor(grid);
    vec2 local = fract(grid) - 0.5;

    float seed = hash12(cell + 11.37);
    if (seed < threshold) {
        return 0.0;
    }
    vec2 offset = (vec2(hash12(cell + 3.11), hash12(cell + 7.53)) - 0.5) * 0.62;
    float dist = length(local - offset);
    float size = sizeMin + sizeMax * hash12(cell + 5.19);
    float core = 1.0 - smoothstep(0.0, size, dist);

    float freq = 1.0 + floor(hash12(cell + 5.19) * 3.0);
    float twinkle = 0.45 + 0.55 * sin(phase * freq + seed * 40.0);
    return core * max(twinkle, 0.0);
}

void main() {
    vec4 base = texture(Sampler0, texCoord0);

    if (base.a < 0.1) {
        discard;
    }

    float gt = GameTime * TAU;
    vec2 uv = localCoord / 16.0;

    vec2 axis = normalize(vec2(1.0, 1.0));
    vec2 side = normalize(vec2(1.0, -1.0));

    vec2 flow = uv + axis * (0.18 * sin(gt * 20.0));

    float spine = dot(uv - vec2(0.5), side);
    float band = exp(-spine * spine * 24.0);

    vec2 swirl = vec2(cos(gt * 13.0), sin(gt * 11.0)) * 0.40;
    float cloud1 = fbm(flow * 3.1 + swirl);
    float cloud2 = fbm(flow * 5.7 - swirl * 1.7 + vec2(1.7, 0.0));

    vec3 deep = vec3(0.015, 0.010, 0.055);
    vec3 violet = vec3(0.22, 0.05, 0.50);
    vec3 ice = vec3(0.10, 0.42, 1.00);
    vec3 nebula = mix(deep, violet, smoothstep(0.30, 0.86, cloud1));
    nebula = mix(nebula, ice, smoothstep(0.58, 0.98, cloud2) * 0.75);

    float stars1 = starLayer(flow, 12.0, 0.45, gt * 900.0, 0.05, 0.15) * 1.7;
    float stars2 = starLayer(flow + vec2(17.3, 31.1), 26.0, 0.62, gt * 1500.0, 0.07, 0.20) * 2.3;
    float stars3 = starLayer(flow + vec2(-9.1, 5.7), 45.0, 0.80, gt * 2400.0, 0.10, 0.26) * 1.5;
    float stars = stars1 + stars2 + stars3;

    float shade = clamp(dot(base.rgb, vec3(0.299, 0.587, 0.114)), 0.0, 1.0);

    vec3 color = nebula * (0.35 + 0.85 * band);
    color += vec3(0.92, 0.96, 1.00) * stars * (0.45 + 0.85 * shade);
    color += ice * smoothstep(0.72, 1.0, shade) * 0.275;

    float ridge = pow(max(0.0, 1.0 - abs(spine) * 11.0), 3.0);
    color += vec3(1.0, 0.95, 1.0) * ridge * (0.07 + 0.10 * (0.5 + 0.5 * sin(gt * 300.0)));

    color *= 0.62 + 0.55 * shade;

    fragColor = vec4(clamp(color, 0.0, 1.4), 1.0) * ColorModulator;
}
