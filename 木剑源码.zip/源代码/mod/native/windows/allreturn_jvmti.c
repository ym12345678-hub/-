/*
 * AllReturn · Windows 原生拦截层（JVMTI）
 * =====================================================================
 * 给「全返」补上手机端做不到的那一层：在 JVM 的 ClassFileLoadHook 上
 * 直接截住类文件，做到三件纯 Java 做不到的事：
 *
 *   1. 拦 hidden class：别的模组用 MethodHandles.Lookup.defineHiddenClass
 *      造出来的隐藏类根本不进 ClassFileTransformer / ModLauncher，
 *      只有 JVMTI 的 ClassFileLoadHook 能看到它们。
 *   2. 抢在最前面：这个回调发生在类定义之前，比任何 Java 层 transformer
 *      都早，不存在「后注册被人压住」的问题。
 *   3. 混在原生里：本文件不是 Java 类，没有类名、没有堆栈帧，
 *      Java 侧的自省/枚举看不到这个拦截器。
 *
 * 注入什么不在这里写死：C 层只把类字节交给 Java 侧的
 * cn.blockforge.generated.allreturn.win.NativeHook#transform，
 * 由它用 ASM 注入「开关判断 + 默认返回值」，字节码细节只维护一份。
 *
 * 通用、不点名任何模组：目标集合由 Java 侧扫描 mods/*.jar 得出。
 *
 * 构建（Windows，zig 或 mingw-w64 均可）：
 *   zig cc -target x86_64-windows-gnu -shared -O2 \
 *       -o allreturn_jvmti.dll allreturn_jvmti.c \
 *       -I"%JAVA_HOME%\include" -I"%JAVA_HOME%\include\win32"
 *
 * 两种加载方式都支持：
 *   - 启动参数 -agentpath:<dir>\allreturn_jvmti.dll  （Agent_OnLoad，最早最稳）
 *   - 模组自己 System.load 后由 NativeHook 注册（JNI_OnLoad 兜底）
 */

#include <jni.h>
#include <jvmti.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#ifdef _WIN32
#  include <windows.h>
#endif

#define AR_TAG "[AllReturn Native] "

/* ---------------------------------------------------------------- 状态 */

static JavaVM *g_vm = NULL;
static jvmtiEnv *g_jvmti = NULL;
static jmethodID g_hook_method = NULL;  /* NativeHook.transform(ClassLoader,String,[B)[B */
static jmethodID g_want_method = NULL;  /* NativeHook.wantsRetransform(String)Z */
static jclass g_hook_class = NULL;

static volatile int g_installed = 0;
static volatile long g_seen = 0;
static volatile long g_transformed = 0;
static volatile long g_failed = 0;
static volatile long g_retransformed = 0;
static char g_last_error[256] = {0};

/* 回调里重入保护：ASM 自己在回调中加载类时直接放行 */
#if defined(_MSC_VER)
#  define AR_TLS __declspec(thread)
#else
#  define AR_TLS __thread
#endif
static AR_TLS int t_in_hook = 0;

/* ------------------------------------------------------------- 日志 */

static void ar_vlog(const char *fmt, va_list ap) {
    char buf[512];
    vsnprintf(buf, sizeof(buf), fmt, ap);
    buf[sizeof(buf) - 1] = '\0';
    fprintf(stderr, "%s%s\n", AR_TAG, buf);
    fflush(stderr);
#ifdef _WIN32
    OutputDebugStringA(AR_TAG);
    OutputDebugStringA(buf);
    OutputDebugStringA("\n");
#endif
}

static void ar_log(const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    ar_vlog(fmt, ap);
    va_end(ap);
}

static void ar_set_error(const char *what, jvmtiError err) {
    snprintf(g_last_error, sizeof(g_last_error), "%s (jvmtiError=%d)", what, (int) err);
    g_last_error[sizeof(g_last_error) - 1] = '\0';
}

/* ------------------------------------------------ 明显不该动的类（粗筛） */

/*
 * 只是省一次 JNI 调用的粗筛；精确目标集合在 Java 侧按 mods/*.jar 判断。
 */
static const char *kSkipPrefixes[] = {
        "java/", "javax/", "jdk/", "sun/", "com/sun/",
        "com/mojang/", "cpw/", "net/minecraft/", "net/minecraftforge/", "net/neoforged/",
        "org/objectweb/", "org/slf4j/", "org/apache/", "org/spongepowered/",
        "org/lwjgl/", "org/joml/", "org/jetbrains/", "org/antlr/", "org/mixin/",
        "io/netty/", "it/unimi/", "com/google/",
        "cn/blockforge/",
        NULL
};

static int ar_skip(const char *name) {
    int i;
    for (i = 0; kSkipPrefixes[i]; i++) {
        size_t n = strlen(kSkipPrefixes[i]);
        if (strncmp(name, kSkipPrefixes[i], n) == 0) {
            return 1;
        }
    }
    return 0;
}

/* ------------------------------------------------------- Java 桥注册 */

static void ar_drop_globals(JNIEnv *env) {
    if (g_hook_class && env) {
        (*env)->DeleteGlobalRef(env, g_hook_class);
    }
    g_hook_class = NULL;
    g_hook_method = NULL;
    g_want_method = NULL;
}

static jint ar_register(JNIEnv *env, jclass hookClass) {
    if (!hookClass) {
        return JNI_ERR;
    }
    ar_drop_globals(env);
    g_hook_class = (jclass) (*env)->NewGlobalRef(env, hookClass);
    if (!g_hook_class) {
        return JNI_ERR;
    }
    g_hook_method = (*env)->GetStaticMethodID(env, g_hook_class, "transform",
            "(Ljava/lang/ClassLoader;Ljava/lang/String;[B)[B");
    if (!g_hook_method) {
        (*env)->ExceptionClear(env);
        ar_drop_globals(env);
        return JNI_ERR;
    }
    g_want_method = (*env)->GetStaticMethodID(env, g_hook_class, "wantsRetransform",
            "(Ljava/lang/String;)Z");
    if (!g_want_method) {
        (*env)->ExceptionClear(env); /* 可选 */
    }
    return JNI_OK;
}

/* --------------------------------------------------- ClassFileLoadHook */

static void JNICALL ar_class_file_load_hook(
        jvmtiEnv *jvmti_env,
        JNIEnv *jni_env,
        jclass class_being_redefined,
        jobject loader,
        const char *name,
        jobject protection_domain,
        jint class_data_len,
        const unsigned char *class_data,
        jint *new_class_data_len,
        unsigned char **new_class_data) {

    jbyteArray input;
    jstring jname;
    jbyteArray output;
    jsize out_len;
    unsigned char *buffer = NULL;
    jvmtiError err;

    (void) class_being_redefined;
    (void) protection_domain;

    if (!new_class_data || !new_class_data_len) {
        return;
    }
    *new_class_data = NULL;
    *new_class_data_len = 0;

    if (!name || !class_data || class_data_len <= 0 || !g_hook_class || !g_hook_method) {
        return;
    }
    if (t_in_hook || ar_skip(name)) {
        return;
    }
    g_seen++;
    t_in_hook = 1;

    input = (*jni_env)->NewByteArray(jni_env, class_data_len);
    jname = input ? (*jni_env)->NewStringUTF(jni_env, name) : NULL;
    if (!input || !jname) {
        (*jni_env)->ExceptionClear(jni_env);
        if (input) {
            (*jni_env)->DeleteLocalRef(jni_env, input);
        }
        t_in_hook = 0;
        g_failed++;
        return;
    }
    (*jni_env)->SetByteArrayRegion(jni_env, input, 0, class_data_len, (const jbyte *) class_data);

    output = (jbyteArray) (*jni_env)->CallStaticObjectMethod(
            jni_env, g_hook_class, g_hook_method, loader, jname, input);

    if ((*jni_env)->ExceptionCheck(jni_env)) {
        (*jni_env)->ExceptionClear(jni_env);
        output = NULL;
    }

    if (output) {
        out_len = (*jni_env)->GetArrayLength(jni_env, output);
        if (out_len > 0 && out_len <= (64 * 1024 * 1024)) {
            err = (*jvmti_env)->Allocate(jvmti_env, (jlong) out_len, &buffer);
            if (err == JVMTI_ERROR_NONE && buffer) {
                (*jni_env)->GetByteArrayRegion(jni_env, output, 0, out_len, (jbyte *) buffer);
                *new_class_data = buffer;
                *new_class_data_len = out_len;
                g_transformed++;
            } else {
                ar_set_error("Allocate", err);
                g_failed++;
                if (buffer) {
                    (*jvmti_env)->Deallocate(jvmti_env, buffer);
                }
            }
        }
        (*jni_env)->DeleteLocalRef(jni_env, output);
    }

    (*jni_env)->DeleteLocalRef(jni_env, jname);
    (*jni_env)->DeleteLocalRef(jni_env, input);
    t_in_hook = 0;
}

/* ------------------------------------------------------- 系统属性标记 */

/*
 * Agent_OnLoad 阶段 JNI 还不能用（拿不到 Java 类），但 SetSystemProperty
 * 是允许的。这里打一个标记，Java 侧看到它就跳过重复 load DLL。
 */
static void ar_mark_loaded(jvmtiEnv *env, const char *source) {
    if (!env) {
        return;
    }
    (*env)->SetSystemProperty(env, "allreturn.native.agentpath", source);
}

/* ------------------------------------------------------------ 安装 */

static jint ar_install(JavaVM *vm, const char *source) {
    jvmtiEnv *env = NULL;
    jvmtiError err;
    jvmtiCapabilities caps;
    jvmtiEventCallbacks callbacks;
    jint rc;

    if (!vm) {
        return JNI_ERR;
    }
    g_vm = vm;
    if (g_installed && g_jvmti) {
        return JNI_OK;
    }

    rc = (*vm)->GetEnv(vm, (void **) &env, JVMTI_VERSION_1_2);
    if (rc != JNI_OK || !env) {
        rc = (*vm)->GetEnv(vm, (void **) &env, JVMTI_VERSION_1_0);
    }
    if (rc != JNI_OK || !env) {
        ar_log("拿不到 JVMTI 环境（%s），原生拦截不可用", source);
        return JNI_ERR;
    }
    g_jvmti = env;

    memset(&caps, 0, sizeof(caps));
    caps.can_generate_all_class_hook_events = 1;
    caps.can_retransform_classes = 1;
    caps.can_generate_early_class_hook_events = 1;

    err = (*env)->AddCapabilities(env, &caps);
    if (err != JVMTI_ERROR_NONE) {
        ar_set_error("AddCapabilities", err);
        ar_log("加能力失败：%s", g_last_error);
        memset(&caps, 0, sizeof(caps));
        caps.can_generate_all_class_hook_events = 1;
        caps.can_retransform_classes = 1;
        err = (*env)->AddCapabilities(env, &caps);
        if (err != JVMTI_ERROR_NONE) {
            ar_set_error("AddCapabilities(retry)", err);
            ar_log("加能力仍然失败：%s", g_last_error);
            return JNI_ERR;
        }
    }

    memset(&callbacks, 0, sizeof(callbacks));
    callbacks.ClassFileLoadHook = &ar_class_file_load_hook;
    err = (*env)->SetEventCallbacks(env, &callbacks, (jint) sizeof(callbacks));
    if (err != JVMTI_ERROR_NONE) {
        ar_set_error("SetEventCallbacks", err);
        ar_log("挂回调失败：%s", g_last_error);
        return JNI_ERR;
    }

    err = (*env)->SetEventNotificationMode(env, JVMTI_ENABLE,
                                           JVMTI_EVENT_CLASS_FILE_LOAD_HOOK, NULL);
    if (err != JVMTI_ERROR_NONE) {
        ar_set_error("SetEventNotificationMode", err);
        ar_log("开事件失败：%s", g_last_error);
        return JNI_ERR;
    }

    g_installed = 1;
    ar_mark_loaded(env, "true");
    ar_log("JVMTI 拦截已装上（%s）", source);
    return JNI_OK;
}

/* -------------------------------------------------- 补拦已加载的类 */

/*
 * 事件打开之前就已经加载完的类不会再触发 ClassFileLoadHook，
 * 这里用 RetransformClasses 把它们补一遍（对每个类单独重试，失败只跳过）。
 */
static jint ar_retransform_loaded(JNIEnv *env) {
    jint total = 0;
    jclass *all = NULL;
    jclass *pick = NULL;
    jint picked = 0;
    jint i;
    jint done = 0;
    jvmtiError err;

    if (!g_jvmti || !g_want_method || !g_hook_class) {
        return 0;
    }
    err = (*g_jvmti)->GetLoadedClasses(g_jvmti, &total, &all);
    if (err != JVMTI_ERROR_NONE || !all) {
        ar_set_error("GetLoadedClasses", err);
        return 0;
    }
    if (total <= 0) {
        (*g_jvmti)->Deallocate(g_jvmti, (unsigned char *) all);
        return 0;
    }
    pick = (jclass *) calloc((size_t) total, sizeof(jclass));
    if (!pick) {
        (*g_jvmti)->Deallocate(g_jvmti, (unsigned char *) all);
        return 0;
    }

    for (i = 0; i < total; i++) {
        char *sig = NULL;
        char name[1024];
        size_t len;
        jstring jn;
        jboolean want;

        if ((*g_jvmti)->GetClassSignature(g_jvmti, all[i], &sig, NULL) != JVMTI_ERROR_NONE || !sig) {
            continue;
        }
        if (sig[0] != 'L') {
            (*g_jvmti)->Deallocate(g_jvmti, (unsigned char *) sig);
            continue;
        }
        len = strlen(sig);
        if (len < 3 || len > sizeof(name)) {
            (*g_jvmti)->Deallocate(g_jvmti, (unsigned char *) sig);
            continue;
        }
        memcpy(name, sig + 1, len - 2);
        name[len - 2] = '\0';
        (*g_jvmti)->Deallocate(g_jvmti, (unsigned char *) sig);

        if (ar_skip(name)) {
            continue;
        }
        jn = (*env)->NewStringUTF(env, name);
        if (!jn) {
            (*env)->ExceptionClear(env);
            continue;
        }
        want = (*env)->CallStaticBooleanMethod(env, g_hook_class, g_want_method, jn);
        if ((*env)->ExceptionCheck(env)) {
            (*env)->ExceptionClear(env);
            want = JNI_FALSE;
        }
        (*env)->DeleteLocalRef(env, jn);
        if (want) {
            pick[picked++] = all[i];
        }
    }

    for (i = 0; i < picked; i++) {
        jvmtiError r = (*g_jvmti)->RetransformClasses(g_jvmti, 1, &pick[i]);
        if (r == JVMTI_ERROR_NONE) {
            done++;
        }
    }
    g_retransformed += done;

    free(pick);
    (*g_jvmti)->Deallocate(g_jvmti, (unsigned char *) all);
    ar_log("补拦已加载的类：候选 %d，成功 %d", (int) picked, (int) done);
    return done;
}

/* ------------------------------------------------------- JVMTI 入口 */

JNIEXPORT jint JNICALL Agent_OnLoad(JavaVM *vm, char *options, void *reserved) {
    (void) options;
    (void) reserved;
    ar_install(vm, "agentpath");
    return JNI_OK;
}

JNIEXPORT jint JNICALL Agent_OnAttach(JavaVM *vm, char *options, void *reserved) {
    (void) options;
    (void) reserved;
    ar_install(vm, "agentattach");
    return JNI_OK;
}

JNIEXPORT void JNICALL Agent_OnUnload(JavaVM *vm) {
    (void) vm;
}

/* --------------------------------------------------------- JNI 入口 */

/* JNI 方法表只在 JNI_OnLoad 之后才搬进来，所以这里再补一次标记。 */
JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *vm, void *reserved) {
    (void) reserved;
    g_vm = vm;
    if (g_jvmti) {
        ar_mark_loaded(g_jvmti, "true");
    }
    return JNI_VERSION_1_8;
}

JNIEXPORT void JNICALL JNI_OnUnload(JavaVM *vm, void *reserved) {
    (void) vm;
    (void) reserved;
}

/* ---- cn.blockforge.generated.allreturn.win.NativeHook ---- */

JNIEXPORT jboolean JNICALL
Java_cn_blockforge_generated_allreturn_win_NativeHook_nativeRegister(JNIEnv *env, jclass clazz) {
    if (ar_register(env, clazz) != JNI_OK) {
        ar_log("注册 Java 桥失败");
        return JNI_FALSE;
    }
    if (!g_installed) {
        if (ar_install(g_vm, "system-load") != JNI_OK) {
            return JNI_FALSE;
        }
    }
    return JNI_TRUE;
}

JNIEXPORT jint JNICALL
Java_cn_blockforge_generated_allreturn_win_NativeHook_nativeRetransformLoaded(JNIEnv *env, jclass clazz) {
    (void) clazz;
    return ar_retransform_loaded(env);
}

JNIEXPORT jboolean JNICALL
Java_cn_blockforge_generated_allreturn_win_NativeHook_nativeInstalled(JNIEnv *env, jclass clazz) {
    (void) env;
    (void) clazz;
    return g_installed ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jstring JNICALL
Java_cn_blockforge_generated_allreturn_win_NativeHook_nativeStatus(JNIEnv *env, jclass clazz) {
    char buf[512];
    (void) clazz;
    snprintf(buf, sizeof(buf),
             "installed=%d seen=%ld transformed=%ld retransformed=%ld failed=%ld%s%s",
             g_installed, g_seen, g_transformed, g_retransformed, g_failed,
             g_last_error[0] ? " lastError=" : "",
             g_last_error[0] ? g_last_error : "");
    buf[sizeof(buf) - 1] = '\0';
    return (*env)->NewStringUTF(env, buf);
}
