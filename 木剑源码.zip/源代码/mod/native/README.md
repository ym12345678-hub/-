# AllReturn 原生代码（教程第 6、7 章）

## native_injector.cpp（第 6 章 JNI 本地注入）

```bash
# Windows（mingw-w64 交叉编译，产物 native_injector.dll）
x86_64-w64-mingw32-g++ -shared -o native_injector.dll native_injector.cpp \
    -I"%JAVA_HOME%\include" -I"%JAVA_HOME%\include\win32"

# Linux/Android（仅语法检查 / 占位）
g++ -shared -fPIC -o libnative_injector.so native_injector.cpp
```

把编译出的 `native_injector.dll` 放到：
- Windows：`%JAVA_HOME%\bin\` 或游戏目录，或加入 `java.library.path`
- 运行时由 `NativeInjector` 类通过 `System.loadLibrary("native_injector")` 加载

## x64_hook_engine（第 7 章 x64 内联 Hook）

```bash
# Windows
x86_64-w64-mingw32-g++ -shared -o x64_hook.dll x64_hook_engine.cpp \
    -I"%JAVA_HOME%\include" -I"%JAVA_HOME%\include\win32"

# Linux/Android（占位）
g++ -shared -fPIC -o libx64hook.so x64_hook_engine.cpp
```

## 注意
- 这些原生库是**可选**的：Java 侧的 `NativeInjector` 和 `VTableHookMaster` 都会安全降级，
  库加载失败时所有方法返回默认值，不会影响模组运行。
- 实际运行目标是 Windows Forge 客户端（Minecraft 1.20.1），需要在 Windows 上用
  mingw-w64 或 MSVC 编译为 DLL 后放入游戏目录。
