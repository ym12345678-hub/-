#include "x64_hook_engine.hpp"
#include <cstring>

std::vector<X64InlineHook::HookContext> X64InlineHook::g_hooks;

static void makeWritable(void* addr, size_t size) {
#if defined(_WIN32) || defined(_WIN64)
    DWORD oldProtect;
    VirtualProtect(addr, size, PAGE_EXECUTE_READWRITE, &oldProtect);
#else
    size_t page = (size_t)sysconf(_SC_PAGESIZE);
    void* p = (void*)((size_t)addr & ~(page - 1));
    mprotect(p, page + size, PROT_READ | PROT_WRITE | PROT_EXEC);
#endif
}

static void flushICache(void* addr, size_t size) {
#if defined(_WIN32) || defined(_WIN64)
    FlushInstructionCache(GetCurrentProcess(), addr, size);
#endif
}

bool X64InlineHook::Install(void* target, void* hook, void** original) {
    if (!target || !hook || !original) return false;
    HookContext ctx;
    ctx.targetAddr = target;
    ctx.hookFunc = hook;
    memcpy(ctx.originalBytes, target, HOOK_SIZE);
    ctx.trampoline = CreateTrampoline(target, ctx.originalBytes);
    if (!ctx.trampoline) return false;

    unsigned char hookCode[HOOK_SIZE] = {
        0x48, 0xB8,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0xFF, 0xE0,
        0x90, 0x90
    };
    memcpy(hookCode + 2, &hook, 8);

    makeWritable(target, HOOK_SIZE);
    memcpy(target, hookCode, HOOK_SIZE);
    flushICache(target, HOOK_SIZE);

    *original = ctx.trampoline;
    g_hooks.push_back(ctx);
    return true;
}

bool X64InlineHook::Remove(void* target) {
    for (auto& ctx : g_hooks) {
        if (ctx.targetAddr == target) {
            makeWritable(target, HOOK_SIZE);
            memcpy(target, ctx.originalBytes, HOOK_SIZE);
            flushICache(target, HOOK_SIZE);
#if defined(_WIN32) || defined(_WIN64)
            VirtualFree(ctx.trampoline, 0, MEM_RELEASE);
#else

#endif
            return true;
        }
    }
    return false;
}

void* X64InlineHook::CreateTrampoline(void* target, unsigned char* original) {
#if defined(_WIN32) || defined(_WIN64)
    void* tramp = VirtualAlloc(nullptr, 32, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
#else
    void* tramp = mmap(nullptr, 32, PROT_READ | PROT_WRITE | PROT_EXEC,
                       MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
#endif
    if (!tramp) return nullptr;
    unsigned char* code = (unsigned char*)tramp;
    memcpy(code, original, HOOK_SIZE);
    code[HOOK_SIZE]     = 0x48;
    code[HOOK_SIZE + 1] = 0xB8;
    void* returnAddr = (char*)target + HOOK_SIZE;
    memcpy(code + HOOK_SIZE + 2, &returnAddr, 8);
    code[HOOK_SIZE + 10] = 0xFF;
    code[HOOK_SIZE + 11] = 0xE0;
    flushICache(tramp, 32);
    return tramp;
}
