#include <jni.h>
#include <cstring>

#if defined(_WIN32) || defined(_WIN64)
#include <windows.h>
#define PLATFORM_WINDOWS 1
#else
#include <sys/mman.h>
#include <unistd.h>
#define PLATFORM_WINDOWS 0
#endif

extern "C" {

JNIEXPORT jlong JNICALL
Java_cn_blockforge_generated_allreturn_combat_NativeInjector_getObjectAddress(
        JNIEnv* env, jclass cls, jobject obj) {
    jclass unsafeClass = env->FindClass("sun/misc/Unsafe");
    if (!unsafeClass) return 0LL;
    jfieldID theUnsafeField = env->GetStaticFieldID(unsafeClass, "theUnsafe", "Lsun/misc/Unsafe;");
    if (!theUnsafeField) return 0LL;
    jobject unsafe = env->GetStaticObjectField(unsafeClass, theUnsafeField);
    if (!unsafe) return 0LL;
    jmethodID getLongMethod = env->GetMethodID(unsafeClass, "getLong", "(Ljava/lang/Object;J)J");
    if (!getLongMethod) return 0LL;
    jclass arrayClass = env->FindClass("[Ljava/lang/Object;");

    jobjectArray arr = env->NewObjectArray(1, env->FindClass("java/lang/Object"), nullptr);
    env->SetObjectArrayElement(arr, 0, obj);
    jmethodID baseOffsetMethod = env->GetMethodID(unsafeClass, "arrayBaseOffset", "(Ljava/lang/Class;)I");
    jint base = env->CallIntMethod(unsafe, baseOffsetMethod, env->FindClass("[Ljava/lang/Object;"));
    return env->CallLongMethod(unsafe, getLongMethod, arr, (jlong)base);
}

JNIEXPORT void JNICALL
Java_cn_blockforge_generated_allreturn_combat_NativeInjector_nativeWriteFloat(
        JNIEnv* env, jclass cls, jlong addr, jfloat value) {
    if (addr == 0) return;
#if PLATFORM_WINDOWS
    DWORD oldProtect;
    VirtualProtect((LPVOID)addr, sizeof(float), PAGE_EXECUTE_READWRITE, &oldProtect);
    *(jfloat*)addr = value;
    VirtualProtect((LPVOID)addr, sizeof(float), oldProtect, &oldProtect);
    FlushInstructionCache(GetCurrentProcess(), (LPCVOID)addr, sizeof(float));
#else
    size_t page = (size_t)sysconf(_SC_PAGESIZE);
    void* p = (void*)(addr & ~(page - 1));
    mprotect(p, page, PROT_READ | PROT_WRITE | PROT_EXEC);
    *(jfloat*)addr = value;
#endif
}

JNIEXPORT void JNICALL
Java_cn_blockforge_generated_allreturn_combat_NativeInjector_nativeZeroMemory(
        JNIEnv* env, jclass cls, jlong addr, jint size) {
    if (addr == 0 || size <= 0) return;
#if PLATFORM_WINDOWS
    DWORD oldProtect;
    VirtualProtect((LPVOID)addr, (SIZE_T)size, PAGE_EXECUTE_READWRITE, &oldProtect);
    memset((void*)addr, 0, (size_t)size);
    VirtualProtect((LPVOID)addr, (SIZE_T)size, oldProtect, &oldProtect);
    FlushInstructionCache(GetCurrentProcess(), (LPCVOID)addr, (SIZE_T)size);
#else
    size_t page = (size_t)sysconf(_SC_PAGESIZE);
    void* p = (void*)(addr & ~(page - 1));
    mprotect(p, page + (size_t)size, PROT_READ | PROT_WRITE | PROT_EXEC);
    memset((void*)addr, 0, (size_t)size);
#endif
}

}
