#pragma once

#if defined(_WIN32) || defined(_WIN64)
#include <windows.h>
#else
#include <sys/mman.h>
#include <unistd.h>
#include <cstring>
#endif
#include <vector>

class X64InlineHook {
public:
    static constexpr size_t HOOK_SIZE = 14;

    struct HookContext {
        void* targetAddr;
        void* hookFunc;
        void* trampoline;
        unsigned char originalBytes[HOOK_SIZE];
    };

    static bool Install(void* target, void* hook, void** original);
    static bool Remove(void* target);

private:
    static std::vector<HookContext> g_hooks;
    static void* CreateTrampoline(void* target, unsigned char* original);
};
