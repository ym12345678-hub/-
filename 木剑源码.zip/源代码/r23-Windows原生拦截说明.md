# 全返 r23 · Windows 原生拦截层（AllReturn）

这份说明只讲这次新增的东西：**在 Windows 电脑上做的 JVMTI 原生拦截层**，
也就是之前手机上做不了、只能留给 PC 的那一块。

---

## 1. 这次到底做了什么

手机上（FCL / Android）只能做纯 Java 的通用 AllReturn：扫 `mods/*.jar`，
用 ModLauncher 的 `ITransformationService` 注入「开关判断 + 默认返回值」。
它有两个绕不过去的短板，这次在 Windows 上补掉了：

| 短板 | 手机版 | Windows 版（本次） |
|---|---|---|
| 拦别的模组用 `defineHiddenClass` 造的**隐藏类** | 做不到（隐藏类不进 `ClassFileTransformer`） | **做得到**，JVMTI `ClassFileLoadHook` 能看到 |
| 抢在别人前面 | 依赖注册顺序，可能被后注册的压住 | **回调发生在类定义之前**，天然最早 |
| 事件打开前已加载的类 | 管不到 | 用 `RetransformClasses` **补拦** |
| 拦截器本身的可见性 | 是普通 Java 类 | 是原生 DLL，**没有类名、没有堆栈帧** |

实现分两层：

- **原生**：`native/windows/allreturn_jvmti.c` → 编译成 `allreturn_jvmti.dll`
- **Java**：`cn.blockforge.generated.allreturn.win` 包
  - `NativeHook`：接收原生回调，用 ASM 注入字节码
  - `WinBridge`：负责把 DLL 装进 JVM
  - `WinTargets`：扫描 `mods/*.jar` 算出目标集合
  - `WinLog` / `NativeHookSelfTest`：日志与自测

**通用、不点名任何模组**：谁进了 `mods/`、又不是全返自己，就算目标；
JDK / Minecraft / Forge / ASM / Netty 这些明显不该动的一律跳过。

---

## 2. 交付物

| 文件 | 说明 | SHA1 |
|---|---|---|
| `all_return-1.0.0-r23.jar` | **本体**：`mods.toml` + 武器/UI/时停/主权/FinalSay + **jar 内自带 DLL** | `0682ee61bc0c7dbb37e97061aed8aed5ac39e406` |
| `all_return_module-1.0.0-r23.jar` | **模块**：只有 `META-INF/services/...ITransformationService` + `core/*` | `1f688bf4d164b479fbaca386983cce424b8a389c` |
| `allreturn_jvmti.dll` | 单独的原生库（想用 `-agentpath` 时用这个） | `7d8c76bb82044e0dbc94d9b701c04cb3787b600e` |

**两个 jar 都要放**进 `mods/`。

> 为什么必须拆两个：单个 jar 同时带 `mods.toml` 和
> `META-INF/services/...ITransformationService` 时，Forge 会把它当成
> coremod/service，Mods 列表里不显示「木剑」，物品也不会注册——这个坑 r22 踩过。

---

## 3. 怎么用

### 方式 A：直接放 mods（最省事）

1. 把两个 jar 丢进 `mods/`；
2. 完全退出启动器再开；
3. 进游戏后执行 `/allreturn native` 看状态。

本体 jar 里自带 DLL，`WinBridge` 会把它解压到临时目录再加载，不需要手动放 DLL。

### 方式 B：-agentpath 启动（最早、最稳）

在你的启动参数里加：

```
-agentpath:D:\完整路径\allreturn_jvmti.dll
```

spaces 的路径要整个用引号包起来。这种方式下 JVMTI 在 JVM 启动时（`Agent_OnLoad`）
就装好了，能覆盖到更早加载的类。

> 实测发现一个细节：JVM 用 `-agentpath` 加载的库，其 JNI 方法表**不会**自动挂到
> Java 的 native 解析链上。所以 `WinBridge` 发现启动参数里有 `-agentpath` 时，
> 会再 `System.load` 一次同一个文件（Windows 对同一模块是引用计数，不会装两遍）。
> 两种加载方式最终都走通，自测里都验证过。

### 开关

还是同一个开关：`allreturn.flag`。

- `true`：别的模组的方法一进来就直接返回默认值（`0` / `false` / `null` / `void`）
- `false`：原样放行

进世界后由「全返总开关」驱动，和手机版一致。

### 命令

```
/allreturn native        # 看原生层状态：装没装上、看过多少类、改了多少
/allreturn retransform   # 重新扫 mods，并把已加载的目标类补拦一遍
```

---

## 4. 实测结果

自测是**用最终交付的 jar + jar 里的 DLL**跑的，不是构建目录里的中间产物：

```
[AllReturn Native] 原生库按启动参数加载：...\native\windows-x64\allreturn_jvmti.dll
ensure() = true
describe() = 原生拦截：installed=1 seen=0 transformed=0 retransformed=0 failed=0
intercepts(com/example/othermod/Shield) = true
flag=false -> null（原样放行）
flag=true  -> 565 bytes
flag=true  调用结果: number=0 text=null banner=false
flag=false 调用结果: number=7 text=x
PASS
```

也就是说：

- 开关关着 → 类原样放行（`null`），方法照常返回 `7` / `"x"`
- 开关打开 → 字节被改写（295 → 565 字节），方法返回 `0` / `null` / `false`

**降级行为**：找不到 DLL、不是 Windows、注册失败时，只会打一行日志，
模组其余功能完全不受影响。

---

## 5. 从源码重建

### 原生 DLL

```powershell
$env:JAVA_HOME = "<你的 JDK 17>"
zig cc -target x86_64-windows-gnu -shared -O2 `
    -o allreturn_jvmti.dll allreturn_jvmti.c `
    -I"$env:JAVA_HOME\include" -I"$env:JAVA_HOME\include\win32"
```

mingw-w64 也行（把 `zig cc -target x86_64-windows-gnu` 换成 `g++` 即可）。
产物放 `mod/native/windows/allreturn_jvmti.dll`，`build.gradle` 会自动打进 jar。

### Java

```powershell
$env:GRADLE_OPTS = "-Dnet.minecraftforge.gradle.check.certs=false"
gradle jar --offline
```

> 这台机器内存只有约 6G、可用 1G 出头，`reobfJar` 会另起一个 JVM 直接 OOM。
> 所以构建时把 reobf 单独跑（`build/reobfJar/log.txt` 里有完整参数），
> 再用 `-Xmx420m` 手动执行 renamer。这一步和代码无关，纯粹是这台机器的内存限制。

---

## 6. 已知边界

1. **只在 Windows 上有效**。`allreturn_jvmti.dll` 是 PE 格式，Linux/macOS 上
   `WinBridge` 会直接跳过，退回纯 Java 层（也就是手机版那套）。
2. **只能拦「能拿到字节」的类**。BDD/ROM 化的类、JVM 实现自带的类没有
   `ClassFileLoadHook`，这个任何 JVMTI agent 都一样。
3. **`-agentpath` 会被 `-XX:+DisableAttachMechanism` 影响吗？** 不会。
   `premain` / `agentpath` 走的是启动期加载，`DisableAttachMechanism` 关的是
   运行期动态 attach。两者互不影响。
4. **只改「开关打开时直接返回」这一种注入**。不写死任何模组的类名、不改别人的
   业务逻辑，注入内容由 `allreturn.flag` 控制。

---

## 7. 源码位置

```
mod/native/windows/allreturn_jvmti.c          # 原生层
mod/src/main/java/cn/blockforge/generated/allreturn/win/
    NativeHook.java                            # 回调 + ASM 注入
    WinBridge.java                             # DLL 装载
    WinTargets.java                            # 扫描 mods 求目标集合
    WinLog.java                                # 日志
    NativeHookSelfTest.java                    # 自测入口
```

顺手修掉的两个老问题：

- `mixin/AllReturnEntityMixin.java` 原本 `import` 的是
  `combat.AllReturnState`（这个类不存在，实际在 `state` 包），
  r23 起改成正确的 `state.AllReturnState`，否则整个工程编译不过。
- `all_return.mixins.json` 里列了不存在的 `AllReturnPlayerMixin`，
  且这个配置文件从来没有接进 `mods.toml`。打包时已排除，避免误加载。
